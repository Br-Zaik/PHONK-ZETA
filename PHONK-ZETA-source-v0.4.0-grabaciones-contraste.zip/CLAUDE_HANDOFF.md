# Estado más reciente: PHONK ZETA v0.4.0. Leer `IMPLEMENTATION_V040.md` antes de editar. Evitar revertir schema 3 y tomas guardadas.

# Instrucción de continuidad a Claude — revisar y ampliar PHONK ZETA sin empezar de cero

Este ZIP es código Android real de PHONK ZETA v0.2.0. NO es una especificación vacía; antes de crear nuevos módulos, examina todos los archivos, prueba lo que existe, identifica errores, y conserva los proyectos de usuario JSON v1/v2. No reescribas a ciegas las funciones que ya trabajan.

## Primera tarea: verificación masiva
1. Extrae ZIP en la raíz de un repo limpio. Ejecuta `gradle --no-daemon --continue --stacktrace :app:testDebugUnitTest :app:lintDebug :app:assembleDebug` con Android SDK/Gradle apropiados.
2. Agrupa todos los fallos de compilación, lint y unit tests, corrige las causas compartidas y vuelve a ejecutar el comando completo. No pidas al usuario capturas de un fallo cada vez si el log completo ya existe.
3. Ejecuta pruebas instrumentadas en Android 11 físico o emulador: piano multitáctil, pads, secuenciador 16/32/64, play/REC/stop, entrada MIDI, WAV importado, grabación de micrófono, guardar, terminar app, reabrir, exporter WAV y reproducción en reproductor externo.
4. Registra resultados reales en IMPLEMENTATION_STATUS.md. No declare «sin fallos» hasta comprobarlo.

## Arquitectura existente
- `MusicCore.kt`: ZetaProject JSON v2 compatible v1, ProjectStorage atómico, WaveDecoder PCM16, sample bank de 1 muestra, ZetaAudioEngine estéreo 48kHz AudioTrack con scheduler en frames, voices, drive/delay, export WAV PCM16 offline.
- `MainActivity.kt`: Compose UI 7 herramientas, instrumentos/piano/touch/pads/ritmos/piano roll/arreglo/mixer/FX, workflows de SAF JSON/WAV, autosave.
- `RecordingAndMidi.kt`: WAV micrófono, MIDI básico Android input.
- `app/src/main/assets/soundkit`: 24 muestras originales con manifest.
- `.github/workflows/android.yml`: Actions agregado test/lint/build, reportes aunque falle.

## Siguiente conjunto de trabajos (son PENDIENTES, no pedir disculpas ni ocultar)
A. Rendimiento: reemplazar renderizado con lock compartido por C++/Oboe, colas SPSC de comandos, buffers preasignados, clock/sample accurate, ruta de audio, audio focus, gestión de glitch y reconexión. Mantener formato de proyecto y pruebas de golden WAV.
B. Instrumentos: sampler multipista/multizona/velocity layers, asignación de 16 pads, kits personalizables, ADSR filtrado, 808 con glide/legato y varios presets, pitch bend/aftertouch, arpegiador real. Conservar el soundkit legal.
C. Edición: clips arrastrables en timeline con patrón/drum/audio, marcadores y secciones de canción, loops/dupl, undo transaction, piano roll drag/resize/scroll/zoom/multi-select, automatización sample-accurate.
D. Audio: pistas de micrófono importadas al timeline con grabación por tomas, edición no destructiva, waveform, crop, slicing, pitch stretch, mezcla de samples y sintetizadores.
E. FX: EQ/compresión/sidechain/reverb/chorus/filters/limiter por canal y buses, automatización de parámetros, pruebas de clipping y export coherente.
F. Proyectos: `.phonkproj` ZIP portable de metadata + samples autorizados + hash + migraciones y safe extraction, autosave snapshot, import/export MIDI SMF, stems, WAV24/FLAC/AAC/MP3 con códecs verificados y licencia adecuada.
G. Diseño: optimizar controles según ancho/alto, accesibilidad, contraste, hit areas, idiomas y pruebas con Moto e30 Android 11; sin copiar UI/recursos de DAWs comerciales.

## Criterio de entrega
Cada avance debe incluir ZIP completo actualizado, APK generado por Actions cuando verificado, CHANGELOG y estado exacto. No fingir que el nuevo motor Oboe o los formatos comprimidos existen porque se dibujó un botón. Si CI falla, recopilar y resolver todos los errores del workflow, no hacer parches improvisados sucesivos sin ejecutar el conjunto completo.
