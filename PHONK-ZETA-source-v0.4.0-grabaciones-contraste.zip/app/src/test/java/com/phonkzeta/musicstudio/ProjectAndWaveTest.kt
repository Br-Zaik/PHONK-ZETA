package com.phonkzeta.musicstudio

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test
import java.io.ByteArrayOutputStream

class ProjectAndWaveTest {
    @Test fun roundTripProjectAndArrangement() {
        val p = ZetaProject(name = "PHONK", bpm = 172, bars = 12, patternLength = 32)
        p.steps[0][21] = true; p.velocity[0][21] = .25
        p.arrangement[6][4] = false; p.pans[5] = -.45; p.solo[5] = true
        p.notes.add(MusicNote(6, 70, 14.125, 1.75, .6))
        p.metronome = true
        val copy = ZetaProject.fromJson(JSONObject(p.toJson().toString()))
        assertEquals(172, copy.bpm)
        assertEquals(12, copy.bars)
        assertEquals(32, copy.patternLength)
        assertTrue(copy.steps[0][21])
        assertEquals(.25, copy.velocity[0][21], 1e-5)
        assertFalse(copy.arrangement[6][4])
        assertTrue(copy.solo[5])
        assertEquals(-.45, copy.pans[5], 1e-5)
        assertEquals(1.75, copy.notes[0].length, 1e-5)
        assertTrue(copy.metronome)
    }
    @Test fun migrationFromOldVersionKeepsDrumNotes() {
        val j = JSONObject("""{"schema":1,"name":"Old","bpm":150,"steps":[[true,false]],"notes":[{"track":6,"pitch":60,"start":0.5,"length":0.25,"velocity":0.8}]}""")
        val p = ZetaProject.fromJson(j)
        assertTrue(p.steps[0][0]); assertEquals(1, p.notes.size)
        assertEquals(64, p.steps[0].size)
    }
    @Test fun decodeValidPcm16Wav() {
        val sample = ByteArrayOutputStream()
        fun write(s: String) { sample.write(s.toByteArray(Charsets.US_ASCII)) }
        fun le(x: Int, n: Int) { repeat(n) { sample.write((x ushr (8 * it)) and 255) } }
        write("RIFF"); le(44, 4); write("WAVEfmt "); le(16, 4)
        le(1, 2); le(1, 2); le(48000, 4); le(96000, 4); le(2, 2); le(16, 2)
        write("data"); le(8, 4)
        listOf(0, 32767, -32768, 0).forEach { le(it, 2) }
        val sound = WaveDecoder.decode(sample.toByteArray())
        assertEquals(48000, sound.sampleRate)
        assertEquals(4, sound.pcm.size)
        assertEquals(-1f, sound.pcm[2], .0001f)
    }
    @Test fun easyPhonkGeneratesRealEditableCustomLengthProject() {
        val p = ZetaProject()
        EasyPhonk.generate(p, "DRIFT", 40, seed = 7)
        assertEquals(40, p.bars)
        assertTrue(p.steps[0].any { it })
        assertTrue(p.steps[1].any { it })
        assertTrue(p.notes.any { it.track == 5 })
        assertTrue(p.notes.any { it.track == 6 })
        assertTrue(p.notes.all { it.start < p.bars * 4.0 })
        val copy = ZetaProject.fromJson(JSONObject(p.toJson().toString()))
        assertEquals(p.notes.size, copy.notes.size)
        assertEquals(p.bars, copy.bars)
    }
    @Test fun namedTakeSurvivesJsonAutosaveAndLongerSong() {
        val p = ZetaProject(bars = 256)
        val phrase = listOf(MusicNote(6, 64, 42.0, .75), MusicNote(5, 40, 43.0, 1.0))
        p.notes.addAll(phrase)
        p.takes.add(ZetaTake("take-123", "Mi improvisación", phrase, 123L))
        val copy = ZetaProject.fromJson(JSONObject(p.toJson().toString()))
        assertEquals(256, copy.bars)
        assertEquals(1, copy.takes.size)
        assertEquals("Mi improvisación", copy.takes[0].name)
        assertEquals(phrase, copy.takes[0].notes)
        assertEquals(123L, copy.takes[0].createdAt)
    }
    @Test fun olderJsonWithoutTakesStillOpens() {
        val p = ZetaProject.fromJson(JSONObject("""{"schema":2,"name":"Version previa","bars":12}"""))
        assertTrue(p.takes.isEmpty())
        assertEquals(12, p.bars)
    }
    @Test fun customPhonkDurationIsNotFixedTo30Or60Seconds() {
        val p = ZetaProject()
        EasyPhonk.generate(p, "DARK", 37, seed = 2)
        assertEquals(37, p.bars)
        assertTrue(p.notes.any { it.start >= 35 * 4.0 })
    }
    @Test fun importedBackgroundReferenceSurvivesProjectSave() {
        val p = ZetaProject(backgroundName = "background_123.wav", backgroundGain = .37)
        val copy = ZetaProject.fromJson(JSONObject(p.toJson().toString()))
        assertEquals("background_123.wav", copy.backgroundName)
        assertEquals(.37, copy.backgroundGain, 1e-5)
    }
    @Test fun waveWriterProducesValidMonoPcm() {
        val target = java.io.File.createTempFile("phonk_test", ".wav")
        try {
            WaveWriter.writeMono16(SampleSound(floatArrayOf(0f, .5f, -.5f, 0f), 48000), target)
            val sound = WaveDecoder.decode(target.readBytes())
            assertEquals(4, sound.pcm.size)
            assertEquals(.5f, sound.pcm[1], .0002f)
        } finally { target.delete() }
    }
    @Test(expected = IllegalArgumentException::class)
    fun rejectNonWaveInput() { WaveDecoder.decode(ByteArray(44)) }
}
