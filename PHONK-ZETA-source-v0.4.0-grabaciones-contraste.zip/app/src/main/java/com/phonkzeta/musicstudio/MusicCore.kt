package com.phonkzeta.musicstudio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.*

/** Self-contained original synthesizer. No sound pack of unknown copyright provenance is bundled. */
const val TRACK_COUNT = 16
const val BAR_LIMIT = 512
val TRACK_NAMES = listOf("KICK", "SNARE", "CLOSED HAT", "CLAP", "PIANO", "808", "COWBELL", "SYNTH", "LEAD", "BELLS", "PAD", "SUB BASS", "ORGAN", "PLUCK", "STRINGS", "SAMPLER")

data class MusicNote(val track: Int, val pitch: Int, val start: Double, val length: Double, val velocity: Double = .8)

/** A named MIDI take, persisted with the project. Notes are original snapshot for isolated audition. */
data class ZetaTake(
    val id: String,
    var name: String,
    val notes: List<MusicNote>,
    val createdAt: Long = System.currentTimeMillis()
)

data class ZetaProject(
    var name: String = "Mi primer PHONK",
    var bpm: Int = 150,
    val steps: Array<BooleanArray> = Array(4) { BooleanArray(64) },
    val volumes: DoubleArray = DoubleArray(TRACK_COUNT) { .70 },
    val notes: MutableList<MusicNote> = mutableListOf(),
    val takes: MutableList<ZetaTake> = mutableListOf(),
    var bars: Int = 8,
    var patternLength: Int = 16,
    var swing: Double = 0.0,
    val velocity: Array<DoubleArray> = Array(4) { DoubleArray(64) { .85 } },
    val pans: DoubleArray = DoubleArray(TRACK_COUNT),
    val muted: BooleanArray = BooleanArray(TRACK_COUNT),
    val solo: BooleanArray = BooleanArray(TRACK_COUNT),
    val arrangement: Array<BooleanArray> = Array(TRACK_COUNT) { BooleanArray(BAR_LIMIT) { true } },
    var delay: Double = 0.0,
    var drive: Double = 0.15,
    var samplerName: String = "",
    var samplerRoot: Int = 60,
    var metronome: Boolean = false,
    var samplerOneShot: Boolean = true,
    var backgroundName: String = "",
    var backgroundGain: Double = .42
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("schema", 3); put("name", name); put("bpm", bpm); put("bars", bars)
        put("patternLength", patternLength); put("swing", swing); put("delay", delay)
        put("drive", drive); put("samplerName", samplerName); put("samplerRoot", samplerRoot)
        put("metronome", metronome); put("samplerOneShot", samplerOneShot)
        put("backgroundName", backgroundName); put("backgroundGain", backgroundGain)
        put("steps", JSONArray().also { a -> steps.forEach { row -> a.put(JSONArray().also { ar -> row.forEach { ar.put(it) } }) } })
        put("velocity", JSONArray().also { a -> velocity.forEach { row -> a.put(JSONArray().also { ar -> row.forEach { ar.put(it) } }) } })
        put("volumes", JSONArray().also { a -> volumes.forEach { a.put(it) } })
        put("pans", JSONArray().also { a -> pans.forEach { a.put(it) } })
        put("muted", JSONArray().also { a -> muted.forEach { a.put(it) } })
        put("solo", JSONArray().also { a -> solo.forEach { a.put(it) } })
        put("arrangement", JSONArray().also { a -> arrangement.forEach { row -> a.put(JSONArray().also { ar -> row.forEach { ar.put(it) } }) } })
        put("notes", JSONArray().also { a -> notes.forEach { n -> a.put(JSONObject().apply {
            put("track", n.track); put("pitch", n.pitch); put("start", n.start)
            put("length", n.length); put("velocity", n.velocity)
        }) } })
        put("takes", JSONArray().also { a -> takes.forEach { t -> a.put(JSONObject().apply {
            put("id", t.id); put("name", t.name); put("createdAt", t.createdAt)
            put("notes", JSONArray().also { ns -> t.notes.forEach { n -> ns.put(JSONObject().apply {
                put("track", n.track); put("pitch", n.pitch); put("start", n.start)
                put("length", n.length); put("velocity", n.velocity)
            }) } })
        }) } })
    }
    fun copyDeep(): ZetaProject = fromJson(toJson())
    fun changeName(newName: String) = copyDeep().apply { name = newName }
    companion object {
        fun fromJson(j: JSONObject): ZetaProject {
            require(j.optInt("schema", 1) in 1..3) { "Versión de proyecto no compatible" }
            val p = ZetaProject(j.optString("name", "Mi PHONK"), j.optInt("bpm", 150).coerceIn(40, 260))
            p.bars = j.optInt("bars", 8).coerceIn(1, BAR_LIMIT)
            p.patternLength = j.optInt("patternLength", 16).let { if (it in listOf(16, 32, 64)) it else 16 }
            p.swing = j.optDouble("swing", 0.0).finite(.0).coerceIn(.0, .75)
            p.delay = j.optDouble("delay", 0.0).finite(.0).coerceIn(.0, .75)
            p.drive = j.optDouble("drive", .15).finite(.15).coerceIn(.0, 1.0)
            p.samplerName = j.optString("samplerName", "").take(100)
            p.samplerRoot = j.optInt("samplerRoot", 60).coerceIn(0, 127)
            p.metronome = j.optBoolean("metronome", false)
            p.samplerOneShot = j.optBoolean("samplerOneShot", true)
            p.backgroundName = j.optString("backgroundName", "").take(100)
            p.backgroundGain = j.optDouble("backgroundGain", .42).finite(.42).coerceIn(.0, 1.0)
            fun readBoolRows(key: String, target: Array<BooleanArray>) {
                val rows = j.optJSONArray(key) ?: return
                for (r in target.indices) {
                    val row = rows.optJSONArray(r) ?: continue
                    for (i in target[r].indices) target[r][i] = row.optBoolean(i, target[r][i])
                }
            }
            fun readDoubleRows(key: String, target: Array<DoubleArray>) {
                val rows = j.optJSONArray(key) ?: return
                for (r in target.indices) {
                    val row = rows.optJSONArray(r) ?: continue
                    for (i in target[r].indices) target[r][i] = row.optDouble(i, target[r][i]).finite(.8).coerceIn(.0, 1.0)
                }
            }
            readBoolRows("steps", p.steps); readBoolRows("arrangement", p.arrangement)
            readDoubleRows("velocity", p.velocity)
            fun doubles(key: String, target: DoubleArray, lo: Double, hi: Double) {
                val ar = j.optJSONArray(key) ?: return
                for (i in target.indices) target[i] = ar.optDouble(i, target[i]).finite(target[i]).coerceIn(lo, hi)
            }
            fun bools(key: String, target: BooleanArray) {
                val ar = j.optJSONArray(key) ?: return
                for (i in target.indices) target[i] = ar.optBoolean(i, target[i])
            }
            doubles("volumes", p.volumes, 0.0, 1.0); doubles("pans", p.pans, -1.0, 1.0)
            bools("muted", p.muted); bools("solo", p.solo)
            val ar = j.optJSONArray("notes")
            if (ar != null) for (i in 0 until min(30000, ar.length())) {
                val n = ar.optJSONObject(i) ?: continue
                val start = n.optDouble("start", 0.0).finite(0.0)
                if (start < 0.0 || start >= BAR_LIMIT * 4.0) continue
                p.notes.add(MusicNote(n.optInt("track", 4).coerceIn(0, TRACK_COUNT - 1),
                    n.optInt("pitch", 60).coerceIn(0, 127), start,
                    n.optDouble("length", .25).finite(.25).coerceIn(.01, p.bars * 4.0),
                    n.optDouble("velocity", .8).finite(.8).coerceIn(.0, 1.0)))
            }
            val takes = j.optJSONArray("takes")
            if (takes != null) for (i in 0 until min(200, takes.length())) {
                val t = takes.optJSONObject(i) ?: continue
                val raw = t.optJSONArray("notes") ?: continue
                val takeNotes = mutableListOf<MusicNote>()
                for (k in 0 until min(10000, raw.length())) {
                    val n = raw.optJSONObject(k) ?: continue
                    val at = n.optDouble("start", 0.0).finite(0.0)
                    if (at < 0 || at >= BAR_LIMIT * 4.0) continue
                    takeNotes.add(MusicNote(n.optInt("track", 4).coerceIn(0, TRACK_COUNT - 1),
                        n.optInt("pitch", 60).coerceIn(0, 127), at,
                        n.optDouble("length", .25).finite(.25).coerceIn(.01, BAR_LIMIT * 4.0),
                        n.optDouble("velocity", .8).finite(.8).coerceIn(0.0, 1.0)))
                }
                if (takeNotes.isNotEmpty()) p.takes.add(ZetaTake(
                    t.optString("id", i.toString()).take(100),
                    t.optString("name", "Toma ${i + 1}").take(80), takeNotes,
                    t.optLong("createdAt", 0L)))
            }
            return p
        }
    }
}
private fun Double.finite(fallback: Double) = if (isFinite()) this else fallback

class ProjectStorage(private val context: Context) {
    private val songs = File(context.filesDir, "songs").apply { mkdirs() }
    private val patterns = File(context.filesDir, "patterns").apply { mkdirs() }
    private val samples = File(context.filesDir, "samples").apply { mkdirs() }
    private val backgrounds = File(context.filesDir, "backgrounds").apply { mkdirs() }
    private fun safe(name: String) = name.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(60).ifBlank { "song" }
    fun list(): List<String> = songs.listFiles { f -> f.extension == "json" }?.sortedByDescending { it.lastModified() }?.map { it.nameWithoutExtension } ?: emptyList()
    fun listPatterns(): List<String> = patterns.listFiles { f -> f.extension == "json" }?.sortedByDescending { it.lastModified() }?.map { it.nameWithoutExtension } ?: emptyList()
    private fun saveJson(file: File, value: String) {
        val atomic = AtomicFile(file)
        val output = atomic.startWrite()
        try { output.write(value.toByteArray(Charsets.UTF_8)); atomic.finishWrite(output) }
        catch (e: Exception) { atomic.failWrite(output); throw e }
    }
    fun save(p: ZetaProject): String {
        val name = safe(p.name)
        saveJson(File(songs, "$name.json"), p.toJson().toString())
        return name
    }
    fun load(name: String): ZetaProject = ZetaProject.fromJson(JSONObject(File(songs, "${safe(name)}.json").readText()))
    fun remove(name: String): Boolean = File(songs, "${safe(name)}.json").delete()
    fun savePattern(p: ZetaProject, name: String): String {
        val target = safe(name)
        val data = JSONObject().put("schema", 1).put("name", name).put("sourceBpm", p.bpm)
        data.put("patternLength", p.patternLength)
        data.put("steps", p.toJson().getJSONArray("steps"))
        data.put("velocity", p.toJson().getJSONArray("velocity"))
        data.put("notes", JSONArray().also { arr -> p.notes.filter { it.start < p.patternLength / 4.0 }.forEach { n ->
            arr.put(JSONObject().put("track", n.track).put("pitch", n.pitch).put("start", n.start)
                .put("length", n.length).put("velocity", n.velocity))
        } })
        saveJson(File(patterns, "$target.json"), data.toString())
        return target
    }
    fun loadPattern(into: ZetaProject, name: String) {
        val j = JSONObject(File(patterns, "${safe(name)}.json").readText())
        require(j.optInt("schema") == 1)
        val rows = j.getJSONArray("steps"); val vel = j.optJSONArray("velocity")
        into.patternLength = j.optInt("patternLength", 16).let { if (it in listOf(16, 32, 64)) it else 16 }
        for (r in 0 until 4) for (s in 0 until 64) {
            into.steps[r][s] = rows.optJSONArray(r)?.optBoolean(s) ?: false
            into.velocity[r][s] = vel?.optJSONArray(r)?.optDouble(s, .85)?.finite(.85)?.coerceIn(0.0, 1.0) ?: .85
        }
        val notes = j.optJSONArray("notes")
        into.notes.removeAll { it.start < into.patternLength / 4.0 }
        if (notes != null) for (i in 0 until min(2000, notes.length())) {
            val n = notes.optJSONObject(i) ?: continue
            into.notes.add(MusicNote(n.optInt("track", 4).coerceIn(0, 15), n.optInt("pitch", 60).coerceIn(0, 127),
                n.optDouble("start", 0.0).coerceIn(0.0, into.patternLength / 4.0 - .01),
                n.optDouble("length", .25).coerceIn(.01, into.bars * 4.0), n.optDouble("velocity", .8).coerceIn(0.0, 1.0)))
        }
    }
    /** Accepts only short PCM16 WAVs; user owns imported samples. Stored in internal app folder, no broad storage permissions. */
    fun importSample(stream: InputStream): SampleSound {
        val bytes = stream.use { input ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(32768)
            while (out.size() <= 24 * 1024 * 1024) {
                val n = input.read(buffer)
                if (n < 0) break
                if (n > 0) out.write(buffer, 0, n)
            }
            out.toByteArray()
        }
        require(bytes.size <= 24 * 1024 * 1024) { "La muestra supera los 24 MB" }
        val sound = WaveDecoder.decode(bytes)
        val filename = "sample_${System.currentTimeMillis()}.wav"
        File(samples, filename).writeBytes(bytes)
        return sound.copy(filename = filename)
    }
    fun importBackground(decoded: SampleSound): String {
        val name = "background_${System.currentTimeMillis()}.wav"
        val target = File(backgrounds, name)
        WaveWriter.writeMono16(decoded, target)
        return name
    }
    fun loadBackground(name: String): SampleSound? {
        if (!Regex("background_[0-9]+\\.wav").matches(name)) return null
        val file = File(backgrounds, name)
        return if (file.isFile && file.length() <= 24L * 1024 * 1024) {
            WaveDecoder.decode(file.readBytes()).copy(filename = name)
        } else null
    }
    fun loadSample(name: String): SampleSound? {
        if (name.isBlank() || safe(name.substringBeforeLast('.')) + ".wav" != name) return null
        val file = File(samples, name)
        return if (file.isFile && file.length() <= 24 * 1024 * 1024) WaveDecoder.decode(file.readBytes()).copy(filename = name) else null
    }
}

data class SampleSound(val pcm: FloatArray, val sampleRate: Int, val filename: String = "")
object WaveDecoder {
    private fun short(b: ByteArray, i: Int): Int = (b[i].toInt() and 255) or ((b[i + 1].toInt() and 255) shl 8)
    private fun int(b: ByteArray, i: Int): Int = short(b, i) or (short(b, i + 2) shl 16)
    fun decode(b: ByteArray): SampleSound {
        require(b.size >= 44 && String(b, 0, 4) == "RIFF" && String(b, 8, 4) == "WAVE") { "Se necesita un archivo WAV válido" }
        var channels = 0; var rate = 0; var format = 0; var bits = 0; var pos = 12; var data = -1; var dataLength = 0
        while (pos + 8 <= b.size) {
            val size = int(b, pos + 4).toLong() and 0xFFFFFFFFL
            val next = pos.toLong() + 8L + size + (size and 1L)
            require(next <= b.size.toLong() + 1L && size <= b.size.toLong()) { "WAV corrupto" }
            when (String(b, pos, 4)) {
                "fmt " -> { require(size >= 16); format = short(b, pos + 8); channels = short(b, pos + 10)
                    rate = int(b, pos + 12); bits = short(b, pos + 22) }
                "data" -> { data = pos + 8; dataLength = size.toInt() }
            }
            pos = next.toInt()
        }
        require(format == 1 && channels in 1..2 && bits == 16 && rate in 8000..192000) {
            "Solo WAV PCM de 16 bits, mono o estéreo (8–192 kHz)"
        }
        require(data >= 0 && dataLength > 0 && data.toLong() + dataLength <= b.size.toLong()) { "WAV sin audio" }
        val frames = dataLength / (channels * 2)
        require(frames in 1..(rate * 120)) { "Máximo 120 segundos por muestra" }
        val mono = FloatArray(frames)
        for (i in 0 until frames) {
            val x = short(b, data + i * channels * 2).toShort().toFloat() / 32768f
            val y = if (channels == 2) short(b, data + i * channels * 2 + 2).toShort().toFloat() / 32768f else x
            mono[i] = (x + y) * .5f
        }
        return SampleSound(mono, rate)
    }
}

private class Voice(val track: Int, val pitch: Int, val velocity: Double,
                    val hz: Double = 440.0 * 2.0.pow((pitch - 69) / 12.0),
                    var age: Int = 0, var phase: Double = 0.0, var phase2: Double = 0.0,
                    var position: Double = 0.0, var released: Boolean = false, var releaseAge: Int = 0,
                    var endFrame: Long = Long.MAX_VALUE)
private data class NoteEvent(val frame: Long, val end: Long, val track: Int, val pitch: Int, val velocity: Double)

/** 48 kHz audio engine: note events scheduled against sample frames. AudioTrack backend; Oboe not claimed. */
class ZetaAudioEngine {
    companion object { const val RATE = 48000 }
    private val mutex = Any()
    private val running = AtomicBoolean(false)
    private val voices = ArrayList<Voice>(128)
    private var output: AudioTrack? = null
    private var worker: Thread? = null
    private var song = ZetaProject()
    private var events: List<NoteEvent> = emptyList()
    private var eventIndex = 0
    private var loopFrames = 1L
    private var frame = 0L
    private var playing = false
    private var freeBeat = 0.0
    private var recordingCycles = 0L
    private val pressed = mutableMapOf<Pair<Int, Int>, Double>()
    private var recorded = mutableListOf<MusicNote>()
    private var sample: SampleSound? = null
    private var background: SampleSound? = null
    private var factoryKit: Array<SampleSound?> = arrayOfNulls(TRACK_COUNT)
    private val delayL = DoubleArray(RATE)
    private val delayR = DoubleArray(RATE)
    private var delayIndex = 0
    private var renderLeft = 0.0
    private var renderRight = 0.0
    @Volatile var currentStep: Int = 0; private set
    @Volatile var currentBar: Int = 0; private set
    @Volatile var active: Boolean = false; private set
    @Volatile var recording: Boolean = false; private set
    @Volatile var failure: String = ""; private set
    fun setSample(sound: SampleSound?) = synchronized(mutex) { sample = sound }
    fun setBackground(sound: SampleSound?) = synchronized(mutex) { background = sound }
    fun setFactoryKit(sounds: Map<Int, SampleSound>) = synchronized(mutex) {
        factoryKit = arrayOfNulls<SampleSound>(TRACK_COUNT).also { kit ->
            sounds.forEach { (track, sound) -> if (track in kit.indices) kit[track] = sound }
        }
    }
    fun setProject(p: ZetaProject) = synchronized(mutex) {
        song = p.copyDeep(); rebuild(); frame = 0; eventIndex = 0; voices.clear(); clearDelay()
    }
    fun refresh(p: ZetaProject) = synchronized(mutex) {
        val pos = frame
        song = p.copyDeep(); rebuild()
        frame = (pos % loopFrames).coerceAtLeast(0L)
        eventIndex = events.indexOfFirst { it.frame >= frame }.let { if (it < 0) events.size else it }
    }
    private fun rebuild() {
        val framesPerBeat = RATE * 60.0 / song.bpm
        loopFrames = max(1L, (framesPerBeat * song.bars * 4).roundToLong())
        val e = ArrayList<NoteEvent>()
        for (bar in 0 until song.bars) for (row in 0 until 4) {
            if (!song.arrangement[row][bar]) continue
            for (s in 0 until 16) {
                val idx = (bar * 16 + s) % song.patternLength
                if (!song.steps[row][idx]) continue
                val swingOffset = if (s % 2 == 1) song.swing * .125 else 0.0
                val start = (bar * 4.0 + s / 4.0 + swingOffset) * framesPerBeat
                val sf = start.roundToLong()
                e.add(NoteEvent(sf, sf + (framesPerBeat * .12).roundToLong(), row,
                    intArrayOf(36, 38, 42, 39)[row], song.velocity[row][idx]))
            }
        }
        if (song.metronome) for (bar in 0 until song.bars) for (pulse in 0 until 4) {
            val start = ((bar * 4.0 + pulse) * framesPerBeat).roundToLong()
            e.add(NoteEvent(start, start + (framesPerBeat * .055).roundToLong(), TRACK_COUNT,
                if (pulse == 0) 90 else 75, if (pulse == 0) .6 else .35))
        }
        for (n in song.notes) {
            if (n.start >= song.bars * 4.0) continue
            val bar = (n.start / 4).toInt().coerceIn(0, BAR_LIMIT - 1)
            if (!song.arrangement[n.track][bar]) continue
            val st = (n.start * framesPerBeat).roundToLong()
            e.add(NoteEvent(st, st + (n.length * framesPerBeat).roundToLong().coerceAtLeast(1L), n.track, n.pitch, n.velocity))
        }
        events = e.sortedBy { it.frame }
    }
    private fun clearDelay() { delayL.fill(0.0); delayR.fill(0.0); delayIndex = 0 }
    fun togglePlay(): Boolean = synchronized(mutex) {
        playing = !playing
        if (playing) { frame = 0; eventIndex = 0; voices.clear(); clearDelay() }
        else { voices.clear(); currentBar = 0; currentStep = 0 }
        playing
    }
    fun stop() = synchronized(mutex) {
        playing = false; recording = false; pressed.clear(); recorded.clear(); voices.clear()
        frame = 0; eventIndex = 0; currentStep = 0; currentBar = 0; freeBeat = 0.0; recordingCycles = 0L; clearDelay()
    }
    fun allNotesOff() = synchronized(mutex) {
        for (v in voices) { v.released = true; v.releaseAge = 0 }
        pressed.clear()
    }
    fun startRecording() = synchronized(mutex) {
        recording = true; pressed.clear(); recorded.clear(); freeBeat = 0.0; recordingCycles = 0L
    }
    fun finishRecording(): List<MusicNote> = synchronized(mutex) {
        if (!recording) return@synchronized emptyList()
        val beat = currentBeat()
        for ((key, start) in pressed) recorded.add(MusicNote(key.first, key.second, start, max(.04, beat - start)))
        pressed.clear(); recording = false
        recorded.toList().also { recorded.clear(); recordingCycles = 0L }
    }
    private fun currentBeat() = if (playing) (frame.toDouble() * song.bpm / (RATE * 60.0) + recordingCycles * song.bars * 4.0) else freeBeat
    fun noteOn(track: Int, pitch: Int, velocity: Double = .85) = synchronized(mutex) {
        if (track !in 0 until TRACK_COUNT || pitch !in 0..127) return@synchronized
        if (voices.size >= 96) voices.removeAt(0)
        if (track == 5 || track == 11) voices.removeAll { it.track == track }
        voices.add(Voice(track, pitch, velocity.coerceIn(0.0, 1.0)))
        if (recording) pressed[track to pitch] = currentBeat()
    }
    fun noteOff(track: Int, pitch: Int) = synchronized(mutex) {
        for (v in voices) if (v.track == track && v.pitch == pitch && !v.released) {
            if (track != 15 || !song.samplerOneShot) {
                v.released = true; v.releaseAge = 0
            }
        }
        if (recording) pressed.remove(track to pitch)?.let { start ->
            val end = currentBeat()
            recorded.add(MusicNote(track, pitch, start, max(.04, end - start)))
        }
    }
    fun start() {
        if (!running.compareAndSet(false, true)) return
        try {
            val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT)
            require(min > 0) { "No hay salida de audio compatible" }
            val t = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(max(min, 4096)).build()
            output = t; t.play(); active = true; failure = ""
            worker = thread(name = "PHONK-ZETA-PCM", isDaemon = true, priority = Thread.MAX_PRIORITY) {
                val buffer = ShortArray(256 * 2)
                try {
                    while (running.get()) {
                        synchronized(mutex) {
                            for (i in 0 until 256) {
                                render()
                                buffer[i * 2] = (renderLeft * 32767).roundToInt().coerceIn(-32768, 32767).toShort()
                                buffer[i * 2 + 1] = (renderRight * 32767).roundToInt().coerceIn(-32768, 32767).toShort()
                            }
                        }
                        var pos = 0
                        while (pos < buffer.size && running.get()) {
                            val n = t.write(buffer, pos, buffer.size - pos, AudioTrack.WRITE_BLOCKING)
                            if (n <= 0) { failure = "No se pudo escribir audio ($n)"; running.set(false); break }
                            pos += n
                        }
                    }
                } catch (e: Exception) { failure = e.message ?: "Fallo de motor de audio" }
                finally { try { t.stop(); t.release() } catch (_: Exception) {}; active = false }
            }
        } catch (e: Exception) { running.set(false); failure = e.message ?: "Error de audio"; active = false; throw e }
    }
    fun close() {
        running.set(false)
        try { output?.pause(); output?.flush() } catch (_: Exception) {}
        try { worker?.join(1200) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        output = null
    }
    /** No dynamic list creation in the inner sample processing loop. Caller must own mutex. */
    private fun render() {
        if (playing) {
            if (frame >= loopFrames) { if (recording) recordingCycles++; frame = 0; eventIndex = 0; voices.clear() }
            while (eventIndex < events.size && events[eventIndex].frame <= frame) {
                val e = events[eventIndex++]
                if (voices.size >= 96) voices.removeAt(0)
                if (e.track == 5 || e.track == 11) voices.removeAll { it.track == e.track }
                voices.add(Voice(e.track, e.pitch, e.velocity, endFrame = e.end))
            }
            currentBar = ((frame.toDouble() / loopFrames * song.bars).toInt()).coerceIn(0, song.bars - 1)
            val beat = frame.toDouble() * song.bpm / (RATE * 60.0)
            currentStep = (floor(beat * 4).toInt() % song.patternLength).coerceAtLeast(0)
        } else if (recording) freeBeat += song.bpm.toDouble() / (RATE * 60.0)
        var left = 0.0; var right = 0.0
        val anySolo = song.solo.any { it }
        var i = 0
        while (i < voices.size) {
            val v = voices[i]
            if (v.endFrame <= frame && playing && !v.released &&
                (v.track != 15 || !song.samplerOneShot)) {
                v.released = true; v.releaseAge = 0
            }
            if (v.age > RATE * 7 || (v.released && v.releaseAge > RATE / 2)) {
                voices.removeAt(i); continue
            }
            if (v.track == TRACK_COUNT || (!song.muted[v.track] && (!anySolo || song.solo[v.track]))) {
                val level = min(1.0, v.age / (RATE * .006)) *
                    (if (v.released) exp(-v.releaseAge / (RATE * .065)) else 1.0) * v.velocity
                val sec = v.age.toDouble() / RATE
                val factorySound = factoryKit.getOrNull(v.track)
                val wave: Double = if (factorySound != null) {
                    val at = v.position.toInt()
                    if (at + 1 >= factorySound.pcm.size) {
                        v.released = true; v.releaseAge = RATE; 0.0
                    } else factorySound.pcm[at].toDouble() * (1 - (v.position - at)) +
                        factorySound.pcm[at + 1] * (v.position - at)
                } else when (v.track) {
                    0 -> sin(v.phase + exp(-sec * 45) * 5.0) * exp(-sec * 12)
                    1 -> (.76 * noise(v.age, v.pitch) + .24 * sin(v.phase * 2)) * exp(-sec * 15)
                    2 -> noise(v.age, v.pitch) * exp(-sec * 48)
                    3 -> noise(v.age, v.pitch) * exp(-sec * 25)
                    4 -> (sin(v.phase) + .22 * sin(2 * v.phase)) * exp(-sec * 1.25)
                    5 -> (sin(v.phase + exp(-sec * 27) * 3.0) + .10 * sin(2 * v.phase)) * exp(-sec * .4)
                    6 -> (sin(v.phase) + .55 * sin(v.phase * 1.48) + .20 * sin(v.phase * 2.02)) * exp(-sec * 7)
                    7 -> .55 * sin(v.phase) + .30 * saw(v.phase) + .15 * sin(3 * v.phase)
                    8 -> .48 * saw(v.phase) + .28 * saw(v.phase * 1.005) + .24 * sin(v.phase)
                    9 -> (sin(v.phase) + .45 * sin(2.75 * v.phase)) * exp(-sec * 3)
                    10 -> .63 * sin(v.phase) + .25 * sin(v.phase * 1.003) + .12 * sin(2 * v.phase)
                    11 -> sin(v.phase) * exp(-sec * .12)
                    12 -> .45 * sin(v.phase) + .30 * sin(2 * v.phase) + .25 * sin(3 * v.phase)
                    13 -> (saw(v.phase) * .48 + sin(v.phase) * .52) * exp(-sec * 4)
                    14 -> .58 * sin(v.phase) + .21 * sin(2 * v.phase) + .21 * sin(v.phase * 1.008)
                    15 -> { val sp = sample
                        if (sp == null) 0.0 else {
                            val at = v.position.toInt()
                            if (at + 1 >= sp.pcm.size) { v.released = true; v.releaseAge = RATE; 0.0 }
                            else sp.pcm[at].toDouble() * (1 - (v.position - at)) + sp.pcm[at + 1] * (v.position - at)
                        }
                    }
                    TRACK_COUNT -> sin(v.phase) * exp(-sec * 40)
                    else -> 0.0
                }
                val amp = wave * level * (if (v.track == TRACK_COUNT) .13 else song.volumes[v.track] * .19)
                val pan = if (v.track == TRACK_COUNT) 0.0 else song.pans[v.track]
                left += amp * (1 - pan.coerceAtLeast(0.0))
                right += amp * (1 + pan.coerceAtMost(0.0))
            }
            v.phase += 2 * PI * v.hz / RATE
            val kitSound = factoryKit.getOrNull(v.track)
            if (v.track == 15) {
                v.position += (sample?.sampleRate ?: RATE) / RATE.toDouble() *
                    2.0.pow((v.pitch - song.samplerRoot) / 12.0)
            } else if (kitSound != null) {
                val root = if (v.track == 5) 36 else if (v.track == 6) 60 else v.pitch
                v.position += kitSound.sampleRate / RATE.toDouble() *
                    2.0.pow((v.pitch - root) / 12.0)
            }
            v.age++
            if (v.released) v.releaseAge++
            i++
        }
        val bg = background
        if (playing && bg != null && song.backgroundGain > 0.0) {
            val ix = frame.toDouble() * bg.sampleRate / RATE
            val at = ix.toInt()
            if (at >= 0 && at + 1 < bg.pcm.size) {
                val audio = (bg.pcm[at] * (1.0 - (ix - at)) + bg.pcm[at + 1] * (ix - at)) * song.backgroundGain
                left += audio; right += audio
            }
        }
        val wet = song.delay
        val oldL = delayL[delayIndex]; val oldR = delayR[delayIndex]
        delayL[delayIndex] = left + oldL * .37
        delayR[delayIndex] = right + oldR * .37
        delayIndex = if (delayIndex + 1 >= RATE / 3) 0 else delayIndex + 1
        val drive = 1 + song.drive * 4
        renderLeft = (tanh((left + oldL * wet * .5) * drive) / tanh(drive)).coerceIn(-1.0, 1.0)
        renderRight = (tanh((right + oldR * wet * .5) * drive) / tanh(drive)).coerceIn(-1.0, 1.0)
        frame++
    }
    private fun saw(phase: Double): Double = (phase / (2 * PI) - floor(phase / (2 * PI))) * 2 - 1
    private fun noise(age: Int, seed: Int): Double {
        var x = age * 1103515245 + seed * 12345 + 0x1a2b3c
        x = x xor (x ushr 13); x *= 1274126177; x = x xor (x ushr 16)
        return x.toDouble() / Int.MAX_VALUE
    }
    fun exportWav(p: ZetaProject, destination: File, onProgress: (Int) -> Unit = {}, cancelled: () -> Boolean = { false }) {
        val snapshot = p.copyDeep()
        snapshot.metronome = false  // Click track is for monitoring, never burned into final song.
        val renderer = ZetaAudioEngine()
        renderer.song = snapshot
        renderer.sample = synchronized(mutex) { sample }
        renderer.background = synchronized(mutex) { background }
        renderer.factoryKit = synchronized(mutex) { factoryKit.copyOf() }
        renderer.rebuild(); renderer.playing = true
        val total = renderer.loopFrames
        val dataSize = total * 4L
        require(dataSize <= 0xFFFFFFFFL - 36L) { "Canción demasiado larga para WAV PCM16 clásico" }
        try {
            FileOutputStream(destination).use { out ->
                fun le(value: Long, count: Int) { repeat(count) { i -> out.write(((value ushr (i * 8)) and 255).toInt()) } }
                out.write("RIFF".toByteArray()); le(dataSize + 36, 4); out.write("WAVEfmt ".toByteArray())
                le(16, 4); le(1, 2); le(2, 2); le(RATE.toLong(), 4); le(RATE * 4L, 4)
                le(4, 2); le(16, 2); out.write("data".toByteArray()); le(dataSize, 4)
                val block = ByteArray(4096)
                var done = 0L; var reported = -1
                while (done < total) {
                    if (cancelled()) throw InterruptedException("Exportación cancelada")
                    val frames = min(1024L, total - done).toInt()
                    for (i in 0 until frames) {
                        renderer.render()
                        val l = (renderer.renderLeft * 32767).roundToInt().coerceIn(-32768, 32767)
                        val r = (renderer.renderRight * 32767).roundToInt().coerceIn(-32768, 32767)
                        val j = i * 4
                        block[j] = l.toByte(); block[j + 1] = (l shr 8).toByte()
                        block[j + 2] = r.toByte(); block[j + 3] = (r shr 8).toByte()
                    }
                    out.write(block, 0, frames * 4); done += frames
                    val pct = (done * 100 / total).toInt()
                    if (pct != reported) { reported = pct; onProgress(pct) }
                }
            }
        } catch (e: Exception) { destination.delete(); throw e }
    }
}
