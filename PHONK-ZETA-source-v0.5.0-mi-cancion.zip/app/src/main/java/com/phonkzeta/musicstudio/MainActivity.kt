package com.phonkzeta.musicstudio

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.ArrayDeque
import kotlin.math.*

private val BG = Color(0xFF09090B)
private val SURFACE = Color(0xFF15151D)
private val PANEL = Color(0xFF30303D)
private val PURPLE = Color(0xFFA78BFA)
private val RED = Color(0xFFFF3B5C)
private val GOLD = Color(0xFFF5C451)
private val MUTED = Color(0xFFE1E4ED)
private val WHITE_NOTES = intArrayOf(0, 2, 4, 5, 7, 9, 11)
private val LABEL_NOTES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
private val TABS = listOf("MI CANCIÓN", "INICIO", "GRABACIONES", "PIANO", "PADS", "RITMOS", "PIANO ROLL", "TRACKS", "MIXER", "FX")

class MainActivity : ComponentActivity() {
    val engine = ZetaAudioEngine()
    lateinit var store: ProjectStorage
    lateinit var midi: MidiBridge
    var snapshotProvider: (() -> ZetaProject)? = null
    val micRecorder by lazy { MicRecorder(this) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStorage(this)
        val project = try { store.load("autosave") } catch (_: Exception) { demoProject() }
        engine.setProject(project)
        try {
            val kit = mapOf(
                0 to "01_deep_kick.wav", 1 to "05_dark_snare.wav",
                2 to "09_tight_hat.wav", 3 to "06_snap_snare.wav",
                5 to "17_long_808_c.wav", 6 to "13_drift_cowbell.wav"
            ).mapValues { (_, file) ->
                WaveDecoder.decode(assets.open("soundkit/$file").use { it.readBytes() })
            }
            engine.setFactoryKit(kit)
        } catch (_: Exception) { /* Sound engine falls back to synthesis if an asset is unavailable. */ }
        try {
            engine.setSample(store.loadSample(project.samplerName))
            engine.setBackground(store.loadBackground(project.backgroundName))
            engine.start()
        } catch (_: Exception) { }
        midi = MidiBridge(this, engine)
        setContent { ZetaApp(project, this) }
    }
    override fun onPause() { super.onPause(); engine.allNotesOff() }
    override fun onStop() {
        try { snapshotProvider?.invoke()?.let { store.save(it.changeName("autosave")) } }
        catch (_: Exception) { /* Manual save and previous atomic autosave remain. */ }
        super.onStop()
    }
    override fun onDestroy() { if (::midi.isInitialized) midi.close(); micRecorder.stop(); engine.close(); super.onDestroy() }
}

private fun demoProject() = ZetaProject().apply {
    listOf(0, 6, 8, 14).forEach { steps[0][it] = true }
    listOf(4, 12).forEach { steps[1][it] = true }
    for (i in 0..15 step 2) steps[2][i] = true
    listOf(60, 63, 67, 65, 60, 58, 55, 58).forEachIndexed { i, pitch ->
        notes.add(MusicNote(6, pitch, i * .5, .42))
    }
}

@Composable
private fun ZetaApp(initial: ZetaProject, activity: MainActivity) {
    val engine = activity.engine
    val store = activity.store
    val scope = rememberCoroutineScope()
    var project by remember { mutableStateOf(initial) }
    var revision by remember { mutableIntStateOf(0) }
    // JSON arrays are mutable; explicitly observe edits so step buttons and mixer repaint.
    val observedProject = remember(revision) { project }
    // Recount only on actual edits, not each transport-frame UI tick.
    val laneNoteCounts = remember(revision) {
        IntArray(TRACK_COUNT).also { counts -> project.notes.forEach { counts[it.track]++ } }
    }
    val laneTakeCounts = remember(revision) {
        IntArray(TRACK_COUNT).also { counts ->
            project.takes.forEach { take -> take.notes.map { it.track }.distinct().forEach { counts[it]++ } }
        }
    }
    DisposableEffect(activity, project) {
        activity.snapshotProvider = { project.copyDeep() }
        onDispose { activity.snapshotProvider = null }
    }
    var tab by remember { mutableStateOf("MI CANCIÓN") }
    var showAdvancedTools by remember { mutableStateOf(false) }
    var instrument by remember { mutableIntStateOf(6) }
    var octave by remember { mutableIntStateOf(4) }
    var chordMode by remember { mutableIntStateOf(0) }
    var scaleMode by remember { mutableIntStateOf(0) }
    var rootNote by remember { mutableIntStateOf(0) }
    var playVelocity by remember { mutableFloatStateOf(.85f) }
    var playing by remember { mutableStateOf(false) }
    var transportTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(playing) {
        while (playing) { delay(75); transportTick++ }
    }
    val displayPosition = remember(transportTick) { engine.currentBar to engine.currentStep }
    var recording by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf(if (engine.active) "Estudio listo · sin Internet" else "Audio: ${engine.failure}") }
    var showProjects by remember { mutableStateOf(false) }
    var showPatterns by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<String?>(null) }
    var showHelp by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf(project.name) }
    var patternInput by remember { mutableStateOf("Mi ritmo") }
    var listProjects by remember { mutableStateOf(store.list()) }
    var listPatterns by remember { mutableStateOf(store.listPatterns()) }
    var saving by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableIntStateOf(-1) }
    var noteBar by remember { mutableIntStateOf(0) }
    var noteOctave by remember { mutableIntStateOf(4) }
    var noteLength by remember { mutableFloatStateOf(.25f) }
    var selectedNote by remember { mutableStateOf<MusicNote?>(null) }
    var page by remember { mutableIntStateOf(0) }
    var selectedStep by remember { mutableIntStateOf(-1) }
    var selectedDrum by remember { mutableIntStateOf(0) }
    var midiStatus by remember { mutableStateOf("MIDI: no conectado") }
    val soundKit = remember {
        try {
            val json = org.json.JSONArray(activity.assets.open("soundkit/manifest.json").bufferedReader().use { it.readText() })
            (0 until json.length()).mapNotNull { i -> json.optJSONObject(i) }
        } catch (_: Exception) { emptyList() }
    }
    var showKit by remember { mutableStateOf(false) }
    var kitCategory by remember { mutableStateOf("TODOS") }
    var micRecording by remember { mutableStateOf(false) }
    var micFile by remember { mutableStateOf<File?>(null) }
    var saveJob by remember { mutableStateOf<Job?>(null) }
    var performanceMode by remember { mutableStateOf<String?>(null) }
    var showQuickCreate by remember { mutableStateOf(false) }
    var showInstrumentLibrary by remember { mutableStateOf(false) }
    var librarySlot by remember { mutableIntStateOf(-1) }
    var pendingTrackDelete by remember { mutableIntStateOf(-1) }
    var libraryNotice by remember { mutableStateOf("") }
    var quickStyle by remember { mutableStateOf("DRIFT") }
    var quickBarsInput by remember { mutableStateOf("24") }
    var countIn by remember { mutableIntStateOf(0) }
    var recordingJob by remember { mutableStateOf<Job?>(null) }
    var auditionId by remember { mutableStateOf<String?>(null) }
    var pendingTakeDelete by remember { mutableStateOf<String?>(null) }
    var renameTakeId by remember { mutableStateOf<String?>(null) }
    var renameTakeValue by remember { mutableStateOf("") }
    val undo = remember { ArrayDeque<String>() }
    val redo = remember { ArrayDeque<String>() }

    fun checkpoint() {
        if (undo.size >= 25) undo.removeFirst()
        undo.addLast(project.toJson().toString())
        redo.clear()
    }
    fun changed() {
        revision++
        engine.refresh(project)
        saveJob?.cancel()
        val snapshot = project.copyDeep()
        saveJob = scope.launch {
            delay(650)
            try { withContext(Dispatchers.IO) { store.save(snapshot.changeName("autosave")) } }
            catch (e: Exception) { notice = "No se pudo guardar: ${e.message}" }
        }
    }
    fun newProject(p: ZetaProject, resetHistory: Boolean = true) {
        if (resetHistory) try { store.save(project.copyDeep()) } catch (_: Exception) { }
        recordingJob?.cancel(); countIn = 0; auditionId = null
        engine.stop(); playing = false; recording = false
        saveJob?.cancel(); project = p; if (resetHistory) { undo.clear(); redo.clear() }
        engine.setProject(p)
        try { engine.setSample(store.loadSample(p.samplerName)) } catch (_: Exception) { engine.setSample(null) }
        try { engine.setBackground(store.loadBackground(p.backgroundName)) } catch (_: Exception) { engine.setBackground(null) }
        nameInput = p.name; selectedNote = null; noteBar = 0; page = 0; tab = "MI CANCIÓN"
        changed()
    }
    fun saveNow() {
        scope.launch {
            saving = true
            try {
                saveJob?.cancel()
                val snapshot = project.copyDeep()
                withContext(Dispatchers.IO) {
                    store.save(snapshot)
                    store.save(snapshot.changeName("autosave"))
                }
                listProjects = store.list(); notice = "Proyecto guardado"
            } catch (e: Exception) { notice = "Error al guardar: ${e.message}" }
            finally { saving = false }
        }
    }
    fun stopAudition() {
        if (auditionId != null) {
            engine.stop(); engine.setProject(project)
            playing = false; auditionId = null
        }
    }
    fun stopRecord() {
        if (countIn > 0) {
            recordingJob?.cancel(); countIn = 0
            notice = "Cuenta regresiva cancelada"; return
        }
        if (!recording) return
        checkpoint()
        val result = engine.finishRecording().filter { it.start >= 0.0 && it.start < BAR_LIMIT * 4.0 }
        recording = false
        if (result.isNotEmpty()) {
            val neededBars = (ceil(result.maxOf { it.start + it.length } / 4.0).toInt())
                .coerceIn(1, BAR_LIMIT)
            project.bars = maxOf(project.bars, neededBars)
            val take = ZetaTake(System.currentTimeMillis().toString(),
                "Grabación ${project.takes.size + 1}", result)
            project.takes.add(take)
            project.notes.addAll(result)
            notice = "✓ ${take.name} guardada · ${result.size} notas · abre GRABACIONES"
            tab = "GRABACIONES"
            changed()
        } else notice = "No tocaste ninguna tecla. Prueba REC → toca → FIN."
    }
    fun beginRecord() {
        if (recording || countIn > 0) return
        stopAudition()
        recordingJob?.cancel()
        recordingJob = scope.launch {
            for (number in 3 downTo 1) {
                countIn = number
                notice = "Preparados… $number"
                delay(1000)
            }
            countIn = 0
            if (!playing) playing = engine.togglePlay()
            engine.startRecording(); recording = true
            notice = "● GRABANDO: toca el piano o pads. Pulsa FIN REC cuando termines."
        }
    }
    fun audition(take: ZetaTake) {
        if (recording || countIn > 0) stopRecord()
        stopAudition()
        val first = take.notes.minOfOrNull { it.start } ?: return
        val clip = take.notes.map { it.copy(start = it.start - first) }
        val lastBeat = clip.maxOfOrNull { it.start + it.length } ?: return
        val soloProject = project.copyDeep().apply {
            steps.forEach { it.fill(false) }
            notes.clear(); notes.addAll(clip)
            bars = ceil(lastBeat / 4.0).toInt().coerceIn(1, BAR_LIMIT)
            backgroundGain = 0.0; metronome = false
            muted.fill(false); solo.fill(false)
            arrangement.forEach { it.fill(true) }
        }
        engine.stop(); engine.setProject(soloProject)
        playing = engine.togglePlay(); auditionId = take.id
        notice = "▶ Escuchando SOLO ${take.name} · STOP para regresar a tu canción"
    }
    val importSample = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val sound = withContext(Dispatchers.IO) {
                    val stream = activity.contentResolver.openInputStream(uri) ?: error("No se pudo leer archivo")
                    store.importSample(stream)
                }
                checkpoint(); project.samplerName = sound.filename
                val lane = if (instrument in 4 until TRACK_COUNT && project.instrumentIds[instrument] == 15)
                    instrument else 15
                project.instrumentIds[lane] = 15; project.laneAdded[lane] = true
                project.laneNames[lane] = "MI SAMPLE"
                engine.setSample(sound); instrument = lane; activity.midi.selectInstrument(lane); changed()
                notice = "Muestra cargada · selecciona SAMPLER y toca el piano"
            } catch (e: Exception) { notice = "Error al importar muestra: ${e.message}" }
        }
    }
    val importBackground = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            notice = "Decodificando audio…"
            try {
                val sound = withContext(Dispatchers.IO) {
                    AudioImport.decode(activity, uri)
                }
                val name = withContext(Dispatchers.IO) { store.importBackground(sound) }
                checkpoint(); project.backgroundName = name
                engine.setBackground(sound)
                changed(); notice = "Fondo importado · se escucha en PLAY y se incluye en WAV"
            } catch (e: Exception) { notice = "No se pudo importar el fondo: ${e.message}" }
        }
    }
    val importCompressedSample = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val decoded = withContext(Dispatchers.IO) { AudioImport.decode(activity, uri, 110) }
                val snd = withContext(Dispatchers.IO) {
                    val file = File(activity.cacheDir, "phonk_sample_import.wav")
                    try {
                        WaveWriter.writeMono16(decoded, file)
                        store.importSample(file.inputStream())
                    } finally { file.delete() }
                }
                checkpoint(); project.samplerName = snd.filename; engine.setSample(snd)
                val lane = if (instrument in 4 until TRACK_COUNT && project.instrumentIds[instrument] == 15)
                    instrument else 15
                project.instrumentIds[lane] = 15; project.laneAdded[lane] = true
                project.laneNames[lane] = "MI SAMPLE"
                instrument = lane; activity.midi.selectInstrument(lane); changed()
                notice = "Sample importado: SAMPLER listo"
            } catch (e: Exception) { notice = "Error de sample: ${e.message}" }
        }
    }
    val exportProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                val data = project.toJson().toString(2)
                withContext(Dispatchers.IO) {
                    activity.contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray(Charsets.UTF_8)) }
                        ?: error("No se pudo escribir proyecto")
                }
                notice = "Proyecto .phonkproj exportado (los samples se guardan por separado)"
            } catch (e: Exception) { notice = "Error exportando proyecto: ${e.message}" }
        }
    }
    val importProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val p = withContext(Dispatchers.IO) {
                    val s = activity.contentResolver.openInputStream(uri) ?: error("Sin acceso")
                    ZetaProject.fromJson(org.json.JSONObject(s.bufferedReader().use { it.readText() }))
                }
                newProject(p); showProjects = false; notice = "Proyecto importado"
            } catch (e: Exception) { notice = "Archivo de proyecto no válido: ${e.message}" }
        }
    }
    val exportWav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) scope.launch {
            exportProgress = 0
            val temp = File(activity.cacheDir, "phonk_${System.currentTimeMillis()}.wav")
            try {
                val snapshot = project.copyDeep()
                withContext(Dispatchers.IO) {
                    engine.exportWav(snapshot, temp, onProgress = { pct ->
                        activity.runOnUiThread { exportProgress = pct }
                    })
                    activity.contentResolver.openOutputStream(uri)?.use { destination ->
                        temp.inputStream().use { it.copyTo(destination) }
                    } ?: error("No se pudo guardar WAV")
                }
                notice = "WAV estéreo exportado: ${project.bars} compases"
            } catch (e: Exception) { notice = "Fallo de exportación: ${e.message}" }
            finally { temp.delete(); exportProgress = -1 }
        }
    }
    val exportM4a = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { uri ->
        if (uri != null) scope.launch {
            exportProgress = 0
            val wav = File(activity.cacheDir, "phonk_export_${System.currentTimeMillis()}.wav")
            val m4a = File(activity.cacheDir, "phonk_export_${System.currentTimeMillis()}.m4a")
            try {
                val snapshot = project.copyDeep()
                withContext(Dispatchers.IO) {
                    engine.exportWav(snapshot, wav, onProgress = { pct ->
                        activity.runOnUiThread { exportProgress = pct.coerceAtMost(95) }
                    })
                    AacExporter.wavToM4a(wav, m4a)
                    activity.contentResolver.openOutputStream(uri)?.use { destination ->
                        m4a.inputStream().use { it.copyTo(destination) }
                    } ?: error("No se pudo escribir el archivo M4A")
                }
                notice = "M4A (AAC) exportado; se puede compartir como audio"
            } catch (e: Exception) { notice = "Error exportando M4A: ${e.message}" }
            finally { wav.delete(); m4a.delete(); exportProgress = -1 }
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try { activity.micRecorder.start(); micRecording = true; notice = "Grabando micrófono para el sampler" }
            catch (e: Exception) { notice = "Error de micrófono: ${e.message}" }
        } else notice = "Se necesita permiso de micrófono para grabar audio"
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = PURPLE, onPrimary = Color(0xFF130B22),
        secondary = GOLD, onSecondary = BG, background = BG, surface = SURFACE,
        surfaceVariant = PANEL, onSurfaceVariant = Color.White, onBackground = Color.White,
        onSurface = Color.White, outline = Color(0xFFAFB5C9))) {
        if (performanceMode != null) {
            ZetaPerformance(
                engine = engine, mode = performanceMode!!, track = instrument,
                trackTitle = project.laneNames[instrument], playing = playing, recording = recording, countIn = countIn,
                rootPitchClass = (project.notes.firstOrNull { it.track == 5 }?.pitch ?: 36).mod(12),
                onExit = {
                    engine.allNotesOff()
                    performanceMode = null
                    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                },
                onPlay = { if (recording || countIn > 0) stopRecord(); stopAudition(); playing = engine.togglePlay() },
                onRecord = {
                    if (recording || countIn > 0) {
                        val didRecord = recording
                        stopRecord()
                        if (didRecord) {
                            engine.stop(); playing = false; performanceMode = null
                            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        }
                    } else beginRecord()
                },
                onStop = {
                    val didRecord = recording
                    stopRecord(); stopAudition(); engine.stop(); playing = false
                    if (didRecord) {
                        performanceMode = null
                        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }
                },
                onInstrument = { instrument = it; activity.midi.selectInstrument(it) }
            )
        } else Column(Modifier.fillMaxSize().background(BG).systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("PHONK", color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp)
                Text(" ZETA", color = GOLD, fontWeight = FontWeight.Black, fontSize = 23.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showHelp = true }) { Text("?", color = GOLD) }
                TextButton(onClick = {
                    showAdvancedTools = !showAdvancedTools
                    if (!showAdvancedTools && tab !in listOf("MI CANCIÓN", "GRABACIONES", "RITMOS"))
                        tab = "MI CANCIÓN"
                }) { Text(if (showAdvancedTools) "FÁCIL" else "ESTUDIO",
                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                TextButton(onClick = { listProjects = store.list(); showProjects = true }) { Text("PROYECTOS", fontSize = 13.sp) }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(observedProject.name, color = MUTED, fontSize = 14.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text("${project.bars} COMPASES", color = GOLD, fontSize = 13.sp)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Button(onClick = {
                    if (recording || countIn > 0) stopRecord()
                    stopAudition(); playing = engine.togglePlay()
                },
                    colors = ButtonDefaults.buttonColors(containerColor = PURPLE),
                    contentPadding = PaddingValues(horizontal = 15.dp)) { Text(if (playing) "Ⅱ PAUSA" else "▶ PLAY", fontSize = 14.sp) }
                Button(onClick = {
                    if (recording || countIn > 0) stopRecord() else beginRecord()
                }, colors = ButtonDefaults.buttonColors(containerColor = if (recording) RED else Color(0xFF8D2743)),
                    contentPadding = PaddingValues(horizontal = 12.dp)) {
                    Text(if (recording) "■ FIN REC" else if (countIn > 0) "$countIn…" else "● REC",
                        color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = { stopRecord(); stopAudition(); engine.stop(); playing = false },
                    contentPadding = PaddingValues(horizontal = 12.dp)) { Text("■", color = Color.White) }
                OutlinedButton(onClick = { checkpoint(); project.bpm = (project.bpm - 1).coerceAtLeast(40); changed() },
                    contentPadding = PaddingValues(horizontal = 8.dp)) { Text("−") }
                Text("${project.bpm} BPM", color = GOLD, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                OutlinedButton(onClick = { checkpoint(); project.bpm = (project.bpm + 1).coerceAtMost(260); changed() },
                    contentPadding = PaddingValues(horizontal = 8.dp)) { Text("+") }
                TextButton(onClick = {
                    checkpoint(); project.metronome = !project.metronome; changed()
                }) { Text("♩", color = if (project.metronome) GOLD else MUTED, fontSize = 19.sp) }
                Text("${displayPosition.first + 1}:${displayPosition.second % 16 + 1}", color = MUTED, fontSize = 14.sp)
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 9.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                (if (showAdvancedTools) TABS else listOf("MI CANCIÓN", "GRABACIONES", "RITMOS"))
                    .forEach { label ->
                    Button(onClick = { tab = label }, modifier = Modifier.height(37.dp),
                        shape = RoundedCornerShape(9.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (label == tab) PURPLE else SURFACE),
                        contentPadding = PaddingValues(horizontal = 11.dp, vertical = 2.dp)) {
                        Text(label, color = if (label == tab) BG else Color.White,
                            fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (tab != "MI CANCIÓN") Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showQuickCreate = true },
                    colors = ButtonDefaults.buttonColors(containerColor = GOLD)) {
                    Text("⚡ CREAR PHONK · DURACIÓN LIBRE", color = BG, fontWeight = FontWeight.Black, fontSize = 15.sp)
                }
                OutlinedButton(onClick = {
                    importBackground.launch(arrayOf("audio/*", "application/octet-stream"))
                }) { Text("+ MP3 / FONDO", color = Color.White, fontSize = 14.sp) }
                OutlinedButton(onClick = {
                    importCompressedSample.launch(arrayOf("audio/*", "application/octet-stream"))
                }) { Text("+ SONIDO", color = Color.White, fontSize = 14.sp) }
            }
            Spacer(Modifier.height(7.dp))
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                when (tab) {
                    "MI CANCIÓN" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionHeading("MI CANCIÓN", "Todo lo que agregas suena junto cuando pulsas ▶ PLAY")
                        Text("1. Añade un sonido  →  2. Toca y graba  →  3. Añade otro sonido  →  4. Escucha todo",
                            color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Button(onClick = {
                            librarySlot = -1; libraryNotice = ""; showInstrumentLibrary = true
                        }, modifier = Modifier.fillMaxWidth().height(62.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GOLD)) {
                            Text("+ AÑADIR INSTRUMENTO", color = BG, fontSize = 18.sp,
                                fontWeight = FontWeight.Black)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { tab = "RITMOS" }, modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = PANEL)) {
                                Text("+ BATERÍA", color = Color.White, fontSize = 15.sp)
                            }
                            Button(onClick = { importBackground.launch(arrayOf("audio/*", "application/octet-stream")) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = PANEL)) {
                                Text("+ MP3 / AUDIO", color = Color.White, fontSize = 15.sp)
                            }
                        }
                        OutlinedButton(onClick = { showQuickCreate = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("⚡ EMPEZAR CON BASE PHONK EDITABLE", color = GOLD,
                                fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("▶ PLAY reproduce tu canción actual; no genera nada nuevo. " +
                            "● REC graba el instrumento que seleccionaste.",
                            color = MUTED, fontSize = 15.sp)
                        val drumUsed = (0 until 4).any { r -> project.steps[r].any { it } ||
                            project.notes.any { it.track == r } }
                        if (drumUsed) {
                            Column(Modifier.fillMaxWidth().background(PANEL, RoundedCornerShape(14.dp))
                                .padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text("🥁 BATERÍA · ritmo de tu canción", color = Color.White,
                                    fontSize = 18.sp, fontWeight = FontWeight.Black)
                                Text("Kick = golpe grave; Snare = golpe seco; Hat = chasquido.",
                                    color = MUTED, fontSize = 14.sp)
                                Button(onClick = { tab = "RITMOS" }, modifier = Modifier.fillMaxWidth()) {
                                    Text("EDITAR GOLPES", color = BG, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        for (lane in 4 until TRACK_COUNT) {
                            if (!project.laneAdded[lane] && laneNoteCounts[lane] == 0) continue
                            val laneNotes = laneNoteCounts[lane]
                            val laneTakes = laneTakeCounts[lane]
                            Column(Modifier.fillMaxWidth().background(PANEL, RoundedCornerShape(14.dp))
                                .padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("${project.laneNames[lane]}", color = Color.White,
                                    fontSize = 19.sp, fontWeight = FontWeight.Black)
                                Text("$laneNotes notas · $laneTakes grabaciones · " +
                                    "sonido: ${TRACK_NAMES[project.instrumentIds[lane]]}",
                                    color = MUTED, fontSize = 15.sp)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Button(onClick = {
                                        engine.allNotesOff(); instrument = lane
                                        if (project.solo.any { it } && !project.solo[lane]) {
                                            checkpoint(); project.solo.fill(false); changed()
                                        }
                                        activity.midi.selectInstrument(lane)
                                        performanceMode = "SMART KEYS"
                                        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    }, modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) {
                                        Text("🎹 TOCAR / REC", color = BG, fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedButton(onClick = {
                                        instrument = lane; librarySlot = lane
                                        libraryNotice = ""; showInstrumentLibrary = true
                                    }, modifier = Modifier.weight(1f)) {
                                        Text("CAMBIAR SONIDO", color = Color.White, fontSize = 13.sp)
                                    }
                                }
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                    OutlinedButton(onClick = {
                                        checkpoint(); project.muted[lane] = !project.muted[lane]; changed()
                                    }, modifier = Modifier.weight(1f)) {
                                        Text(if (project.muted[lane]) "ACTIVAR" else "SILENCIAR",
                                            color = if (project.muted[lane]) GOLD else Color.White, fontSize = 13.sp)
                                    }
                                    OutlinedButton(onClick = {
                                        checkpoint()
                                        val wasSolo = project.solo[lane]
                                        project.solo.fill(false); project.solo[lane] = !wasSolo
                                        changed()
                                        notice = if (project.solo[lane]) "PLAY → solo ${project.laneNames[lane]}"
                                            else "PLAY → toda mi canción"
                                    }, modifier = Modifier.weight(1f)) {
                                        Text(if (project.solo[lane]) "TODAS" else "▶ SOLO",
                                            color = if (project.solo[lane]) GOLD else Color.White, fontSize = 13.sp)
                                    }
                                    Text("${(project.volumes[lane] * 100).toInt()}%", color = GOLD,
                                        fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                                Slider(value = project.volumes[lane].toFloat(),
                                    onValueChange = { project.volumes[lane] = it.toDouble(); revision++ },
                                    onValueChangeFinished = { changed() })
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = {
                                        instrument = lane; selectedNote = null
                                    showAdvancedTools = true; tab = "PIANO ROLL"
                                    }, modifier = Modifier.weight(1f)) {
                                        Text("EDITAR MIS NOTAS", color = Color.White, fontSize = 13.sp)
                                    }
                                    TextButton(onClick = { pendingTrackDelete = lane },
                                        modifier = Modifier.weight(1f)) {
                                        Text("BORRAR PISTA", color = Color(0xFFFFB3C3), fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                        if (project.backgroundName.isNotBlank()) {
                            Column(Modifier.fillMaxWidth().background(PANEL, RoundedCornerShape(14.dp)).padding(12.dp)) {
                                Text("🎵 AUDIO IMPORTADO", color = Color.White,
                                    fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("Suena junto a las demás pistas en PLAY. " +
                                    "Es un archivo completo, no sus instrumentos separados.", color = MUTED)
                                Text(project.backgroundName, color = GOLD, fontSize = 14.sp)
                                OutlinedButton(onClick = { tab = "MIXER" }) {
                                    Text("AJUSTAR VOLUMEN / QUITAR", color = Color.White)
                                }
                            }
                        }
                        Button(onClick = { tab = "GRABACIONES" }, modifier = Modifier.fillMaxWidth()) {
                            Text("MIS GRABACIONES (${project.takes.size}) · ESCUCHAR SOLAS",
                                fontSize = 15.sp, color = BG, fontWeight = FontWeight.Bold)
                        }
                        Text("¿Quieres una canción más larga? TRACKS → + COMPASES. " +
                            "¿Quieres guardar el audio final? WAV o M4A abajo.", color = MUTED,
                            fontSize = 14.sp)
                    }
                    "INICIO" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionHeading("CREA TU PRIMER PHONK", "No necesitas saber música · sigue estos 4 pasos")
                        Button(onClick = { showQuickCreate = true },
                            modifier = Modifier.fillMaxWidth().height(65.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GOLD)) {
                            Text("1 · ELEGIR BASE PHONK", color = BG, fontSize = 18.sp, fontWeight = FontWeight.Black)
                        }
                        Text("2 · ESCUCHAR BASE · pulsa PLAY arriba. Puedes importar tu MP3 propio.",
                            color = Color.White, fontSize = 16.sp)
                        Button(onClick = {
                            performanceMode = "SMART KEYS"
                            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        }, modifier = Modifier.fillMaxWidth().height(65.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) {
                            Text("3 · TOCAR Y GRABAR · CELULAR DE COSTADO", color = BG,
                                fontSize = 16.sp, fontWeight = FontWeight.Black)
                        }
                        Button(onClick = { tab = "GRABACIONES" },
                            modifier = Modifier.fillMaxWidth().height(65.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF227C59))) {
                            Text("4 · ESCUCHAR MIS GRABACIONES (${project.takes.size})",
                                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        }
                        Text("REC → cuenta 3, 2, 1 → toca → FIN REC → GRABACIONES → ESCUCHAR SOLO.",
                            color = GOLD, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        HorizontalDivider(color = PANEL)
                        SectionHeading("DURACIÓN LIBRE", "Amplía tu canción desde TRACKS → COMPASES. No hay obligación de 30/60 s.")
                        Text("Actual: ${project.bars} compases · aproximadamente ${(project.bars * 240.0 / project.bpm).roundToInt()} s · " +
                            "máximo técnico de esta versión: $BAR_LIMIT compases.",
                            color = Color.White, fontSize = 15.sp)
                        Button(onClick = { tab = "MI CANCIÓN" }, modifier = Modifier.fillMaxWidth()) {
                            Text("ABRIR MI CANCIÓN", color = BG, fontSize = 16.sp)
                        }
                    }
                    "GRABACIONES" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionHeading("MIS GRABACIONES", "Cada interpretación se guarda dentro del proyecto")
                        Text("▶ SOLO reproduce tu toma sin batería, bajo ni MP3. " +
                            "■ STOP vuelve a la canción completa.", color = Color.White, fontSize = 16.sp)
                        if (project.takes.isEmpty()) {
                            Text("Aún no hay grabaciones. Abre PIANO o PADS → REC → toca → FIN REC.",
                                color = GOLD, fontSize = 17.sp)
                        }
                        project.takes.asReversed().forEach { take ->
                            Column(Modifier.fillMaxWidth().background(PANEL, RoundedCornerShape(13.dp))
                                .padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text(take.name, color = Color.White, fontSize = 18.sp,
                                    fontWeight = FontWeight.Black)
                                Text("${take.notes.size} notas · instrumentos: " +
                                    take.notes.map { project.laneNames[it.track] }.distinct().joinToString(),
                                    color = MUTED, fontSize = 15.sp)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { audition(take) }, modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF227C59))) {
                                        Text("▶ SOLO", color = Color.White, fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedButton(onClick = {
                                        stopAudition(); engine.stop(); playing = false; notice = "Escucha detenida"
                                    }, modifier = Modifier.weight(1f)) { Text("■ STOP", color = Color.White, fontSize = 16.sp) }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        instrument = take.notes.firstOrNull()?.track ?: instrument
                                        tab = "PIANO ROLL"
                                    }) {
                                        Text("EDITAR", color = Color.White)
                                    }
                                    OutlinedButton(onClick = {
                                        instrument = take.notes.firstOrNull()?.track ?: 6
                                        activity.midi.selectInstrument(instrument)
                                        performanceMode = if (instrument < 4) "PADS" else "SMART KEYS"
                                        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    }) { Text("REGRABAR", color = Color.White) }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        renameTakeId = take.id; renameTakeValue = take.name
                                    }) { Text("RENOMBRAR", color = Color.White) }
                                    OutlinedButton(onClick = { pendingTakeDelete = take.id }) {
                                        Text("BORRAR TOMA", color = Color(0xFFFF8EA4))
                                    }
                                }
                            }
                        }
                    }
                    "PIANO" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        SectionHeading("INSTRUMENTO", "Abre el modo horizontal para tocar teclas GRANDES")
                        Button(onClick = {
                            performanceMode = "PIANO"
                            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        }, modifier = Modifier.fillMaxWidth().height(55.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GOLD)) {
                            Text("🎹 PIANO GIGANTE · GIRAR CELULAR", color = BG,
                                fontSize = 15.sp, fontWeight = FontWeight.Black)
                        }
                        Button(onClick = {
                            performanceMode = "SMART KEYS"
                            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        }, modifier = Modifier.fillMaxWidth().height(53.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) {
                            Text("MODO FÁCIL · 8 TECLAS GRANDES", fontSize = 15.sp)
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (4 until TRACK_COUNT).forEach { idx ->
                                SelectPill(project.laneNames[idx], instrument == idx) {
                                    engine.allNotesOff(); instrument = idx; activity.midi.selectInstrument(idx)
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { octave = (octave - 1).coerceAtLeast(1) }) { Text("OCT −") }
                            Text(" OCTAVA $octave ", color = GOLD, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            OutlinedButton(onClick = { octave = (octave + 1).coerceAtMost(7) }) { Text("OCT +") }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("LIBRE", "MAYOR", "MENOR").forEachIndexed { i, label ->
                                SelectPill("ESC. $label", scaleMode == i) { scaleMode = i }
                            }
                            SelectPill("TONO: ${LABEL_NOTES[rootNote]}", false) { rootNote = (rootNote + 1) % 12 }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("UNA NOTA", "ACORDE MAYOR", "ACORDE MENOR", "SÉPTIMA").forEachIndexed { i, label ->
                                SelectPill(label, chordMode == i) { chordMode = i }
                            }
                        }
                        Text("FUERZA ${(playVelocity * 100).toInt()}%", color = MUTED, fontSize = 13.sp)
                        Slider(value = playVelocity, onValueChange = { playVelocity = it }, valueRange = .1f..1f)
                        PianoView(engine, instrument, octave, chordMode, scaleMode, rootNote, playVelocity,
                            Modifier.fillMaxWidth().height(
                            if (LocalConfiguration.current.screenWidthDp > 600) 300.dp else 215.dp))
                        Text("REC captura duración y posición de cada nota. Las notas se editan en PIANO ROLL.",
                            color = MUTED, fontSize = 14.sp)
                        if (project.instrumentIds[instrument] == 15) {
                            Text("SAMPLER · ${project.samplerName.ifBlank { "Importa tu propio WAV" }}", color = GOLD)
                            OutlinedButton(onClick = {
                                checkpoint(); project.samplerOneShot = !project.samplerOneShot; changed()
                            }) { Text(if (project.samplerOneShot) "MODO ONE-SHOT · tocar completo"
                                     else "MODO SUSTAIN · soltar detiene") }
                            Button(onClick = { showKit = true }) { Text("BIBLIOTECA DE 24 SONIDOS ORIGINALES") }
                            Button(onClick = { importSample.launch(arrayOf("audio/wav", "audio/x-wav", "application/octet-stream")) }) {
                                Text("IMPORTAR MUESTRA WAV")
                            }
                        }
                        OutlinedButton(onClick = {
                            activity.midi.onStatus = { midiStatus = it }
                            activity.midi.connect()
                            notice = midiStatus
                        }) { Text("CONECTAR TECLADO MIDI USB / BLUETOOTH") }
                        Text(midiStatus, color = MUTED, fontSize = 13.sp)
                        Text("Para tocar en tiempo real, es preferible usar auriculares con cable.", color = MUTED, fontSize = 13.sp)
                    }
                    "PADS" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        SectionHeading("DRUM PADS 4 × 4", "Pulsa para abrir pads GRANDES de lado")
                        Button(onClick = {
                            performanceMode = "PADS"
                            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        }, modifier = Modifier.fillMaxWidth().height(57.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GOLD)) {
                            Text("ABRIR 16 PADS GIGANTES · HORIZONTAL", color = BG,
                                fontSize = 15.sp, fontWeight = FontWeight.Black)
                        }
                        val pads = listOf(0, 1, 2, 3, 0, 2, 1, 3, 6, 5, 4, 7, 0, 1, 2, 3)
                        for (r in 0..3) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                for (c in 0..3) {
                                    val track = pads[r * 4 + c]
                                    Box(Modifier.weight(1f).padding(vertical = 5.dp).height(80.dp)
                                        .background(if (track == 0) RED.copy(alpha = .22f) else SURFACE, RoundedCornerShape(12.dp))
                                        .border(1.dp, if (track == 0) RED else PURPLE.copy(alpha = .7f), RoundedCornerShape(12.dp))
                                        .pointerInput(track) {
                                            awaitEachGesture {
                                                val down = awaitPointerEvent()
                                                val pitch = if (track < 4) intArrayOf(36, 38, 42, 39)[track] else 60
                                                if (down.changes.any { it.pressed }) engine.noteOn(track, pitch)
                                                do { val e = awaitPointerEvent() } while (e.changes.any { it.pressed })
                                                engine.noteOff(track, pitch)
                                            }
                                        }, contentAlignment = Alignment.Center) {
                                        Text(TRACK_NAMES[track], fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        Text("Puedes grabar los pads con REC; sus golpes aparecerán como notas editables.", color = MUTED, fontSize = 14.sp)
                    }
                    "RITMOS" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionHeading("STEP SEQUENCER", "Patrones editables · 16, 32 o 64 pasos")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf(16, 32, 64).forEach { length ->
                                SelectPill("$length PASOS", project.patternLength == length) {
                                    checkpoint(); project.patternLength = length; changed()
                                }
                            }
                        }
                        Text("Página ${page + 1} / ${project.patternLength / 16}", color = GOLD, fontSize = 14.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { page = (page - 1).coerceAtLeast(0) }) { Text("◀") }
                            OutlinedButton(onClick = { page = (page + 1).coerceAtMost(project.patternLength / 16 - 1) }) { Text("▶") }
                            OutlinedButton(onClick = { listPatterns = store.listPatterns(); showPatterns = true }) { Text("MIS RITMOS") }
                        }
                        for (r in 0..3) {
                            Text(TRACK_NAMES[r], color = if (r == 0) RED else GOLD, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                for (col in 0 until 16) {
                                    val step = page * 16 + col
                                    val checked = project.steps[r][step]
                                    Box(Modifier.weight(1f).height(40.dp).padding(vertical = 2.dp)
                                        .background(if (playing && displayPosition.second == step) GOLD
                                            else if (checked) (if (r == 0) RED else PURPLE) else PANEL,
                                            RoundedCornerShape(4.dp))
                                        .clickable {
                                            checkpoint(); project.steps[r][step] = !project.steps[r][step]
                                            selectedDrum = r; selectedStep = step; changed()
                                        }, contentAlignment = Alignment.Center) {
                                        if (col % 4 == 0) Text("·", color = Color.White.copy(alpha = .45f))
                                    }
                                }
                            }
                        }
                        if (selectedStep >= 0) {
                            Text("${TRACK_NAMES[selectedDrum]} · paso ${selectedStep + 1} · fuerza ${(project.velocity[selectedDrum][selectedStep] * 100).toInt()}%",
                                color = GOLD, fontSize = 14.sp)
                            Slider(value = project.velocity[selectedDrum][selectedStep].toFloat(),
                                onValueChange = { project.velocity[selectedDrum][selectedStep] = it.toDouble(); revision++ },
                                onValueChangeFinished = { changed() })
                        }
                        Text("SWING ${(project.swing * 100).toInt()}%", color = MUTED, fontSize = 14.sp)
                        Slider(value = project.swing.toFloat(), valueRange = 0f..0.75f,
                            onValueChange = { project.swing = it.toDouble(); revision++ }, onValueChangeFinished = { changed() })
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = {
                                checkpoint(); project.steps.forEach { it.fill(false) }; changed()
                            }) { Text("LIMPIAR") }
                            Button(onClick = {
                                checkpoint(); project.steps.forEach { it.fill(false) }
                                listOf(0, 6, 8, 14).forEach { project.steps[0][it] = true }
                                listOf(4, 12).forEach { project.steps[1][it] = true }
                                for (i in 0..15 step 2) project.steps[2][i] = true
                                changed()
                            }) { Text("RITMO PHONK") }
                            Button(onClick = {
                                checkpoint()
                                val rng = kotlin.random.Random(System.currentTimeMillis())
                                for (row in 0..3) project.steps[row].fill(false)
                                for (s in 0 until project.patternLength) {
                                    val beat = s % 16
                                    project.steps[0][s] = beat in listOf(0, 7, 8, 14) || (beat == 3 && rng.nextBoolean())
                                    project.steps[1][s] = beat == 4 || beat == 12
                                    project.steps[2][s] = s % 2 == 0 || rng.nextInt(12) == 0
                                    project.steps[3][s] = (beat == 12 && rng.nextBoolean())
                                }
                                project.notes.removeAll { it.track in listOf(5, 6) && it.start < 4.0 }
                                listOf(0.0, 1.5, 2.0, 3.5).forEachIndexed { i, start ->
                                    project.notes.add(MusicNote(5, listOf(36, 39, 43, 34)[i], start, .43))
                                }
                                listOf(0.0, .5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5).forEachIndexed { i, start ->
                                    project.notes.add(MusicNote(6, listOf(60, 63, 67, 65, 60, 58, 55, 58)[i], start, .3))
                                }
                                changed(); notice = "Ritmo, cowbell y bajo generados; todo editable"
                            }) { Text("GENERAR PHONK") }
                        }
                    }
                    "PIANO ROLL" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        SectionHeading("PIANO ROLL", "Notas editables: toca cuadrícula para crear o seleccionar")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            (4 until TRACK_COUNT).forEach { idx ->
                                SelectPill(project.laneNames[idx], instrument == idx) { instrument = idx; activity.midi.selectInstrument(idx); selectedNote = null }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { noteBar = (noteBar - 1).coerceAtLeast(0) }) { Text("◀") }
                            Text(" COMPÁS ${noteBar + 1}/${project.bars} ", color = GOLD, fontSize = 14.sp)
                            OutlinedButton(onClick = { noteBar = (noteBar + 1).coerceAtMost(project.bars - 1) }) { Text("▶") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { noteOctave = (noteOctave - 1).coerceAtLeast(1) }) { Text("OCT −") }
                            Text("  $noteOctave  ", color = GOLD)
                            OutlinedButton(onClick = { noteOctave = (noteOctave + 1).coerceAtMost(7) }) { Text("OCT +") }
                            Text("  ${project.notes.size} notas", color = MUTED, fontSize = 13.sp)
                        }
                        PianoRoll(project, instrument, noteBar, noteOctave, selectedNote,
                            onTap = { pitch, beat ->
                                val found = project.notes.lastOrNull { it.track == instrument &&
                                    pitch == it.pitch && beat >= it.start && beat < it.start + it.length }
                                if (found != null) selectedNote = found else {
                                    checkpoint()
                                    val n = MusicNote(instrument, pitch, beat, noteLength.toDouble())
                                    project.notes.add(n); selectedNote = n; changed()
                                }
                            }, modifier = Modifier.fillMaxWidth().height(436.dp))
                        Text("Duración de nueva nota: ${"%.2f".format(noteLength)} pulsos", color = MUTED, fontSize = 13.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(.125f, .25f, .5f, 1f, 2f, 4f).forEach { v ->
                                SelectPill("${v}×", abs(noteLength - v) < .001f) { noteLength = v }
                            }
                        }
                        selectedNote?.takeIf { project.notes.contains(it) }?.let { n ->
                            Text("SELECCIONADA: ${LABEL_NOTES[n.pitch % 12]}${n.pitch / 12 - 1} · pulso ${"%.2f".format(n.start)}",
                                color = GOLD, fontSize = 14.sp)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                OutlinedButton(onClick = {
                                    checkpoint(); val newer = n.copy(pitch = (n.pitch - 1).coerceAtLeast(0))
                                    project.notes[project.notes.indexOf(n)] = newer; selectedNote = newer; changed()
                                }) { Text("− NOTA") }
                                OutlinedButton(onClick = {
                                    checkpoint(); val newer = n.copy(pitch = (n.pitch + 1).coerceAtMost(127))
                                    project.notes[project.notes.indexOf(n)] = newer; selectedNote = newer; changed()
                                }) { Text("+ NOTA") }
                                OutlinedButton(onClick = {
                                    checkpoint(); val newer = n.copy(start = (n.start - .25).coerceAtLeast(0.0))
                                    project.notes[project.notes.indexOf(n)] = newer; selectedNote = newer; changed()
                                }) { Text("←") }
                                OutlinedButton(onClick = {
                                    checkpoint(); val newer = n.copy(start = (n.start + .25).coerceAtMost(project.bars * 4.0 - .01))
                                    project.notes[project.notes.indexOf(n)] = newer; selectedNote = newer; changed()
                                }) { Text("→") }
                            }
                            Text("LARGO ${"%.2f".format(n.length)} · FUERZA ${(n.velocity * 100).toInt()}%", color = MUTED, fontSize = 14.sp)
                            Slider(value = n.length.toFloat().coerceIn(.125f, 4f), valueRange = .125f..4f,
                                onValueChange = { v ->
                                    val ix = project.notes.indexOf(n)
                                    if (ix >= 0) { val updated = project.notes[ix].copy(length = v.toDouble()); project.notes[ix] = updated; selectedNote = updated; revision++ }
                                }, onValueChangeFinished = { changed() })
                            Slider(value = n.velocity.toFloat(), onValueChange = { v ->
                                val ix = project.notes.indexOf(n)
                                if (ix >= 0) { val updated = project.notes[ix].copy(velocity = v.toDouble()); project.notes[ix] = updated; selectedNote = updated; revision++ }
                            }, onValueChangeFinished = { changed() })
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                OutlinedButton(onClick = {
                                    checkpoint(); project.notes.add(n.copy(start = (n.start + .5).coerceAtMost(project.bars * 4.0 - .01)))
                                    changed()
                                }) { Text("DUPLICAR") }
                                OutlinedButton(onClick = {
                                    checkpoint(); project.notes.remove(n); selectedNote = null; changed()
                                }) { Text("ELIMINAR", color = RED) }
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            OutlinedButton(onClick = {
                                checkpoint(); val snap = project.notes.toList()
                                project.notes.clear(); project.notes.addAll(snap.map { n ->
                                    if (n.track == instrument) n.copy(start = (round(n.start * 4) / 4.0).coerceAtMost(project.bars * 4.0 - .01)) else n
                                }); selectedNote = null; changed()
                            }) { Text("CUANTIZAR 1/16") }
                            OutlinedButton(onClick = {
                                checkpoint(); project.notes.removeAll { it.track == instrument && (it.start / 4).toInt() == noteBar }
                                selectedNote = null; changed()
                            }) { Text("VACIAR COMPÁS") }
                        }
                    }
                    "TRACKS" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionHeading("ARREGLO MUSICAL", "Activa o silencia cada instrumento por compás")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { page = (page - 1).coerceAtLeast(0) }) { Text("◀") }
                            Text(" COMPASES ${page * 8 + 1}–${min(project.bars, page * 8 + 8)} ", color = GOLD, fontSize = 14.sp)
                            OutlinedButton(onClick = { page = (page + 1).coerceAtMost((project.bars - 1) / 8) }) { Text("▶") }
                        }
                        SectionHeading("DURACIÓN DE MI CANCIÓN", "Aumenta compases cuando quieras, sin límite de 30 o 60 segundos")
                        Text("${project.bars} compases · aprox. ${(project.bars * 240.0 / project.bpm).roundToInt()} segundos",
                            color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Row(Modifier.horizontalScroll(rememberScrollState()),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                checkpoint(); project.bars = (project.bars - 1).coerceAtLeast(1); changed()
                            }) { Text("− 1", color = Color.White) }
                            OutlinedButton(onClick = {
                                checkpoint(); project.bars = (project.bars + 1).coerceAtMost(BAR_LIMIT); changed()
                            }) { Text("+ 1", color = Color.White) }
                            Button(onClick = {
                                checkpoint(); project.bars = (project.bars + 8).coerceAtMost(BAR_LIMIT); changed()
                            }) { Text("+ 8", color = BG, fontWeight = FontWeight.Bold) }
                            Button(onClick = {
                                checkpoint(); project.bars = (project.bars + 32).coerceAtMost(BAR_LIMIT); changed()
                            }) { Text("+ 32", color = BG, fontWeight = FontWeight.Bold) }
                        }
                        for (track in 0 until TRACK_COUNT) {
                            Text(project.laneNames[track], color = if (track < 4) GOLD else Color.White, fontSize = 13.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                for (bar in page * 8 until min(project.bars, page * 8 + 8)) {
                                    Box(Modifier.weight(1f).height(33.dp)
                                        .background(if (playing && displayPosition.first == bar) GOLD.copy(alpha = .70f)
                                            else if (project.arrangement[track][bar]) PURPLE.copy(alpha = .85f) else PANEL,
                                            RoundedCornerShape(6.dp))
                                        .clickable {
                                            checkpoint(); project.arrangement[track][bar] = !project.arrangement[track][bar]; changed()
                                        }, contentAlignment = Alignment.Center) {
                                        Text("${bar + 1}", fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                        Text("Ritmos: se repiten según 16/32/64 pasos. Melodías: se graban en su compás correspondiente.",
                            color = MUTED, fontSize = 14.sp)
                    }
                    "MIXER" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        SectionHeading("AUDIO IMPORTADO", "El fondo suena en PLAY y queda incluido al exportar WAV")
                        Text(if (project.backgroundName.isBlank()) "Sin fondo todavía" else "Fondo: ${project.backgroundName}",
                            color = Color.White, fontSize = 14.sp)
                        Button(onClick = { importBackground.launch(arrayOf("audio/*", "application/octet-stream")) }) {
                            Text("IMPORTAR MP3 / WAV / M4A / FLAC")
                        }
                        Text("VOLUMEN DE FONDO ${(project.backgroundGain * 100).toInt()}%", color = GOLD)
                        Slider(value = project.backgroundGain.toFloat(),
                            onValueChange = { project.backgroundGain = it.toDouble(); revision++ },
                            onValueChangeFinished = { changed() })
                        OutlinedButton(onClick = {
                            checkpoint(); project.backgroundName = ""; engine.setBackground(null); changed()
                        }) { Text("QUITAR FONDO") }
                        HorizontalDivider(color = PANEL)
                        SectionHeading("MIXER · 16 CANALES", "Volumen, estéreo, mute y solo")
                        for (i in 0 until TRACK_COUNT) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(project.laneNames[i], modifier = Modifier.weight(1f), fontSize = 13.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${(project.volumes[i] * 100).toInt()}%", color = GOLD, fontSize = 13.sp)
                                TextButton(onClick = { checkpoint(); project.muted[i] = !project.muted[i]; changed() }) {
                                    Text("M", color = if (project.muted[i]) RED else MUTED)
                                }
                                TextButton(onClick = { checkpoint(); project.solo[i] = !project.solo[i]; changed() }) {
                                    Text("S", color = if (project.solo[i]) GOLD else MUTED)
                                }
                            }
                            Slider(value = project.volumes[i].toFloat(), onValueChange = { project.volumes[i] = it.toDouble(); revision++ },
                                onValueChangeFinished = { changed() })
                            Text("PAN: ${(project.pans[i] * 100).toInt()}", color = MUTED, fontSize = 13.sp)
                            Slider(value = project.pans[i].toFloat(), valueRange = -1f..1f,
                                onValueChange = { project.pans[i] = it.toDouble(); revision++ },
                                onValueChangeFinished = { changed() })
                            HorizontalDivider(color = PANEL)
                        }
                    }
                    "FX" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeading("MASTER FX", "Efectos DSP integrados en la reproducción y WAV")
                        Text("SATURACIÓN / DRIVE ${(project.drive * 100).toInt()}%", color = GOLD)
                        Slider(value = project.drive.toFloat(), onValueChange = { project.drive = it.toDouble(); revision++ },
                            onValueChangeFinished = { changed() })
                        Text("DELAY ${(project.delay * 100).toInt()}%", color = GOLD)
                        Slider(value = project.delay.toFloat(), onValueChange = { project.delay = it.toDouble(); revision++ },
                            onValueChangeFinished = { changed() })
                        Text("La saturación y el delay se procesan directamente sobre ambos canales. No se incluyen efectos que no funcionen.",
                            color = MUTED, fontSize = 14.sp)
                        HorizontalDivider(color = PANEL)
                        SectionHeading("GRABACIÓN DE AUDIO", "Micrófono → muestra WAV → sampler")
                        Button(onClick = {
                            if (!micRecording) {
                                if (activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    try { activity.micRecorder.start(); micRecording = true; notice = "Grabando micrófono…" }
                                    catch (e: Exception) { notice = "Error: ${e.message}" }
                                } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                val file = activity.micRecorder.stop(); micRecording = false; micFile = file
                                notice = "Grabación guardada: ${file?.name ?: "error"}"
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = if (micRecording) RED else PURPLE)) {
                            Text(if (micRecording) "■ DETENER MICRÓFONO" else "● GRABAR MICRÓFONO")
                        }
                        micFile?.let { f ->
                            Button(onClick = { scope.launch {
                                try {
                                    val snd = withContext(Dispatchers.IO) { store.importSample(f.inputStream()) }
                                    checkpoint(); project.samplerName = snd.filename; engine.setSample(snd)
                                    instrument = 15; activity.midi.selectInstrument(15); tab = "PIANO"; changed(); notice = "Audio importado al SAMPLER"
                                } catch (e: Exception) { notice = "Error leyendo audio: ${e.message}" }
                            } }) { Text("USAR GRABACIÓN COMO INSTRUMENTO") }
                        }
                        Button(onClick = { showKit = true }) { Text("BIBLIOTECA ORIGINAL · 24 SONIDOS") }
                        Button(onClick = { importSample.launch(arrayOf("audio/wav", "audio/x-wav", "application/octet-stream")) }) {
                            Text("IMPORTAR WAV PROPIO")
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(notice, modifier = Modifier.weight(1f), color = GOLD, fontSize = 13.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = {
                    if (undo.isNotEmpty()) {
                        redo.addLast(project.toJson().toString())
                        newProject(ZetaProject.fromJson(org.json.JSONObject(undo.removeLast())), resetHistory = false)
                        notice = "Deshacer"
                    }
                }, enabled = undo.isNotEmpty()) { Text("↶", fontSize = 20.sp) }
                TextButton(onClick = {
                    if (redo.isNotEmpty()) {
                        undo.addLast(project.toJson().toString())
                        newProject(ZetaProject.fromJson(org.json.JSONObject(redo.removeLast())), resetHistory = false)
                        notice = "Rehacer"
                    }
                }, enabled = redo.isNotEmpty()) { Text("↷", fontSize = 20.sp) }
            }
            if (exportProgress >= 0) LinearProgressIndicator(progress = { exportProgress / 100f }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { saveNow() }, enabled = !saving, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3D4257))) {
                        Text("GUARDAR", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                Button(onClick = { exportWav.launch("${project.name.take(40)}.wav") },
                    enabled = exportProgress < 0, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) {
                        Text("WAV", color = BG, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                Button(onClick = { exportM4a.launch("${project.name.take(40)}.m4a") },
                    enabled = exportProgress < 0, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF28684C))) {
                    Text("M4A", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (showQuickCreate) AlertDialog(onDismissRequest = { showQuickCreate = false },
            title = { Text("CREAR PHONK · DURACIÓN LIBRE") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Elige un estilo. La app crea batería, 808 y melodía originales y editables.",
                        color = Color.White, fontSize = 15.sp)
                    EasyPhonk.styles.forEach { style ->
                        SelectPill(if (style == "SLOWED") "SLOWED / LENTO" else style,
                            quickStyle == style) { quickStyle = style }
                    }
                    OutlinedTextField(value = quickBarsInput,
                        onValueChange = { quickBarsInput = it.filter(Char::isDigit).take(4) },
                        singleLine = true, label = { Text("Compases (2 a $BAR_LIMIT)") },
                        supportingText = { Text("1 compás = cuatro pulsos; podrás ampliar en TRACKS") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Text("La base es editable. Puedes continuar añadiendo pistas y compases.",
                        color = Color.White, fontSize = 15.sp)
                    Text("Después: PLAY → PIANO GIGANTE → REC → toca → GRABACIONES.",
                        color = GOLD, fontSize = 14.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val bars = quickBarsInput.toIntOrNull()
                    if (bars == null || bars !in 2..BAR_LIMIT) {
                        notice = "Escribe una duración de 2 a $BAR_LIMIT compases"
                    } else {
                        val created = ZetaProject()
                        EasyPhonk.generate(created, quickStyle, bars)
                        newProject(created)
                        showQuickCreate = false
                        tab = "MI CANCIÓN"
                        notice = "Base creada: $bars compases · PLAY para escuchar · REC para grabar"
                    }
                }) { Text("GENERAR BASE", color = GOLD, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showQuickCreate = false }) { Text("CANCELAR") }
            })
        if (showInstrumentLibrary) AlertDialog(
            onDismissRequest = { engine.stopPreview(); showInstrumentLibrary = false },
            title = { Text(if (librarySlot < 0) "AÑADIR UN SONIDO" else "CAMBIAR EL SONIDO", fontSize = 20.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Pulsa ▶ para escuchar; AÑADIR abre las teclas grandes. " +
                        "Puedes añadir otro piano, otro bajo u otra campana. CAMBIAR SONIDO " +
                        "conserva las notas y cambia cómo suenan.",
                        color = Color.White, fontSize = 15.sp)
                    if (librarySlot < 0 && (4 until TRACK_COUNT).none { lane ->
                        !project.laneAdded[lane] && project.notes.none { it.track == lane }
                    }) Text("Todas las 12 pistas melódicas están ocupadas. Cambia " +
                        "el sonido desde una pista de MI CANCIÓN.", color = GOLD)
                    if (libraryNotice.isNotBlank()) Text(libraryNotice, color = GOLD, fontSize = 14.sp)
                    OutlinedButton(onClick = {
                        engine.stopPreview(); showInstrumentLibrary = false
                        importCompressedSample.launch(arrayOf("audio/*", "application/octet-stream"))
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text("+ IMPORTAR MI PROPIO MP3 / WAV", color = Color.White, fontSize = 14.sp)
                    }
                    val descriptions = listOf("PIANO SUAVE", "BAJO 808", "CAMPANA PHONK",
                        "SINTETIZADOR", "MELODÍA BRILLANTE", "CAMPANAS", "AMBIENTE",
                        "SUBGRAVE", "ÓRGANO", "CUERDAS PULSADAS", "CUERDAS", "MI SAMPLE")
                    LazyColumn(Modifier.heightIn(max = 380.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items((4 until TRACK_COUNT).toList()) { sound ->
                            Row(Modifier.fillMaxWidth().background(PANEL, RoundedCornerShape(11.dp))
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(descriptions[sound - 4], modifier = Modifier.weight(1f),
                                    color = Color.White, fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold)
                                OutlinedButton(onClick = {
                                    engine.previewSound(sound, if (sound in listOf(5, 11)) 36 else 60)
                                    scope.launch { delay(700); engine.stopPreview() }
                                }, contentPadding = PaddingValues(horizontal = 9.dp)) {
                                    Text("▶", color = Color.White, fontSize = 17.sp)
                                }
                                Button(onClick = {
                                    val destination = if (librarySlot in 4 until TRACK_COUNT) librarySlot
                                        else (4 until TRACK_COUNT).firstOrNull { lane ->
                                            !project.laneAdded[lane] && project.notes.none { it.track == lane }
                                        } ?: -1
                                    if (destination < 0) {
                                        libraryNotice = "No quedan pistas libres. Selecciona una existente."
                                    } else {
                                        engine.stopPreview(); checkpoint()
                                        project.instrumentIds[destination] = sound
                                        val repeated = (4 until TRACK_COUNT).count { lane ->
                                            lane != destination && (project.laneAdded[lane] ||
                                                project.notes.any { it.track == lane }) &&
                                                project.instrumentIds[lane] == sound
                                        }
                                        project.laneNames[destination] =
                                            descriptions[sound - 4] + if (repeated > 0) " ${repeated + 1}" else ""
                                        project.laneAdded[destination] = true
                                        project.muted[destination] = false
                                        project.solo.fill(false)
                                        instrument = destination
                                        activity.midi.selectInstrument(destination)
                                        changed(); showInstrumentLibrary = false
                                        notice = "${project.laneNames[destination]} listo. TOCA y pulsa REC."
                                        tab = "MI CANCIÓN"
                                        if (sound == 15 && project.samplerName.isBlank()) {
                                            notice = "Importa un WAV/MP3 desde + SONIDO para escuchar tu sampler."
                                        } else {
                                            performanceMode = "SMART KEYS"
                                            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                        }
                                    }
                                }, contentPadding = PaddingValues(horizontal = 10.dp)) {
                                    Text("AÑADIR", color = BG, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }, confirmButton = {
                TextButton(onClick = { engine.stopPreview(); showInstrumentLibrary = false }) {
                    Text("VOLVER A MI CANCIÓN", color = GOLD)
                }
            })
        if (pendingTrackDelete in 4 until TRACK_COUNT) {
            val lane = pendingTrackDelete
            AlertDialog(onDismissRequest = { pendingTrackDelete = -1 },
                title = { Text("¿BORRAR ${project.laneNames[lane]}?") },
                text = { Text("Se eliminarán las notas y grabaciones de esta pista; " +
                    "puedes DESHACER desde la pantalla principal si cambias de idea.") },
                confirmButton = { TextButton(onClick = {
                    stopAudition(); checkpoint()
                    project.notes.removeAll { it.track == lane }
                    project.takes.removeAll { t -> t.notes.any { it.track == lane } }
                    project.laneAdded[lane] = false
                    project.instrumentIds[lane] = lane
                    project.laneNames[lane] = TRACK_NAMES[lane]
                    project.muted[lane] = false; project.solo[lane] = false
                    if (instrument == lane) instrument = 6
                    changed(); pendingTrackDelete = -1
                }) { Text("BORRAR PISTA", color = RED) } },
                dismissButton = { TextButton(onClick = { pendingTrackDelete = -1 }) {
                    Text("CANCELAR", color = Color.White)
                } })
        }
        if (showProjects) AlertDialog(onDismissRequest = { showProjects = false },
            title = { Text("MIS PROYECTOS") }, text = {
                Column {
                    OutlinedTextField(value = nameInput, onValueChange = { nameInput = it.take(60) },
                        label = { Text("Nombre") }, singleLine = true)
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        TextButton(onClick = {
                            checkpoint(); project.name = nameInput.ifBlank { "Mi PHONK" }; saveNow(); showProjects = false
                        }) { Text("RENOMBRAR Y GUARDAR") }
                        TextButton(onClick = {
                            val title = "Proyecto " + java.text.SimpleDateFormat("ddMMyy_HHmmss", java.util.Locale.getDefault())
                                .format(java.util.Date())
                            newProject(ZetaProject(name = title)); showProjects = false
                        }) { Text("NUEVO") }
                    }
                    TextButton(onClick = { exportProject.launch("${project.name}.phonkproj") }) { Text("EXPORTAR PROYECTO") }
                    TextButton(onClick = { importProject.launch(arrayOf("application/json", "application/octet-stream", "*/*")) }) {
                        Text("IMPORTAR PROYECTO")
                    }
                    HorizontalDivider(color = PANEL)
                    LazyColumn(Modifier.heightIn(max = 270.dp)) {
                        items(listProjects) { n ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = {
                                    try { newProject(store.load(n)); showProjects = false; notice = "Abierto $n" }
                                    catch (e: Exception) { notice = "Error: ${e.message}" }
                                }, modifier = Modifier.weight(1f)) {
                                    Text(n, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                TextButton(onClick = {
                                    if (n != "autosave") pendingDelete = n
                                }) { Text("✕", color = RED) }
                            }
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showProjects = false }) { Text("CERRAR") } })
        renameTakeId?.let { target ->
            AlertDialog(onDismissRequest = { renameTakeId = null },
                title = { Text("RENOMBRAR GRABACIÓN") },
                text = { OutlinedTextField(value = renameTakeValue,
                    onValueChange = { renameTakeValue = it.take(60) }, singleLine = true,
                    label = { Text("Nombre de la toma") }) },
                confirmButton = { TextButton(onClick = {
                    val take = project.takes.firstOrNull { it.id == target }
                    if (take != null) {
                        checkpoint(); take.name = renameTakeValue.trim().ifBlank { take.name }
                        changed()
                    }
                    renameTakeId = null
                }) { Text("GUARDAR NOMBRE") } },
                dismissButton = { TextButton(onClick = { renameTakeId = null }) { Text("CANCELAR") } })
        }
        pendingTakeDelete?.let { target ->
            AlertDialog(onDismissRequest = { pendingTakeDelete = null },
                title = { Text("¿BORRAR GRABACIÓN?") },
                text = { Text("La toma se quitará de Mis grabaciones y sus notas originales del proyecto. " +
                    "Si modificaste esas notas en Piano Roll, algunas notas modificadas pueden conservarse.") },
                confirmButton = { TextButton(onClick = {
                    stopAudition(); checkpoint()
                    val take = project.takes.firstOrNull { it.id == target }
                    if (take != null) {
                        for (note in take.notes) project.notes.remove(note)
                        project.takes.remove(take)
                        changed(); notice = "Grabación eliminada"
                    }
                    pendingTakeDelete = null
                }) { Text("BORRAR", color = RED) } },
                dismissButton = { TextButton(onClick = { pendingTakeDelete = null }) { Text("CANCELAR") } })
        }
        pendingDelete?.let { target ->
            AlertDialog(onDismissRequest = { pendingDelete = null },
                title = { Text("¿ELIMINAR PROYECTO?") },
                text = { Text("Se eliminará '$target'. Esta acción no se puede deshacer.") },
                confirmButton = { TextButton(onClick = {
                    store.remove(target); listProjects = store.list(); pendingDelete = null
                    notice = "Proyecto eliminado"
                }) { Text("ELIMINAR", color = RED) } },
                dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("CANCELAR") } })
        }
        if (showPatterns) AlertDialog(onDismissRequest = { showPatterns = false },
            title = { Text("MIS RITMOS") }, text = {
                Column {
                    OutlinedTextField(value = patternInput, onValueChange = { patternInput = it.take(60) },
                        label = { Text("Nombre del ritmo") }, singleLine = true)
                    Button(onClick = {
                        try {
                            store.savePattern(project, patternInput)
                            listPatterns = store.listPatterns(); notice = "Ritmo guardado"; showPatterns = false
                        } catch (e: Exception) { notice = "Error: ${e.message}" }
                    }) { Text("GUARDAR RITMO ACTUAL") }
                    LazyColumn(Modifier.heightIn(max = 270.dp)) {
                        items(listPatterns) { n ->
                            TextButton(onClick = {
                                try { checkpoint(); store.loadPattern(project, n); changed(); showPatterns = false; notice = "Ritmo aplicado: $n" }
                                catch (e: Exception) { notice = "Error: ${e.message}" }
                            }) { Text(n) }
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showPatterns = false }) { Text("CERRAR") } })
        if (showKit) AlertDialog(onDismissRequest = { showKit = false },
            title = { Text("BIBLIOTECA DE SONIDOS") }, text = {
                Column {
                    Text("24 WAV sintetizados originalmente para esta app; selecciona uno para el sampler.", color = MUTED, fontSize = 13.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        listOf("TODOS", "KICK", "SNARE", "HAT", "COWBELL", "808", "FX").forEach { cat ->
                            SelectPill(cat, kitCategory == cat) { kitCategory = cat }
                        }
                    }
                    LazyColumn(Modifier.heightIn(max = 350.dp)) {
                        items(soundKit.filter { kitCategory == "TODOS" || it.optString("category") == kitCategory }) { sound ->
                            TextButton(onClick = { scope.launch {
                                try {
                                    val file = sound.getString("file")
                                    val data = withContext(Dispatchers.IO) {
                                        store.importSample(activity.assets.open("soundkit/$file"))
                                    }
                                    checkpoint(); project.samplerName = data.filename
                                    project.samplerRoot = sound.optInt("root", 60)
                                    val lane = if (instrument in 4 until TRACK_COUNT && project.instrumentIds[instrument] == 15)
                                        instrument else 15
                                    project.instrumentIds[lane] = 15; project.laneAdded[lane] = true
                                    project.laneNames[lane] = sound.optString("name", "MI SAMPLE").take(40)
                                    engine.setSample(data); instrument = lane; activity.midi.selectInstrument(lane)
                                    changed(); tab = "MI CANCIÓN"; showKit = false
                                    notice = "Sonido cargado: ${sound.optString("name")}"
                                } catch (e: Exception) { notice = "Error: ${e.message}" }
                            } }) {
                                Text("${sound.optString("category")}  ·  ${sound.optString("name")}")
                            }
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showKit = false }) { Text("CERRAR") } })
        if (showHelp) AlertDialog(onDismissRequest = { showHelp = false }, title = { Text("PHONK ZETA") },
            text = { Text("MI CANCIÓN: pulsa + AÑADIR INSTRUMENTO, usa ▶ para oírlo, " +
                "elige AÑADIR y toca las teclas en horizontal. ● REC cuenta 3, 2, 1; " +
                "■ FIN REC guarda las notas. GRABACIONES permite escuchar solo lo que tocaste. " +
                "Vuelve a MI CANCIÓN para añadir otro piano, 808 o campana: PLAY reproducirá " +
                "todas tus pistas, NO genera otra base. + BATERÍA crea golpes; + MP3 / AUDIO " +
                "importa un acompañamiento (uno por proyecto, hasta 115 s por archivo). " +
                "ESTUDIO abre editar notas, Mixer y FX. Duración editable desde TRACKS, " +
                "hasta $BAR_LIMIT compases en esta versión. Salida WAV/M4A; sin Internet.") },
            confirmButton = { TextButton(onClick = { showHelp = false }) { Text("OK") } })
    }
}

@Composable private fun SectionHeading(title: String, subtitle: String) {
    Text(title, color = GOLD, fontWeight = FontWeight.Black, fontSize = 16.sp)
    Text(subtitle, color = MUTED, fontSize = 15.sp)
}
@Composable private fun SelectPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, shape = RoundedCornerShape(9.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) PURPLE else PANEL),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier = Modifier.height(48.dp)) {
        Text(text, color = if (selected) BG else Color.White, fontSize = 15.sp,
            fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PianoRoll(p: ZetaProject, track: Int, bar: Int, octave: Int,
                      selected: MusicNote?, onTap: (Int, Double) -> Unit, modifier: Modifier) {
    val bottom = octave * 12
    Canvas(modifier.background(SURFACE, RoundedCornerShape(8.dp))
        .pointerInput(track, bar, octave, p.notes.size) {
            detectTapGestures { pos ->
                val pitch = (bottom + 23 - floor(pos.y / size.height * 24.0).toInt()).coerceIn(0, 127)
                val beat = bar * 4.0 + (floor(pos.x / size.width * 16.0) / 4.0)
                onTap(pitch, beat.coerceIn(0.0, p.bars * 4.0 - .01))
            }
        }) {
        val h = size.height / 24f
        val w = size.width / 16f
        for (i in 0..24) {
            drawLine(if (i % 12 == 0) GOLD.copy(alpha = .55f) else MUTED.copy(alpha = .20f),
                Offset(0f, i * h), Offset(size.width, i * h), 1f)
        }
        for (i in 0..16) {
            drawLine(if (i % 4 == 0) PURPLE.copy(alpha = .7f) else MUTED.copy(alpha = .17f),
                Offset(i * w, 0f), Offset(i * w, size.height), if (i % 4 == 0) 2f else 1f)
        }
        for (n in p.notes) {
            if (n.track != track || n.pitch !in bottom..bottom + 23) continue
            val start = (n.start - bar * 4.0) * 4 * w
            val end = (n.start + n.length - bar * 4.0) * 4 * w
            if (end <= 0 || start >= size.width) continue
            val y = (bottom + 23 - n.pitch) * h
            drawRect(if (n == selected) GOLD else PURPLE,
                Offset(start.toFloat().coerceAtLeast(0f) + 1f, y + 1f),
                Size((end - start).toFloat().coerceAtMost(size.width - start.toFloat().coerceAtLeast(0f)).coerceAtLeast(2f),
                    h - 2f))
        }
        drawIntoCanvas { c ->
            val paint = android.graphics.Paint().apply {
                color = android.graphics.Color.WHITE; textSize = 19f; isAntiAlias = true
            }
            for (i in 0 until 24) {
                val pitch = bottom + 23 - i
                if (pitch % 12 == 0) c.nativeCanvas.drawText("C${pitch / 12 - 1}", 3f, (i + .72f) * h, paint)
            }
        }
    }
}

@Composable
private fun PianoView(engine: ZetaAudioEngine, track: Int, octave: Int, chordMode: Int,
                      scaleMode: Int, rootNote: Int, velocity: Float, modifier: Modifier) {
    val active = remember { mutableStateMapOf<Int, List<Int>>() }
    fun notesFor(pitch: Int): List<Int> {
        val tones = when (scaleMode) {
            1 -> setOf(0, 2, 4, 5, 7, 9, 11)
            2 -> setOf(0, 2, 3, 5, 7, 8, 10)
            else -> (0..11).toSet()
        }
        val base = (pitch - 2..pitch + 2).filter { it in 0..127 && (it - rootNote).mod(12) in tones }
            .minByOrNull { kotlin.math.abs(it - pitch) } ?: pitch
        val ints = when (chordMode) { 1 -> listOf(0, 4, 7); 2 -> listOf(0, 3, 7);
            3 -> listOf(0, 4, 7, 10); else -> listOf(0) }
        return ints.map { base + it }.filter { it in 0..127 }
    }
    fun pitchAt(x: Float, y: Float, width: Float, height: Float): Int {
        val unit = width / 14
        val white = (x / unit).toInt().coerceIn(0, 13)
        val base = WHITE_NOTES[white % 7] + (white / 7) * 12
        if (y < height * .62f) {
            val fraction = x / unit - floor(x / unit)
            if (fraction > .68f && base % 12 in listOf(0, 2, 5, 7, 9))
                return (octave * 12 + 12 + base + 1).coerceIn(0, 127)
            if (fraction < .32f && white > 0) {
                val prev = WHITE_NOTES[(white - 1) % 7] + (white - 1) / 7 * 12
                if (prev % 12 in listOf(0, 2, 5, 7, 9))
                    return (octave * 12 + 12 + prev + 1).coerceIn(0, 127)
            }
        }
        return (octave * 12 + 12 + base).coerceIn(0, 127)
    }
    DisposableEffect(track, octave, chordMode, scaleMode, rootNote) {
        onDispose { active.values.flatten().forEach { engine.noteOff(track, it) }; active.clear() }
    }
    Canvas(modifier.background(SURFACE, RoundedCornerShape(10.dp))
        .pointerInput(track, octave, chordMode, scaleMode, rootNote, velocity) {
            awaitEachGesture {
                do {
                    val e = awaitPointerEvent()
                    for (change in e.changes) {
                        val id = change.id.value.toInt()
                        if (change.pressed) {
                            val notes = notesFor(pitchAt(change.position.x, change.position.y,
                                size.width.toFloat(), size.height.toFloat()))
                            val old = active[id]
                            if (old != notes) {
                                old?.forEach { engine.noteOff(track, it) }
                                notes.forEach { engine.noteOn(track, it, velocity.toDouble()) }
                                active[id] = notes
                            }
                        } else active.remove(id)?.forEach { engine.noteOff(track, it) }
                    }
                } while (e.changes.any { it.pressed })
                active.toMap().values.flatten().forEach { engine.noteOff(track, it) }
                active.clear()
            }
        }) {
        val keyW = size.width / 14
        for (i in 0 until 14) {
            val pitch = octave * 12 + 12 + WHITE_NOTES[i % 7] + i / 7 * 12
            drawRect(if (active.values.any { pitch in it }) GOLD else Color(0xFFE7E7EC),
                Offset(i * keyW, 0f), Size(keyW - 1f, size.height))
        }
        for (i in 0 until 13) {
            val n = WHITE_NOTES[i % 7]
            if (n in listOf(0, 2, 5, 7, 9)) {
                val pitch = octave * 12 + 12 + n + i / 7 * 12 + 1
                val bw = keyW * .62f
                drawRect(if (active.values.any { pitch in it }) PURPLE else Color(0xFF17171E),
                    Offset((i + 1) * keyW - bw / 2, 0f), Size(bw, size.height * .62f))
            }
        }
    }
}
