# PHONK ZETA 0.9.2

- Corregido `MethodTooLargeException` en `ZetaApp`.
- La interfaz principal fue separada y reducida al flujo nuevo: Inicio, Pads, Melodía, Editor y Exportar.
- Eliminado del composable principal el bloque antiguo enorme que hacía fallar el compilador Kotlin.
- Se mantiene el editor visual, audio importado, grabación de notas, creación automática y exportación WAV/M4A.
- `detectDragGestures` queda importado para el editor de melodía.
