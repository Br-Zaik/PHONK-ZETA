package com.phonkzeta.musicstudio

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.ArrayDeque
import kotlin.math.*

private val BG = Color(0xFF09090B)
private val SURFACE = Color(0xFF15151D)
private val PANEL = Color(0xFF30303D)
private val PURPLE = Color(0xFFA78BFA)
private val RED = Color(0xFFFF3B5C)
private val GOLD = Color(0xFFF5C451)
private val MUTED = Color(0xFFE1E4ED)
private val WHITE_NOTES = intArrayOf(0, 2, 4, 5, 7, 9, 11)
private val LABEL_NOTES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
private val TABS = listOf("MI CANCIÓN", "EDITOR", "INICIO", "GRABACIONES", "PIANO", "PADS", "RITMOS", "PIANO ROLL", "TRACKS", "MIXER", "FX")

class MainActivity : ComponentActivity() {
    val engine = ZetaAudioEngine()
    lateinit var store: ProjectStorage
    lateinit var midi: MidiBridge
    var snapshotProvider: (() -> ZetaProject)? = null
    val micRecorder by lazy { MicRecorder(this) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStorage(this)
        val project = try { store.load("autosave") } catch (_: Exception) { demoProject() }
        if (project.name == "autosave") project.name = "Mi canción"
        engine.setProject(project)
        try {
            val kit = mapOf(
                0 to "01_deep_kick.wav", 1 to "05_dark_snare.wav",
                2 to "09_tight_hat.wav", 3 to "06_snap_snare.wav",
                5 to "17_long_808_c.wav", 6 to "13_drift_cowbell.wav"
            ).mapValues { (_, file) ->
                WaveDecoder.decode(assets.open("soundkit/$file").use { it.readBytes() })
            }
            engine.setFactoryKit(kit)
        } catch (_: Exception) { /* Sound engine falls back to synthesis if an asset is unavailable. */ }
        try {
            engine.setSample(store.loadSample(project.samplerName))
            engine.setBackground(store.loadBackground(project.backgroundName))
            engine.setAudioBank(project.audioClips.mapNotNull { c ->
                store.loadBackground(c.filename)?.let { c.filename to it }
            }.toMap())
            engine.start()
        } catch (_: Exception) { }
        midi = MidiBridge(this, engine)
        setContent { ZetaApp(project, this) }
    }
    override fun onPause() { super.onPause(); engine.allNotesOff() }
    override fun onStop() {
        try { snapshotProvider?.invoke()?.let { store.saveAutosave(it) } }
        catch (_: Exception) { /* Manual save and previous atomic autosave remain. */ }
        super.onStop()
    }
    override fun onDestroy() { if (::midi.isInitialized) midi.close(); micRecorder.stop(); engine.close(); super.onDestroy() }
}

private fun demoProject() = ZetaProject().apply {
    listOf(0, 6, 8, 14).forEach { steps[0][it] = true }
    listOf(4, 12).forEach { steps[1][it] = true }
    for (i in 0..15 step 2) steps[2][i] = true
    listOf(60, 63, 67, 65, 60, 58, 55, 58).forEachIndexed { i, pitch ->
        notes.add(MusicNote(6, pitch, i * .5, .42))
    }
}

@Composable
private fun ZetaApp(initial: ZetaProject, activity: MainActivity) {
    val engine = activity.engine
    val store = activity.store
    val scope = rememberCoroutineScope()

    var project by remember { mutableStateOf(initial) }
    var revision by remember { mutableIntStateOf(0) }
    val observedProject = remember(revision) { project }
    var tab by remember { mutableStateOf("INICIO") }
    var instrument by remember { mutableIntStateOf(8) }
    var playing by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var countIn by remember { mutableIntStateOf(0) }
    var transportTick by remember { mutableIntStateOf(0) }
    var notice by remember { mutableStateOf("Estudio listo · sin Internet") }
    var exportProgress by remember { mutableIntStateOf(-1) }
    var showQuickCreate by remember { mutableStateOf(false) }
    var quickStyle by remember { mutableStateOf("DARK") }
    var quickBars by remember { mutableStateOf("16") }
    var saveJob by remember { mutableStateOf<Job?>(null) }
    var recordingJob by remember { mutableStateOf<Job?>(null) }

    DisposableEffect(activity, project) {
        activity.snapshotProvider = { project.copyDeep() }
        onDispose { activity.snapshotProvider = null }
    }

    LaunchedEffect(playing) {
        while (playing) {
            delay(100)
            transportTick++
        }
    }
    val playSeconds = remember(transportTick, revision) { engine.playSeconds }

    fun changed(message: String? = null) {
        revision++
        engine.refresh(project)
        if (message != null) notice = message
        saveJob?.cancel()
        val snapshot = project.copyDeep()
        saveJob = scope.launch {
            delay(700)
            runCatching { withContext(Dispatchers.IO) { store.saveAutosave(snapshot) } }
        }
    }

    fun saveNow() {
        val snapshot = project.copyDeep()
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    store.save(snapshot)
                    store.saveAutosave(snapshot)
                }
            }.onSuccess { notice = "Proyecto guardado" }
                .onFailure { notice = "No se pudo guardar: ${it.message}" }
        }
    }

    fun stopRecording() {
        recordingJob?.cancel()
        if (countIn > 0) {
            countIn = 0
            notice = "Grabación cancelada"
            return
        }
        if (!recording) return
        val result = engine.finishRecording().filter { it.start >= 0.0 && it.start < BAR_LIMIT * 4.0 }
        recording = false
        if (result.isNotEmpty()) {
            project.notes.addAll(result)
            val maxBeat = result.maxOf { it.start + it.length }
            project.bars = max(project.bars, ceil(maxBeat / 4.0).toInt()).coerceAtMost(BAR_LIMIT)
            changed("Grabación guardada · ${result.size} notas")
        } else {
            notice = "No se grabaron notas"
        }
    }

    fun startRecording() {
        if (recording || countIn > 0) return
        recordingJob?.cancel()
        recordingJob = scope.launch {
            for (n in 3 downTo 1) {
                countIn = n
                notice = "Preparados… $n"
                delay(650)
            }
            countIn = 0
            if (!playing) playing = engine.togglePlay()
            engine.startRecording()
            recording = true
            notice = "● Grabando"
        }
    }

    fun togglePlay() {
        if (recording || countIn > 0) stopRecording()
        playing = engine.togglePlay()
    }

    fun stopAll() {
        if (recording || countIn > 0) stopRecording()
        engine.stop()
        playing = false
        notice = "Detenido"
    }

    val importAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            notice = "Importando audio…"
            runCatching {
                val sound = withContext(Dispatchers.IO) { AudioImport.decode(activity, uri, maximumSeconds = 240) }
                val label = runCatching {
                    activity.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { c -> if (c.moveToFirst()) c.getString(0).take(70) else "Audio" } ?: "Audio"
                }.getOrDefault("Audio")
                val name = withContext(Dispatchers.IO) { store.importBackground(sound) }
                val waveform = withContext(Dispatchers.Default) { timelineWaveform(sound) }
                val spb = 60.0 / project.bpm
                val startBeat = (engine.playSeconds / spb).coerceAtLeast(0.0)
                val lengthBeats = sound.pcm.size.toDouble() / sound.sampleRate / spb
                val neededBars = ceil((startBeat + lengthBeats) / 4.0).toInt().coerceAtMost(BAR_LIMIT)
                project.bars = max(project.bars, neededBars)
                project.audioClips.add(
                    ZetaAudioClip(
                        id = System.nanoTime().toString(), filename = name,
                        startBeat = startBeat.coerceAtMost(project.bars * 4.0 - .25),
                        trimSeconds = 0.0,
                        lengthBeats = lengthBeats.coerceIn(.25, project.bars * 4.0),
                        gain = .7, label = label, waveform = waveform
                    )
                )
                engine.setAudioSource(sound.copy(filename = name))
                changed("Audio añadido al editor")
                tab = "EDITOR"
            }.onFailure { notice = "No se pudo importar: ${it.message}" }
        }
    }

    val exportWav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) scope.launch {
            exportProgress = 0
            val temp = File(activity.cacheDir, "phonk_${System.currentTimeMillis()}.wav")
            runCatching {
                val snapshot = project.copyDeep()
                withContext(Dispatchers.IO) {
                    engine.exportWav(snapshot, temp) { pct -> activity.runOnUiThread { exportProgress = pct } }
                    activity.contentResolver.openOutputStream(uri)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
                        ?: error("No se pudo guardar WAV")
                }
            }.onSuccess { notice = "WAV exportado" }
                .onFailure { notice = "Error WAV: ${it.message}" }
            temp.delete()
            exportProgress = -1
        }
    }

    val exportM4a = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { uri ->
        if (uri != null) scope.launch {
            exportProgress = 0
            val wav = File(activity.cacheDir, "phonk_${System.currentTimeMillis()}.wav")
            val m4a = File(activity.cacheDir, "phonk_${System.currentTimeMillis()}.m4a")
            runCatching {
                val snapshot = project.copyDeep()
                withContext(Dispatchers.IO) {
                    engine.exportWav(snapshot, wav) { pct -> activity.runOnUiThread { exportProgress = pct.coerceAtMost(92) } }
                    AacExporter.wavToM4a(wav, m4a)
                    activity.contentResolver.openOutputStream(uri)?.use { out -> m4a.inputStream().use { it.copyTo(out) } }
                        ?: error("No se pudo guardar M4A")
                }
            }.onSuccess { notice = "M4A exportado" }
                .onFailure { notice = "Error M4A: ${it.message}" }
            wav.delete(); m4a.delete(); exportProgress = -1
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PURPLE, secondary = GOLD, background = BG, surface = SURFACE,
            onPrimary = BG, onSecondary = BG, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Column(Modifier.fillMaxSize().background(BG).systemBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("PHONK", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text(" ZETA", color = GOLD, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { saveNow() }) { Text("GUARDAR", color = MUTED, fontWeight = FontWeight.Bold) }
            }

            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                when (tab) {
                    "INICIO" -> EasyStudioHome(
                        project = observedProject,
                        playing = playing,
                        recording = recording,
                        countIn = countIn,
                        onPlay = { togglePlay() },
                        onRecord = { if (recording || countIn > 0) stopRecording() else startRecording() },
                        onOpenEditor = { tab = "EDITOR" },
                        onQuickCreate = { showQuickCreate = true },
                        onOpenPads = { tab = "PADS" },
                        onOpenMelody = { instrument = 8; tab = "MELODÍA" },
                        onExportWav = { exportWav.launch("${project.name.take(40)}.wav") },
                        onExportM4a = { exportM4a.launch("${project.name.take(40)}.m4a") },
                        onMp3Info = { notice = "Usa WAV o M4A" },
                        onChangeBpm = { d -> project.bpm = (project.bpm + d).coerceIn(40, 260); changed() },
                        onPadTap = { lane, pitch ->
                            instrument = lane
                            engine.noteOn(lane, pitch)
                            scope.launch { delay(140); engine.noteOff(lane, pitch) }
                        },
                        onPreviewTrack = { lane -> instrument = lane; tab = "MELODÍA" }
                    )

                    "PADS" -> EasyPadsPage(
                        project = observedProject,
                        playing = playing,
                        recording = recording,
                        countIn = countIn,
                        onPlay = { togglePlay() },
                        onRecord = { if (recording || countIn > 0) stopRecording() else startRecording() },
                        onPad = { lane, pitch ->
                            instrument = lane
                            engine.noteOn(lane, pitch)
                            scope.launch { delay(140); engine.noteOff(lane, pitch) }
                        },
                        onMelody = { instrument = 8; tab = "MELODÍA" },
                        onEditor = { tab = "EDITOR" }
                    )

                    "MELODÍA" -> EasyMelodyRoll(
                        project = observedProject,
                        track = instrument.coerceIn(4, TRACK_COUNT - 1),
                        playSeconds = playSeconds,
                        onChange = { edit -> edit(project); changed() },
                        onPreview = { pitch ->
                            engine.noteOn(instrument, pitch)
                            scope.launch { delay(180); engine.noteOff(instrument, pitch) }
                        },
                        onBack = { tab = "PADS" }
                    )

                    "EDITOR" -> VisualStudioEditor(
                        project = observedProject,
                        playSeconds = playSeconds,
                        onChange = { edit -> edit(project); changed() },
                        onSeek = { sec -> engine.seekSeconds(sec); transportTick++ },
                        onImport = { importAudio.launch(arrayOf("audio/*", "application/octet-stream")) },
                        onAddInstrument = {
                            instrument = 8
                            project.laneAdded[instrument] = true
                            project.laneNames[instrument] = "MELODÍA"
                            changed()
                            tab = "MELODÍA"
                        },
                        onEditNotes = { track, _ -> instrument = if (track < 4) 8 else track; tab = "MELODÍA" },
                        onOpenPiano = { track -> instrument = if (track < 4) 8 else track; tab = "PADS" },
                        onPreviewNote = { track, pitch ->
                            engine.noteOn(track, pitch)
                            scope.launch { delay(160); engine.noteOff(track, pitch) }
                        },
                        compactMode = true
                    )

                    "EXPORTAR" -> EasyExportScreen(
                        project = observedProject,
                        exportBusy = exportProgress >= 0,
                        onSave = { saveNow() },
                        onExportWav = { exportWav.launch("${project.name.take(40)}.wav") },
                        onExportM4a = { exportM4a.launch("${project.name.take(40)}.m4a") },
                        onEditor = { tab = "EDITOR" },
                        onProjects = { notice = "Proyecto guardado automáticamente" },
                        onMp3Info = { notice = "Usa WAV o M4A" }
                    )
                }
            }

            if (exportProgress >= 0) {
                LinearProgressIndicator(progress = { exportProgress / 100f }, modifier = Modifier.fillMaxWidth())
            }
            Text(
                notice, color = GOLD, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp)
            )
            EasyBottomBar(tab = tab, onSelect = { tab = it }, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
        }

        if (showQuickCreate) {
            AlertDialog(
                onDismissRequest = { showQuickCreate = false },
                title = { Text("Crear beat") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Elige un estilo y una duración. Todo queda editable.")
                        EasyPhonk.styles.forEach { style ->
                            SelectPill(style, quickStyle == style) { quickStyle = style }
                        }
                        OutlinedTextField(
                            value = quickBars,
                            onValueChange = { quickBars = it.filter(Char::isDigit).take(3) },
                            label = { Text("Compases") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val bars = quickBars.toIntOrNull()?.coerceIn(2, BAR_LIMIT) ?: 16
                        EasyPhonk.generate(project, quickStyle, bars)
                        changed("Beat $quickStyle creado")
                        showQuickCreate = false
                        tab = "EDITOR"
                    }) { Text("CREAR") }
                },
                dismissButton = { TextButton(onClick = { showQuickCreate = false }) { Text("CANCELAR") } }
            )
        }
    }
}


@Composable
private fun EasyStudioHome(
    project: ZetaProject,
    playing: Boolean,
    recording: Boolean,
    countIn: Int,
    onPlay: () -> Unit,
    onRecord: () -> Unit,
    onOpenEditor: () -> Unit,
    onQuickCreate: () -> Unit,
    onOpenPads: () -> Unit,
    onOpenMelody: () -> Unit,
    onExportWav: () -> Unit,
    onExportM4a: () -> Unit,
    onMp3Info: () -> Unit,
    onChangeBpm: (Int) -> Unit,
    onPadTap: (Int, Int) -> Unit,
    onPreviewTrack: (Int) -> Unit
) {
    val padItems = remember {
        listOf(
            Triple("KICK", 0, 36), Triple("SNARE", 1, 38), Triple("HAT", 2, 42), Triple("OPEN HAT", 3, 39),
            Triple("PERC", 2, 46), Triple("SAMPLE", 6, 60), Triple("FX", 7, 60), Triple("VOCAL", 8, 60)
        )
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(18.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(project.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("Proyecto · ${project.bars} compases", color = MUTED, fontSize = 14.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { onChangeBpm(-1) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("−") }
                    Text("${project.bpm} BPM", color = GOLD, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    OutlinedButton(onClick = { onChangeBpm(1) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("+") }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPlay, modifier = Modifier.weight(1f).height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) {
                    Text(if (playing) "Ⅱ PAUSA" else "▶ PLAY", color = BG, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
                Button(onClick = onRecord, modifier = Modifier.weight(1f).height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (recording) RED else Color(0xFF8D2743))) {
                    Text(if (recording) "■ FIN REC" else if (countIn > 0) "$countIn…" else "● REC",
                        color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
            }
            OutlinedButton(onClick = onQuickCreate, modifier = Modifier.fillMaxWidth()) {
                Text("⚡ CREAR BEAT AUTOMÁTICO", color = GOLD, fontWeight = FontWeight.Bold)
            }
        }

        Text("PADS", color = GOLD, fontWeight = FontWeight.Black, fontSize = 16.sp)
        Text("Toca para agregar sonidos", color = MUTED, fontSize = 14.sp)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (row in 0 until 2) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (col in 0 until 4) {
                        val item = padItems[row * 4 + col]
                        Button(
                            onClick = { onPadTap(item.second, item.third) },
                            modifier = Modifier.weight(1f).height(84.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = when (col) {
                                    1 -> Color(0xFFB1266A)
                                    2 -> Color(0xFF7A5A13)
                                    3 -> Color(0xFF5B2A96)
                                    else -> Color(0xFF4B327A)
                                }
                            ),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            Text(item.first, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = onOpenPads, modifier = Modifier.fillMaxWidth()) {
            Text("ABRIR PADS GIGANTES", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Text("MELODÍA", color = GOLD, fontWeight = FontWeight.Black, fontSize = 16.sp)
        Text("Toca el teclado o graba una melodía", color = MUTED, fontSize = 14.sp)
        Row(Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(14.dp)).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("DO" to 60, "RE" to 62, "MI" to 64, "FA" to 65, "SOL" to 67, "LA" to 69, "SI" to 71).forEach { (label, pitch) ->
                Button(onClick = { onPadTap(8, pitch) }, modifier = Modifier.weight(1f).height(72.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8E8ED)),
                    contentPadding = PaddingValues(2.dp)) {
                    Text(label, color = BG, fontWeight = FontWeight.Black)
                }
            }
        }
        Button(onClick = onOpenMelody, modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RED)) {
            Text("● GRABAR MELODÍA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }

        Text("LÍNEA DE TIEMPO", color = GOLD, fontWeight = FontWeight.Black, fontSize = 16.sp)
        EasyArrangementPreview(project = project, modifier = Modifier.fillMaxWidth().height(176.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SelectPill("1 Toca pads", true) { }
            SelectPill("2 Graba melodía", false) { }
            SelectPill("3 Ajusta bloques", false) { }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onOpenEditor, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) {
                Text("ABRIR EDITOR", color = BG, fontWeight = FontWeight.Black)
            }
            OutlinedButton(onClick = { onPreviewTrack(8) }, modifier = Modifier.weight(1f)) {
                Text("EDITAR NOTAS", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Text("EXPORTAR CANCIÓN", color = GOLD, fontWeight = FontWeight.Black, fontSize = 16.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onExportWav, modifier = Modifier.weight(1f).height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) {
                Text("WAV", color = BG, fontWeight = FontWeight.Black, fontSize = 18.sp)
            }
            OutlinedButton(onClick = onMp3Info, modifier = Modifier.weight(1f).height(54.dp)) {
                Text("MP3", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Button(onClick = onExportM4a, modifier = Modifier.weight(1f).height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C8A5D))) {
                Text("M4A", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
            }
        }
    }
}

@Composable
private fun EasyArrangementPreview(project: ZetaProject, modifier: Modifier = Modifier) {
    val totalBeats = (project.bars * 4).coerceAtLeast(4)
    Canvas(modifier.background(SURFACE, RoundedCornerShape(16.dp)).padding(10.dp)) {
        val rowHeight = size.height / 3f
        for (i in 0..project.bars.coerceAtMost(8)) {
            val x = i * size.width / project.bars.coerceAtLeast(1)
            drawLine(MUTED.copy(alpha = if (i % 4 == 0) .35f else .15f), Offset(x, 0f), Offset(x, size.height), if (i % 4 == 0) 2f else 1f)
        }
        for (r in 1..2) drawLine(MUTED.copy(alpha = .16f), Offset(0f, r * rowHeight), Offset(size.width, r * rowHeight), 1f)
        // Drum clip
        if ((0 until 4).any { t -> project.steps[t].any { it } || project.notes.any { n -> n.track == t } }) {
            drawRoundRect(PURPLE.copy(alpha = .85f), Offset(10f, 10f), Size(size.width * .55f, rowHeight - 18f), androidx.compose.ui.geometry.CornerRadius(10f, 10f))
        }
        val melodic = project.notes.filter { it.track >= 4 }
        if (melodic.isNotEmpty()) {
            val minPitch = melodic.minOf { it.pitch }
            val maxPitch = melodic.maxOf { it.pitch }.coerceAtLeast(minPitch + 1)
            melodic.take(42).forEach { note ->
                val x = (note.start / totalBeats * size.width).toFloat()
                val w = (note.length / totalBeats * size.width).toFloat().coerceAtLeast(8f)
                val frac = 1f - ((note.pitch - minPitch).toFloat() / (maxPitch - minPitch).toFloat())
                val y = rowHeight + 10f + frac * (rowHeight - 26f)
                drawRoundRect(Color(0xFFFF4FA2), Offset(x, y), Size(w, 10f), androidx.compose.ui.geometry.CornerRadius(5f, 5f))
            }
        } else {
            drawRoundRect(Color(0xFFFF4FA2).copy(alpha = .75f), Offset(size.width * .34f, rowHeight + 10f), Size(size.width * .55f, rowHeight - 18f), androidx.compose.ui.geometry.CornerRadius(10f, 10f))
        }
        if (project.audioClips.isNotEmpty()) {
            val clip = project.audioClips.first()
            val x = (clip.startBeat / totalBeats * size.width).toFloat()
            val w = (clip.lengthBeats / totalBeats * size.width).toFloat().coerceAtLeast(20f)
            drawRoundRect(GOLD.copy(alpha = .85f), Offset(x, rowHeight * 2 + 10f), Size(w, rowHeight - 18f), androidx.compose.ui.geometry.CornerRadius(10f, 10f))
        } else {
            drawRoundRect(GOLD.copy(alpha = .8f), Offset(size.width * .08f, rowHeight * 2 + 10f), Size(size.width * .42f, rowHeight - 18f), androidx.compose.ui.geometry.CornerRadius(10f, 10f))
        }
        val playX = size.width * .08f
        drawLine(Color.White, Offset(playX, 0f), Offset(playX, size.height), 3f)
    }
}

@Composable
private fun EasyExportScreen(
    project: ZetaProject,
    exportBusy: Boolean,
    onSave: () -> Unit,
    onExportWav: () -> Unit,
    onExportM4a: () -> Unit,
    onEditor: () -> Unit,
    onProjects: () -> Unit,
    onMp3Info: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Exporta tu beat", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text(project.name, color = GOLD, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("${project.bpm} BPM · ${project.bars} compases", color = MUTED, fontSize = 15.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onSave, modifier = Modifier.weight(1f).height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3D4257))) {
                Text("GUARDAR", color = Color.White, fontWeight = FontWeight.Black)
            }
            OutlinedButton(onClick = onProjects, modifier = Modifier.weight(1f).height(54.dp)) {
                Text("PROYECTOS", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Text("Elige un formato", color = GOLD, fontWeight = FontWeight.Black, fontSize = 16.sp)
        Button(onClick = onExportWav, enabled = !exportBusy, modifier = Modifier.fillMaxWidth().height(60.dp), colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) {
            Text("WAV · máxima calidad", color = BG, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        OutlinedButton(onClick = onMp3Info, modifier = Modifier.fillMaxWidth().height(60.dp)) {
            Text("MP3 · próximamente", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Button(onClick = onExportM4a, enabled = !exportBusy, modifier = Modifier.fillMaxWidth().height(60.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C8A5D))) {
            Text("M4A · tamaño menor", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        OutlinedButton(onClick = onEditor, modifier = Modifier.fillMaxWidth()) {
            Text("VOLVER AL EDITOR", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EasyBottomBar(tab: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(18.dp)).padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("INICIO" to "Inicio", "EDITOR" to "Editor", "PADS" to "Pads", "EXPORTAR" to "Exportar").forEach { (key, label) ->
            Button(onClick = { onSelect(key) }, modifier = Modifier.weight(1f).height(46.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (tab == key) PURPLE else PANEL),
                contentPadding = PaddingValues(4.dp)) {
                Text(label, color = if (tab == key) BG else Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}


@Composable
private fun EasyTransportBar(
    bpm: Int,
    playing: Boolean,
    recording: Boolean,
    countIn: Int,
    metronome: Boolean,
    onPlay: () -> Unit,
    onRecord: () -> Unit,
    onStop: () -> Unit,
    onBpm: (Int) -> Unit,
    onMetronome: () -> Unit
) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onPlay, modifier = Modifier.weight(1.1f).height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PURPLE), contentPadding = PaddingValues(horizontal = 8.dp)) {
            Text(if (playing) "Ⅱ" else "▶ PLAY", color = BG, fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
        Button(onClick = onRecord, modifier = Modifier.weight(1f).height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (recording) RED else Color(0xFF932846)),
            contentPadding = PaddingValues(horizontal = 8.dp)) {
            Text(if (recording) "■ FIN" else if (countIn > 0) "$countIn…" else "● REC", color = Color.White,
                fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        OutlinedButton(onClick = onMetronome, modifier = Modifier.height(50.dp), contentPadding = PaddingValues(horizontal = 10.dp)) {
            Text("♩", color = if (metronome) GOLD else MUTED, fontSize = 20.sp)
        }
        Row(Modifier.weight(1.35f).height(50.dp).background(SURFACE, RoundedCornerShape(15.dp)),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = { onBpm(-1) }, contentPadding = PaddingValues(4.dp)) { Text("−", color = MUTED, fontSize = 20.sp) }
            Text("$bpm BPM", color = GOLD, fontWeight = FontWeight.Black, fontSize = 15.sp)
            TextButton(onClick = { onBpm(1) }, contentPadding = PaddingValues(4.dp)) { Text("+", color = PURPLE, fontSize = 20.sp) }
        }
        TextButton(onClick = onStop, contentPadding = PaddingValues(4.dp)) { Text("■", color = MUTED, fontSize = 17.sp) }
    }
}

@Composable
private fun EasyPadsPage(
    project: ZetaProject,
    playing: Boolean,
    recording: Boolean,
    countIn: Int,
    onPlay: () -> Unit,
    onRecord: () -> Unit,
    onPad: (Int, Int) -> Unit,
    onMelody: () -> Unit,
    onEditor: () -> Unit
) {
    val pads = remember {
        listOf(
            Triple("KICK", 0, 36), Triple("SNARE", 1, 38), Triple("HAT", 2, 42), Triple("OPEN HAT", 3, 39),
            Triple("PERC", 2, 46), Triple("COWBELL", 6, 60), Triple("808", 5, 36), Triple("FX", 7, 60)
        )
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        EasyTransportBar(
            bpm = project.bpm, playing = playing, recording = recording, countIn = countIn,
            metronome = project.metronome, onPlay = onPlay, onRecord = onRecord, onStop = { },
            onBpm = { }, onMetronome = { }
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("PADS", color = GOLD, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(8.dp))
            Text("Toca y combina sonidos", color = MUTED, fontSize = 14.sp)
        }
        for (r in 0 until 2) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in 0 until 4) {
                    val p = pads[r * 4 + c]
                    val color = when ((r * 4 + c) % 4) {
                        0 -> Color(0xFF5E3AA7)
                        1 -> Color(0xFF9E285D)
                        2 -> Color(0xFF7A5A13)
                        else -> Color(0xFF483285)
                    }
                    Button(onClick = { onPad(p.second, p.third) }, modifier = Modifier.weight(1f).height(92.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = color),
                        contentPadding = PaddingValues(4.dp), shape = RoundedCornerShape(18.dp)) {
                        Text(p.first, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(SURFACE, RoundedCornerShape(18.dp)).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("MELODÍA", color = GOLD, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Text("Toca unas notas o pulsa REC para grabarlas", color = MUTED, fontSize = 14.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("DO" to 60, "RE" to 62, "MI" to 64, "FA" to 65, "SOL" to 67, "LA" to 69, "SI" to 71).forEach { (name, pitch) ->
                    Button(onClick = { onPad(8, pitch) }, modifier = Modifier.weight(1f).height(66.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE9E8EF)),
                        contentPadding = PaddingValues(2.dp), shape = RoundedCornerShape(8.dp)) {
                        Text(name, color = BG, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                }
            }
            Button(onClick = onMelody, modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RED), shape = RoundedCornerShape(14.dp)) {
                Text("EDITAR / GRABAR MELODÍA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
            }
        }
        OutlinedButton(onClick = onEditor, modifier = Modifier.fillMaxWidth().height(48.dp)) {
            Text("VER LÍNEA DE TIEMPO", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

private enum class NoteDragMode { MOVE, LEFT, RIGHT }

@Composable
private fun EasyMelodyRoll(
    project: ZetaProject,
    track: Int,
    playSeconds: Double,
    onChange: ((ZetaProject) -> Unit) -> Unit,
    onPreview: (Int) -> Unit,
    onBack: () -> Unit
) {
    var page by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<MusicNote?>(null) }
    var dragOriginal by remember { mutableStateOf<MusicNote?>(null) }
    var dragPreview by remember { mutableStateOf<MusicNote?>(null) }
    var dragMode by remember { mutableStateOf(NoteDragMode.MOVE) }
    val beatsPerPage = 16.0
    val totalPages = ceil(project.bars * 4.0 / beatsPerPage).toInt().coerceAtLeast(1)
    page = page.coerceIn(0, totalPages - 1)
    val startBeat = page * beatsPerPage
    val endBeat = startBeat + beatsPerPage
    val notesState = rememberUpdatedState(project.notes.filter { it.track == track && it.start < endBeat && it.start + it.length > startBeat })
    val playBeat = playSeconds * project.bpm / 60.0

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", color = Color.White, fontSize = 24.sp) }
            Column(Modifier.weight(1f)) {
                Text("MELODÍA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("Arrastra para mover · bordes para estirar", color = MUTED, fontSize = 13.sp)
            }
            Text(project.laneNames[track].take(14), color = PURPLE, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { page = (page - 1).coerceAtLeast(0) }) { Text("◀") }
            Text("Compases ${page * 4 + 1}–${min(project.bars, page * 4 + 4)}", color = GOLD,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            OutlinedButton(onClick = { page = (page + 1).coerceAtMost(totalPages - 1) }) { Text("▶") }
        }
        Row(Modifier.fillMaxWidth().weight(1f)) {
            val labelWidth = 52.dp
            Column(Modifier.width(labelWidth).fillMaxHeight().background(Color(0xFFE8E8EE))) {
                for (i in 0 until 12) {
                    val pitch = 71 - i
                    Box(Modifier.weight(1f).fillMaxWidth()
                        .background(if (pitch % 12 in setOf(1,3,6,8,10)) Color(0xFF4D4D55) else Color(0xFFE8E8EE))
                        .clickable { onPreview(pitch) }, contentAlignment = Alignment.Center) {
                        Text(LABEL_NOTES[pitch % 12], color = if (pitch % 12 in setOf(1,3,6,8,10)) Color.White else BG,
                            fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Canvas(Modifier.weight(1f).fillMaxHeight().background(SURFACE, RoundedCornerShape(12.dp))
                .pointerInput(track, page, project.notes.hashCode()) {
                    detectTapGestures(onTap = { pos ->
                        val rowH = size.height / 12f
                        val pitch = (71 - floor(pos.y / rowH).toInt()).coerceIn(60, 71)
                        val beat = startBeat + (pos.x / size.width * beatsPerPage)
                        val snapped = (round(beat * 4.0) / 4.0).coerceIn(startBeat, endBeat - .25)
                        val notes = notesState.value
                        val hit = notes.lastOrNull { n ->
                            val x = ((n.start - startBeat) / beatsPerPage * size.width).toFloat()
                            val w = (n.length / beatsPerPage * size.width).toFloat().coerceAtLeast(8f)
                            val y = (71 - n.pitch) * rowH
                            pos.x in x..(x + w) && pos.y in y..(y + rowH)
                        }
                        if (hit != null) {
                            selected = hit; onPreview(hit.pitch)
                        } else {
                            val n = MusicNote(track, pitch, snapped, .5, .82)
                            onChange { it.notes.add(n) }; selected = n; onPreview(pitch)
                        }
                    })
                }
                .pointerInput(track, page, project.notes.hashCode()) {
                    detectDragGestures(
                        onDragStart = { pos ->
                            val rowH = size.height / 12f
                            val notes = notesState.value
                            val hit = notes.lastOrNull { n ->
                                val x = ((n.start - startBeat) / beatsPerPage * size.width).toFloat()
                                val w = (n.length / beatsPerPage * size.width).toFloat().coerceAtLeast(10f)
                                val y = (71 - n.pitch) * rowH
                                pos.x in (x - 8f)..(x + w + 8f) && pos.y in y..(y + rowH)
                            }
                            dragOriginal = hit; dragPreview = hit; selected = hit
                            if (hit != null) {
                                val x = ((hit.start - startBeat) / beatsPerPage * size.width).toFloat()
                                val w = (hit.length / beatsPerPage * size.width).toFloat().coerceAtLeast(10f)
                                dragMode = when {
                                    kotlin.math.abs(pos.x - x) < 22f -> NoteDragMode.LEFT
                                    kotlin.math.abs(pos.x - (x + w)) < 22f -> NoteDragMode.RIGHT
                                    else -> NoteDragMode.MOVE
                                }
                                onPreview(hit.pitch)
                            }
                        },
                        onDrag = { change, amount ->
                            change.consume()
                            val original = dragOriginal ?: return@detectDragGestures
                            val rowH = size.height / 12f
                            val beatDelta = (amount.x / size.width * beatsPerPage)
                            val pitchDelta = (-amount.y / rowH)
                            val current = dragPreview ?: original
                            dragPreview = when (dragMode) {
                                NoteDragMode.MOVE -> {
                                    val s = (round((current.start + beatDelta) * 4.0) / 4.0)
                                        .coerceIn(startBeat, endBeat - current.length)
                                    val pch = (current.pitch + pitchDelta.roundToInt()).coerceIn(60, 71)
                                    current.copy(start = s, pitch = pch)
                                }
                                NoteDragMode.LEFT -> {
                                    val proposed = (round((current.start + beatDelta) * 4.0) / 4.0)
                                        .coerceIn(startBeat, current.start + current.length - .25)
                                    val right = current.start + current.length
                                    current.copy(start = proposed, length = (right - proposed).coerceAtLeast(.25))
                                }
                                NoteDragMode.RIGHT -> current.copy(length = (round((current.length + beatDelta) * 4.0) / 4.0)
                                    .coerceIn(.25, endBeat - current.start))
                            }
                        },
                        onDragEnd = {
                            val original = dragOriginal; val edited = dragPreview
                            if (original != null && edited != null && original != edited) {
                                onChange { p ->
                                    val idx = p.notes.indexOf(original)
                                    if (idx >= 0) p.notes[idx] = edited
                                }
                                selected = edited
                            }
                            dragOriginal = null; dragPreview = null
                        },
                        onDragCancel = { dragOriginal = null; dragPreview = null }
                    )
                }) {
                val rowH = size.height / 12f
                for (r in 0..12) drawLine(MUTED.copy(alpha = .18f), Offset(0f, r * rowH), Offset(size.width, r * rowH), 1f)
                for (b in 0..16) {
                    val x = b / 16f * size.width
                    drawLine(if (b % 4 == 0) PURPLE.copy(alpha = .35f) else MUTED.copy(alpha = .15f),
                        Offset(x, 0f), Offset(x, size.height), if (b % 4 == 0) 2f else 1f)
                }
                val notes = notesState.value
                for (n in notes) {
                    val drawNote = if (dragOriginal == n && dragPreview != null) dragPreview!! else n
                    val x = ((drawNote.start - startBeat) / beatsPerPage * size.width).toFloat()
                    val w = (drawNote.length / beatsPerPage * size.width).toFloat().coerceAtLeast(10f)
                    val y = (71 - drawNote.pitch) * rowH + 2f
                    val selectedNow = selected == n || selected == drawNote || dragOriginal == n
                    drawRoundRect(if (selectedNow) GOLD else PURPLE, Offset(x, y), Size(w, rowH - 4f),
                        androidx.compose.ui.geometry.CornerRadius(9f, 9f))
                    if (selectedNow) {
                        drawCircle(Color.White, radius = 6f, center = Offset(x + 3f, y + (rowH - 4f) / 2))
                        drawCircle(Color.White, radius = 6f, center = Offset(x + w - 3f, y + (rowH - 4f) / 2))
                    }
                }
                if (playBeat in startBeat..endBeat) {
                    val px = ((playBeat - startBeat) / beatsPerPage * size.width).toFloat()
                    drawLine(Color.White, Offset(px, 0f), Offset(px, size.height), 2.5f)
                }
            }
        }
        selected?.let { n ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    onChange { p -> p.notes.add(n.copy(start = (n.start + .5).coerceAtMost(p.bars * 4.0 - n.length))) }
                }, modifier = Modifier.weight(1f)) { Text("DUPLICAR") }
                OutlinedButton(onClick = {
                    onChange { p -> p.notes.remove(n) }; selected = null
                }, modifier = Modifier.weight(1f)) { Text("BORRAR", color = RED) }
            }
        }
    }
}

@Composable private fun SectionHeading(title: String, subtitle: String) {
    Text(title, color = GOLD, fontWeight = FontWeight.Black, fontSize = 16.sp)
    Text(subtitle, color = MUTED, fontSize = 15.sp)
}
@Composable private fun SelectPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, shape = RoundedCornerShape(9.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) PURPLE else PANEL),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier = Modifier.height(48.dp)) {
        Text(text, color = if (selected) BG else Color.White, fontSize = 15.sp,
            fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PianoRoll(p: ZetaProject, track: Int, bar: Int, octave: Int,
                      selected: MusicNote?, onTap: (Int, Double) -> Unit, modifier: Modifier) {
    val bottom = octave * 12
    Canvas(modifier.background(SURFACE, RoundedCornerShape(8.dp))
        .pointerInput(track, bar, octave, p.notes.size) {
            detectTapGestures { pos ->
                val pitch = (bottom + 23 - floor(pos.y / size.height * 24.0).toInt()).coerceIn(0, 127)
                val beat = bar * 4.0 + (floor(pos.x / size.width * 16.0) / 4.0)
                onTap(pitch, beat.coerceIn(0.0, p.bars * 4.0 - .01))
            }
        }) {
        val h = size.height / 24f
        val w = size.width / 16f
        for (i in 0..24) {
            drawLine(if (i % 12 == 0) GOLD.copy(alpha = .55f) else MUTED.copy(alpha = .20f),
                Offset(0f, i * h), Offset(size.width, i * h), 1f)
        }
        for (i in 0..16) {
            drawLine(if (i % 4 == 0) PURPLE.copy(alpha = .7f) else MUTED.copy(alpha = .17f),
                Offset(i * w, 0f), Offset(i * w, size.height), if (i % 4 == 0) 2f else 1f)
        }
        for (n in p.notes) {
            if (n.track != track || n.pitch !in bottom..bottom + 23) continue
            val start = (n.start - bar * 4.0) * 4 * w
            val end = (n.start + n.length - bar * 4.0) * 4 * w
            if (end <= 0 || start >= size.width) continue
            val y = (bottom + 23 - n.pitch) * h
            drawRect(if (n == selected) GOLD else PURPLE,
                Offset(start.toFloat().coerceAtLeast(0f) + 1f, y + 1f),
                Size((end - start).toFloat().coerceAtMost(size.width - start.toFloat().coerceAtLeast(0f)).coerceAtLeast(2f),
                    h - 2f))
        }
        drawIntoCanvas { c ->
            val paint = android.graphics.Paint().apply {
                color = android.graphics.Color.WHITE; textSize = 19f; isAntiAlias = true
            }
            for (i in 0 until 24) {
                val pitch = bottom + 23 - i
                if (pitch % 12 == 0) c.nativeCanvas.drawText("C${pitch / 12 - 1}", 3f, (i + .72f) * h, paint)
            }
        }
    }
}

@Composable
private fun PianoView(engine: ZetaAudioEngine, track: Int, octave: Int, chordMode: Int,
                      scaleMode: Int, rootNote: Int, velocity: Float, modifier: Modifier) {
    val active = remember { mutableStateMapOf<Int, List<Int>>() }
    fun notesFor(pitch: Int): List<Int> {
        val tones = when (scaleMode) {
            1 -> setOf(0, 2, 4, 5, 7, 9, 11)
            2 -> setOf(0, 2, 3, 5, 7, 8, 10)
            else -> (0..11).toSet()
        }
        val base = (pitch - 2..pitch + 2).filter { it in 0..127 && (it - rootNote).mod(12) in tones }
            .minByOrNull { kotlin.math.abs(it - pitch) } ?: pitch
        val ints = when (chordMode) { 1 -> listOf(0, 4, 7); 2 -> listOf(0, 3, 7);
            3 -> listOf(0, 4, 7, 10); else -> listOf(0) }
        return ints.map { base + it }.filter { it in 0..127 }
    }
    fun pitchAt(x: Float, y: Float, width: Float, height: Float): Int {
        val unit = width / 14
        val white = (x / unit).toInt().coerceIn(0, 13)
        val base = WHITE_NOTES[white % 7] + (white / 7) * 12
        if (y < height * .62f) {
            val fraction = x / unit - floor(x / unit)
            if (fraction > .68f && base % 12 in listOf(0, 2, 5, 7, 9))
                return (octave * 12 + 12 + base + 1).coerceIn(0, 127)
            if (fraction < .32f && white > 0) {
                val prev = WHITE_NOTES[(white - 1) % 7] + (white - 1) / 7 * 12
                if (prev % 12 in listOf(0, 2, 5, 7, 9))
                    return (octave * 12 + 12 + prev + 1).coerceIn(0, 127)
            }
        }
        return (octave * 12 + 12 + base).coerceIn(0, 127)
    }
    DisposableEffect(track, octave, chordMode, scaleMode, rootNote) {
        onDispose { active.values.flatten().forEach { engine.noteOff(track, it) }; active.clear() }
    }
    Canvas(modifier.background(SURFACE, RoundedCornerShape(10.dp))
        .pointerInput(track, octave, chordMode, scaleMode, rootNote, velocity) {
            awaitEachGesture {
                do {
                    val e = awaitPointerEvent()
                    for (change in e.changes) {
                        val id = change.id.value.toInt()
                        if (change.pressed) {
                            val notes = notesFor(pitchAt(change.position.x, change.position.y,
                                size.width.toFloat(), size.height.toFloat()))
                            val old = active[id]
                            if (old != notes) {
                                old?.forEach { engine.noteOff(track, it) }
                                notes.forEach { engine.noteOn(track, it, velocity.toDouble()) }
                                active[id] = notes
                            }
                        } else active.remove(id)?.forEach { engine.noteOff(track, it) }
                    }
                } while (e.changes.any { it.pressed })
                active.toMap().values.flatten().forEach { engine.noteOff(track, it) }
                active.clear()
            }
        }) {
        val keyW = size.width / 14
        for (i in 0 until 14) {
            val pitch = octave * 12 + 12 + WHITE_NOTES[i % 7] + i / 7 * 12
            drawRect(if (active.values.any { pitch in it }) GOLD else Color(0xFFE7E7EC),
                Offset(i * keyW, 0f), Size(keyW - 1f, size.height))
        }
        for (i in 0 until 13) {
            val n = WHITE_NOTES[i % 7]
            if (n in listOf(0, 2, 5, 7, 9)) {
                val pitch = octave * 12 + 12 + n + i / 7 * 12 + 1
                val bw = keyW * .62f
                drawRect(if (active.values.any { pitch in it }) PURPLE else Color(0xFF17171E),
                    Offset((i + 1) * keyW - bw / 2, 0f), Size(bw, size.height * .62f))
            }
        }
    }
}
