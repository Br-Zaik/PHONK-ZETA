package com.phonkzeta.musicstudio

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.ArrayDeque
import kotlin.math.*

private val BG = Color(0xFF09090B)
private val SURFACE = Color(0xFF15151D)
private val PANEL = Color(0xFF23232D)
private val PURPLE = Color(0xFF8B5CF6)
private val RED = Color(0xFFFF3B5C)
private val GOLD = Color(0xFFF5C451)
private val MUTED = Color(0xFF9B9BA8)
private val WHITE_NOTES = intArrayOf(0, 2, 4, 5, 7, 9, 11)
private val LABEL_NOTES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
private val TABS = listOf("PIANO", "PADS", "RITMOS", "PIANO ROLL", "TRACKS", "MIXER", "FX")

class MainActivity : ComponentActivity() {
    val engine = ZetaAudioEngine()
    lateinit var store: ProjectStorage
    lateinit var midi: MidiBridge
    var snapshotProvider: (() -> ZetaProject)? = null
    val micRecorder by lazy { MicRecorder(this) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStorage(this)
        val project = try { store.load("autosave") } catch (_: Exception) { demoProject() }
        engine.setProject(project)
        try { engine.setSample(store.loadSample(project.samplerName)); engine.start() } catch (_: Exception) { }
        midi = MidiBridge(this, engine)
        setContent { ZetaApp(project, this) }
    }
    override fun onPause() { super.onPause(); engine.allNotesOff() }
    override fun onStop() {
        try { snapshotProvider?.invoke()?.let { store.save(it.changeName("autosave")) } }
        catch (_: Exception) { /* Manual save and previous atomic autosave remain. */ }
        super.onStop()
    }
    override fun onDestroy() { if (::midi.isInitialized) midi.close(); micRecorder.stop(); engine.close(); super.onDestroy() }
}

private fun demoProject() = ZetaProject().apply {
    listOf(0, 6, 8, 14).forEach { steps[0][it] = true }
    listOf(4, 12).forEach { steps[1][it] = true }
    for (i in 0..15 step 2) steps[2][i] = true
    listOf(60, 63, 67, 65, 60, 58, 55, 58).forEachIndexed { i, pitch ->
        notes.add(MusicNote(6, pitch, i * .5, .42))
    }
}

@Composable
private fun ZetaApp(initial: ZetaProject, activity: MainActivity) {
    val engine = activity.engine
    val store = activity.store
    val scope = rememberCoroutineScope()
    var project by remember { mutableStateOf(initial) }
    var revision by remember { mutableIntStateOf(0) }
    // JSON arrays are mutable; explicitly observe edits so step buttons and mixer repaint.
    val observedProject = remember(revision) { project }
    DisposableEffect(activity, project) {
        activity.snapshotProvider = { project.copyDeep() }
        onDispose { activity.snapshotProvider = null }
    }
    var tab by remember { mutableStateOf("PIANO") }
    var instrument by remember { mutableIntStateOf(6) }
    var octave by remember { mutableIntStateOf(4) }
    var chordMode by remember { mutableIntStateOf(0) }
    var scaleMode by remember { mutableIntStateOf(0) }
    var rootNote by remember { mutableIntStateOf(0) }
    var playVelocity by remember { mutableFloatStateOf(.85f) }
    var playing by remember { mutableStateOf(false) }
    var transportTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(playing) {
        while (playing) { delay(75); transportTick++ }
    }
    val displayPosition = remember(transportTick) { engine.currentBar to engine.currentStep }
    var recording by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf(if (engine.active) "Estudio listo · sin Internet" else "Audio: ${engine.failure}") }
    var showProjects by remember { mutableStateOf(false) }
    var showPatterns by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<String?>(null) }
    var showHelp by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf(project.name) }
    var patternInput by remember { mutableStateOf("Mi ritmo") }
    var listProjects by remember { mutableStateOf(store.list()) }
    var listPatterns by remember { mutableStateOf(store.listPatterns()) }
    var saving by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableIntStateOf(-1) }
    var noteBar by remember { mutableIntStateOf(0) }
    var noteOctave by remember { mutableIntStateOf(4) }
    var noteLength by remember { mutableFloatStateOf(.25f) }
    var selectedNote by remember { mutableStateOf<MusicNote?>(null) }
    var page by remember { mutableIntStateOf(0) }
    var selectedStep by remember { mutableIntStateOf(-1) }
    var selectedDrum by remember { mutableIntStateOf(0) }
    var midiStatus by remember { mutableStateOf("MIDI: no conectado") }
    val soundKit = remember {
        try {
            val json = org.json.JSONArray(activity.assets.open("soundkit/manifest.json").bufferedReader().use { it.readText() })
            (0 until json.length()).mapNotNull { i -> json.optJSONObject(i) }
        } catch (_: Exception) { emptyList() }
    }
    var showKit by remember { mutableStateOf(false) }
    var kitCategory by remember { mutableStateOf("TODOS") }
    var micRecording by remember { mutableStateOf(false) }
    var micFile by remember { mutableStateOf<File?>(null) }
    var saveJob by remember { mutableStateOf<Job?>(null) }
    val undo = remember { ArrayDeque<String>() }
    val redo = remember { ArrayDeque<String>() }

    fun checkpoint() {
        if (undo.size >= 25) undo.removeFirst()
        undo.addLast(project.toJson().toString())
        redo.clear()
    }
    fun changed() {
        revision++
        engine.refresh(project)
        saveJob?.cancel()
        val snapshot = project.copyDeep()
        saveJob = scope.launch {
            delay(650)
            try { withContext(Dispatchers.IO) { store.save(snapshot.changeName("autosave")) } }
            catch (e: Exception) { notice = "No se pudo guardar: ${e.message}" }
        }
    }
    fun newProject(p: ZetaProject, resetHistory: Boolean = true) {
        if (resetHistory) try { store.save(project.copyDeep()) } catch (_: Exception) { }
        engine.stop(); playing = false; recording = false
        saveJob?.cancel(); project = p; if (resetHistory) { undo.clear(); redo.clear() }
        engine.setProject(p)
        try { engine.setSample(store.loadSample(p.samplerName)) } catch (_: Exception) { engine.setSample(null) }
        nameInput = p.name; selectedNote = null; noteBar = 0; page = 0
        changed()
    }
    fun saveNow() {
        scope.launch {
            saving = true
            try {
                saveJob?.cancel()
                val snapshot = project.copyDeep()
                withContext(Dispatchers.IO) {
                    store.save(snapshot)
                    store.save(snapshot.changeName("autosave"))
                }
                listProjects = store.list(); notice = "Proyecto guardado"
            } catch (e: Exception) { notice = "Error al guardar: ${e.message}" }
            finally { saving = false }
        }
    }
    fun stopRecord() {
        if (recording) {
            checkpoint()
            val result = engine.finishRecording().filter { it.start < project.bars * 4.0 }
            project.notes.addAll(result)
            recording = false
            notice = "${result.size} notas grabadas · abre PIANO ROLL"
            changed()
        }
    }
    val importSample = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val sound = withContext(Dispatchers.IO) {
                    val stream = activity.contentResolver.openInputStream(uri) ?: error("No se pudo leer archivo")
                    store.importSample(stream)
                }
                checkpoint(); project.samplerName = sound.filename
                engine.setSample(sound); instrument = 15; activity.midi.selectInstrument(15); changed()
                notice = "Muestra cargada · selecciona SAMPLER y toca el piano"
            } catch (e: Exception) { notice = "Error al importar muestra: ${e.message}" }
        }
    }
    val exportProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                val data = project.toJson().toString(2)
                withContext(Dispatchers.IO) {
                    activity.contentResolver.openOutputStream(uri)?.use { it.write(data.toByteArray(Charsets.UTF_8)) }
                        ?: error("No se pudo escribir proyecto")
                }
                notice = "Proyecto .phonkproj exportado (los samples se guardan por separado)"
            } catch (e: Exception) { notice = "Error exportando proyecto: ${e.message}" }
        }
    }
    val importProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val p = withContext(Dispatchers.IO) {
                    val s = activity.contentResolver.openInputStream(uri) ?: error("Sin acceso")
                    ZetaProject.fromJson(org.json.JSONObject(s.bufferedReader().use { it.readText() }))
                }
                newProject(p); showProjects = false; notice = "Proyecto importado"
            } catch (e: Exception) { notice = "Archivo de proyecto no válido: ${e.message}" }
        }
    }
    val exportWav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) scope.launch {
            exportProgress = 0
            val temp = File(activity.cacheDir, "phonk_${System.currentTimeMillis()}.wav")
            try {
                val snapshot = project.copyDeep()
                withContext(Dispatchers.IO) {
                    engine.exportWav(snapshot, temp, onProgress = { pct ->
                        activity.runOnUiThread { exportProgress = pct }
                    })
                    activity.contentResolver.openOutputStream(uri)?.use { destination ->
                        temp.inputStream().use { it.copyTo(destination) }
                    } ?: error("No se pudo guardar WAV")
                }
                notice = "WAV estéreo exportado: ${project.bars} compases"
            } catch (e: Exception) { notice = "Fallo de exportación: ${e.message}" }
            finally { temp.delete(); exportProgress = -1 }
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try { activity.micRecorder.start(); micRecording = true; notice = "Grabando micrófono para el sampler" }
            catch (e: Exception) { notice = "Error de micrófono: ${e.message}" }
        } else notice = "Se necesita permiso de micrófono para grabar audio"
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = PURPLE, secondary = GOLD,
        background = BG, surface = SURFACE, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(BG).systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("PHONK", color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp)
                Text(" ZETA", color = GOLD, fontWeight = FontWeight.Black, fontSize = 23.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showHelp = true }) { Text("?", color = GOLD) }
                TextButton(onClick = { listProjects = store.list(); showProjects = true }) { Text("PROYECTOS", fontSize = 11.sp) }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(observedProject.name, color = MUTED, fontSize = 12.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text("${project.bars} COMPASES", color = GOLD, fontSize = 10.sp)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Button(onClick = { stopRecord(); playing = engine.togglePlay() },
                    colors = ButtonDefaults.buttonColors(containerColor = PURPLE),
                    contentPadding = PaddingValues(horizontal = 15.dp)) { Text(if (playing) "Ⅱ PAUSA" else "▶ PLAY", fontSize = 12.sp) }
                Button(onClick = {
                    if (recording) stopRecord() else { engine.startRecording(); recording = true; notice = "● Grabando notas" }
                }, colors = ButtonDefaults.buttonColors(containerColor = if (recording) RED else PANEL),
                    contentPadding = PaddingValues(horizontal = 12.dp)) {
                    Text(if (recording) "■ REC" else "● REC", color = if (recording) Color.White else RED, fontSize = 12.sp)
                }
                OutlinedButton(onClick = { stopRecord(); engine.stop(); playing = false },
                    contentPadding = PaddingValues(horizontal = 12.dp)) { Text("■", color = Color.White) }
                OutlinedButton(onClick = { checkpoint(); project.bpm = (project.bpm - 1).coerceAtLeast(40); changed() },
                    contentPadding = PaddingValues(horizontal = 8.dp)) { Text("−") }
                Text("${project.bpm} BPM", color = GOLD, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                OutlinedButton(onClick = { checkpoint(); project.bpm = (project.bpm + 1).coerceAtMost(260); changed() },
                    contentPadding = PaddingValues(horizontal = 8.dp)) { Text("+") }
                TextButton(onClick = {
                    checkpoint(); project.metronome = !project.metronome; changed()
                }) { Text("♩", color = if (project.metronome) GOLD else MUTED, fontSize = 19.sp) }
                Text("${displayPosition.first + 1}:${displayPosition.second % 16 + 1}", color = MUTED, fontSize = 12.sp)
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 9.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                TABS.forEach { label ->
                    Button(onClick = { tab = label }, modifier = Modifier.height(37.dp),
                        shape = RoundedCornerShape(9.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (label == tab) PURPLE else SURFACE),
                        contentPadding = PaddingValues(horizontal = 11.dp, vertical = 2.dp)) {
                        Text(label, fontSize = 10.sp)
                    }
                }
            }
            Spacer(Modifier.height(7.dp))
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                when (tab) {
                    "PIANO" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        SectionHeading("INSTRUMENTO", "Toca, graba y crea melodías")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (4 until TRACK_COUNT).forEach { idx ->
                                SelectPill(TRACK_NAMES[idx], instrument == idx) {
                                    engine.allNotesOff(); instrument = idx; activity.midi.selectInstrument(idx)
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { octave = (octave - 1).coerceAtLeast(1) }) { Text("OCT −") }
                            Text(" OCTAVA $octave ", color = GOLD, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            OutlinedButton(onClick = { octave = (octave + 1).coerceAtMost(7) }) { Text("OCT +") }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("LIBRE", "MAYOR", "MENOR").forEachIndexed { i, label ->
                                SelectPill("ESC. $label", scaleMode == i) { scaleMode = i }
                            }
                            SelectPill("TONO: ${LABEL_NOTES[rootNote]}", false) { rootNote = (rootNote + 1) % 12 }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("UNA NOTA", "ACORDE MAYOR", "ACORDE MENOR", "SÉPTIMA").forEachIndexed { i, label ->
                                SelectPill(label, chordMode == i) { chordMode = i }
                            }
                        }
                        Text("FUERZA ${(playVelocity * 100).toInt()}%", color = MUTED, fontSize = 11.sp)
                        Slider(value = playVelocity, onValueChange = { playVelocity = it }, valueRange = .1f..1f)
                        PianoView(engine, instrument, octave, chordMode, scaleMode, rootNote, playVelocity,
                            Modifier.fillMaxWidth().height(
                            if (LocalConfiguration.current.screenWidthDp > 600) 300.dp else 215.dp))
                        Text("REC captura duración y posición de cada nota. Las notas se editan en PIANO ROLL.",
                            color = MUTED, fontSize = 12.sp)
                        if (instrument == 15) {
                            Text("SAMPLER · ${project.samplerName.ifBlank { "Importa tu propio WAV" }}", color = GOLD)
                            OutlinedButton(onClick = {
                                checkpoint(); project.samplerOneShot = !project.samplerOneShot; changed()
                            }) { Text(if (project.samplerOneShot) "MODO ONE-SHOT · tocar completo"
                                     else "MODO SUSTAIN · soltar detiene") }
                            Button(onClick = { showKit = true }) { Text("BIBLIOTECA DE 24 SONIDOS ORIGINALES") }
                            Button(onClick = { importSample.launch(arrayOf("audio/wav", "audio/x-wav", "application/octet-stream")) }) {
                                Text("IMPORTAR MUESTRA WAV")
                            }
                        }
                        OutlinedButton(onClick = {
                            activity.midi.onStatus = { midiStatus = it }
                            activity.midi.connect()
                            notice = midiStatus
                        }) { Text("CONECTAR TECLADO MIDI USB / BLUETOOTH") }
                        Text(midiStatus, color = MUTED, fontSize = 11.sp)
                        Text("Para tocar en tiempo real, es preferible usar auriculares con cable.", color = MUTED, fontSize = 11.sp)
                    }
                    "PADS" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        SectionHeading("DRUM PADS 4 × 4", "Multitouch · sintes originales")
                        val pads = listOf(0, 1, 2, 3, 0, 2, 1, 3, 6, 5, 4, 7, 0, 1, 2, 3)
                        for (r in 0..3) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                for (c in 0..3) {
                                    val track = pads[r * 4 + c]
                                    Box(Modifier.weight(1f).padding(vertical = 5.dp).height(80.dp)
                                        .background(if (track == 0) RED.copy(alpha = .22f) else SURFACE, RoundedCornerShape(12.dp))
                                        .border(1.dp, if (track == 0) RED else PURPLE.copy(alpha = .7f), RoundedCornerShape(12.dp))
                                        .pointerInput(track) {
                                            awaitEachGesture {
                                                awaitPointerEventScope {
                                                    val down = awaitPointerEvent()
                                                    val pitch = if (track < 4) intArrayOf(36, 38, 42, 39)[track] else 60
                                                    if (down.changes.any { it.pressed }) engine.noteOn(track, pitch)
                                                    do { val e = awaitPointerEvent() } while (e.changes.any { it.pressed })
                                                    engine.noteOff(track, pitch)
                                                }
                                            }
                                        }, contentAlignment = Alignment.Center) {
                                        Text(TRACK_NAMES[track], fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        Text("Puedes grabar los pads con REC; sus golpes aparecerán como notas editables.", color = MUTED, fontSize = 12.sp)
                    }
                    "RITMOS" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionHeading("STEP SEQUENCER", "Patrones editables · 16, 32 o 64 pasos")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf(16, 32, 64).forEach { length ->
                                SelectPill("$length PASOS", project.patternLength == length) {
                                    checkpoint(); project.patternLength = length; changed()
                                }
                            }
                        }
                        Text("Página ${page + 1} / ${project.patternLength / 16}", color = GOLD, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { page = (page - 1).coerceAtLeast(0) }) { Text("◀") }
                            OutlinedButton(onClick = { page = (page + 1).coerceAtMost(project.patternLength / 16 - 1) }) { Text("▶") }
                            OutlinedButton(onClick = { listPatterns = store.listPatterns(); showPatterns = true }) { Text("MIS RITMOS") }
                        }
                        for (r in 0..3) {
                            Text(TRACK_NAMES[r], color = if (r == 0) RED else GOLD, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                for (col in 0 until 16) {
                                    val step = page * 16 + col
                                    val checked = project.steps[r][step]
                                    Box(Modifier.weight(1f).height(40.dp).padding(vertical = 2.dp)
                                        .background(if (playing && displayPosition.second == step) GOLD
                                            else if (checked) (if (r == 0) RED else PURPLE) else PANEL,
                                            RoundedCornerShape(4.dp))
                                        .clickable {
                                            checkpoint(); project.steps[r][step] = !project.steps[r][step]
                                            selectedDrum = r; selectedStep = step; changed()
                                        }, contentAlignment = Alignment.Center) {
                                        if (col % 4 == 0) Text("·", color = Color.White.copy(alpha = .45f))
                                    }
                                }
                            }
                        }
                        if (selectedStep >= 0) {
                            Text("${TRACK_NAMES[selectedDrum]} · paso ${selectedStep + 1} · fuerza ${(project.velocity[selectedDrum][selectedStep] * 100).toInt()}%",
                                color = GOLD, fontSize = 12.sp)
                            Slider(value = project.velocity[selectedDrum][selectedStep].toFloat(),
                                onValueChange = { project.velocity[selectedDrum][selectedStep] = it.toDouble(); revision++ },
                                onValueChangeFinished = { changed() })
                        }
                        Text("SWING ${(project.swing * 100).toInt()}%", color = MUTED, fontSize = 12.sp)
                        Slider(value = project.swing.toFloat(), valueRange = 0f..0.75f,
                            onValueChange = { project.swing = it.toDouble(); revision++ }, onValueChangeFinished = { changed() })
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = {
                                checkpoint(); project.steps.forEach { it.fill(false) }; changed()
                            }) { Text("LIMPIAR") }
                            Button(onClick = {
                                checkpoint(); project.steps.forEach { it.fill(false) }
                                listOf(0, 6, 8, 14).forEach { project.steps[0][it] = true }
                                listOf(4, 12).forEach { project.steps[1][it] = true }
                                for (i in 0..15 step 2) project.steps[2][i] = true
                                changed()
                            }) { Text("RITMO PHONK") }
                            Button(onClick = {
                                checkpoint()
                                val rng = kotlin.random.Random(System.currentTimeMillis())
                                for (row in 0..3) project.steps[row].fill(false)
                                for (s in 0 until project.patternLength) {
                                    val beat = s % 16
                                    project.steps[0][s] = beat in listOf(0, 7, 8, 14) || (beat == 3 && rng.nextBoolean())
                                    project.steps[1][s] = beat == 4 || beat == 12
                                    project.steps[2][s] = s % 2 == 0 || rng.nextInt(12) == 0
                                    project.steps[3][s] = (beat == 12 && rng.nextBoolean())
                                }
                                project.notes.removeAll { it.track in listOf(5, 6) && it.start < 4.0 }
                                listOf(0.0, 1.5, 2.0, 3.5).forEachIndexed { i, start ->
                                    project.notes.add(MusicNote(5, listOf(36, 39, 43, 34)[i], start, .43))
                                }
                                listOf(0.0, .5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5).forEachIndexed { i, start ->
                                    project.notes.add(MusicNote(6, listOf(60, 63, 67, 65, 60, 58, 55, 58)[i], start, .3))
                                }
                                changed(); notice = "Ritmo, cowbell y bajo generados; todo editable"
                            }) { Text("GENERAR PHONK") }
                        }
                    }
                    "PIANO ROLL" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        SectionHeading("PIANO ROLL", "Notas editables: toca cuadrícula para crear o seleccionar")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            (4 until TRACK_COUNT).forEach { idx ->
                                SelectPill(TRACK_NAMES[idx], instrument == idx) { instrument = idx; activity.midi.selectInstrument(idx); selectedNote = null }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { noteBar = (noteBar - 1).coerceAtLeast(0) }) { Text("◀") }
                            Text(" COMPÁS ${noteBar + 1}/${project.bars} ", color = GOLD, fontSize = 12.sp)
                            OutlinedButton(onClick = { noteBar = (noteBar + 1).coerceAtMost(project.bars - 1) }) { Text("▶") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { noteOctave = (noteOctave - 1).coerceAtLeast(1) }) { Text("OCT −") }
                            Text("  $noteOctave  ", color = GOLD)
                            OutlinedButton(onClick = { noteOctave = (noteOctave + 1).coerceAtMost(7) }) { Text("OCT +") }
                            Text("  ${project.notes.size} notas", color = MUTED, fontSize = 11.sp)
                        }
                        PianoRoll(project, instrument, noteBar, noteOctave, selectedNote,
                            onTap = { pitch, beat ->
                                val found = project.notes.lastOrNull { it.track == instrument &&
                                    pitch == it.pitch && beat >= it.start && beat < it.start + it.length }
                                if (found != null) selectedNote = found else {
                                    checkpoint()
                                    val n = MusicNote(instrument, pitch, beat, noteLength.toDouble())
                                    project.notes.add(n); selectedNote = n; changed()
                                }
                            }, modifier = Modifier.fillMaxWidth().height(436.dp))
                        Text("Duración de nueva nota: ${"%.2f".format(noteLength)} pulsos", color = MUTED, fontSize = 11.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(.125f, .25f, .5f, 1f, 2f, 4f).forEach { v ->
                                SelectPill("${v}×", abs(noteLength - v) < .001f) { noteLength = v }
                            }
                        }
                        selectedNote?.takeIf { project.notes.contains(it) }?.let { n ->
                            Text("SELECCIONADA: ${LABEL_NOTES[n.pitch % 12]}${n.pitch / 12 - 1} · pulso ${"%.2f".format(n.start)}",
                                color = GOLD, fontSize = 12.sp)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                OutlinedButton(onClick = {
                                    checkpoint(); val newer = n.copy(pitch = (n.pitch - 1).coerceAtLeast(0))
                                    project.notes[project.notes.indexOf(n)] = newer; selectedNote = newer; changed()
                                }) { Text("− NOTA") }
                                OutlinedButton(onClick = {
                                    checkpoint(); val newer = n.copy(pitch = (n.pitch + 1).coerceAtMost(127))
                                    project.notes[project.notes.indexOf(n)] = newer; selectedNote = newer; changed()
                                }) { Text("+ NOTA") }
                                OutlinedButton(onClick = {
                                    checkpoint(); val newer = n.copy(start = (n.start - .25).coerceAtLeast(0.0))
                                    project.notes[project.notes.indexOf(n)] = newer; selectedNote = newer; changed()
                                }) { Text("←") }
                                OutlinedButton(onClick = {
                                    checkpoint(); val newer = n.copy(start = (n.start + .25).coerceAtMost(project.bars * 4.0 - .01))
                                    project.notes[project.notes.indexOf(n)] = newer; selectedNote = newer; changed()
                                }) { Text("→") }
                            }
                            Text("LARGO ${"%.2f".format(n.length)} · FUERZA ${(n.velocity * 100).toInt()}%", color = MUTED, fontSize = 12.sp)
                            Slider(value = n.length.toFloat().coerceIn(.125f, 4f), valueRange = .125f..4f,
                                onValueChange = { v ->
                                    val ix = project.notes.indexOf(n)
                                    if (ix >= 0) { val updated = project.notes[ix].copy(length = v.toDouble()); project.notes[ix] = updated; selectedNote = updated; revision++ }
                                }, onValueChangeFinished = { changed() })
                            Slider(value = n.velocity.toFloat(), onValueChange = { v ->
                                val ix = project.notes.indexOf(n)
                                if (ix >= 0) { val updated = project.notes[ix].copy(velocity = v.toDouble()); project.notes[ix] = updated; selectedNote = updated; revision++ }
                            }, onValueChangeFinished = { changed() })
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                OutlinedButton(onClick = {
                                    checkpoint(); project.notes.add(n.copy(start = (n.start + .5).coerceAtMost(project.bars * 4.0 - .01)))
                                    changed()
                                }) { Text("DUPLICAR") }
                                OutlinedButton(onClick = {
                                    checkpoint(); project.notes.remove(n); selectedNote = null; changed()
                                }) { Text("ELIMINAR", color = RED) }
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            OutlinedButton(onClick = {
                                checkpoint(); val snap = project.notes.toList()
                                project.notes.clear(); project.notes.addAll(snap.map { n ->
                                    if (n.track == instrument) n.copy(start = (round(n.start * 4) / 4.0).coerceAtMost(project.bars * 4.0 - .01)) else n
                                }); selectedNote = null; changed()
                            }) { Text("CUANTIZAR 1/16") }
                            OutlinedButton(onClick = {
                                checkpoint(); project.notes.removeAll { it.track == instrument && (it.start / 4).toInt() == noteBar }
                                selectedNote = null; changed()
                            }) { Text("VACIAR COMPÁS") }
                        }
                    }
                    "TRACKS" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionHeading("ARREGLO MUSICAL", "Activa o silencia cada instrumento por compás")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { page = (page - 1).coerceAtLeast(0) }) { Text("◀") }
                            Text(" COMPASES ${page * 8 + 1}–${min(project.bars, page * 8 + 8)} ", color = GOLD, fontSize = 12.sp)
                            OutlinedButton(onClick = { page = (page + 1).coerceAtMost((project.bars - 1) / 8) }) { Text("▶") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = {
                                checkpoint(); project.bars = (project.bars - 1).coerceAtLeast(1); changed()
                            }) { Text("−") }
                            Text("  ${project.bars} COMPASES  ", color = GOLD)
                            OutlinedButton(onClick = {
                                checkpoint(); project.bars = (project.bars + 1).coerceAtMost(BAR_LIMIT); changed()
                            }) { Text("+") }
                        }
                        for (track in 0 until TRACK_COUNT) {
                            Text(TRACK_NAMES[track], color = if (track < 4) GOLD else Color.White, fontSize = 11.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                for (bar in page * 8 until min(project.bars, page * 8 + 8)) {
                                    Box(Modifier.weight(1f).height(33.dp)
                                        .background(if (playing && displayPosition.first == bar) GOLD.copy(alpha = .70f)
                                            else if (project.arrangement[track][bar]) PURPLE.copy(alpha = .85f) else PANEL,
                                            RoundedCornerShape(6.dp))
                                        .clickable {
                                            checkpoint(); project.arrangement[track][bar] = !project.arrangement[track][bar]; changed()
                                        }, contentAlignment = Alignment.Center) {
                                        Text("${bar + 1}", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                        Text("Ritmos: se repiten según 16/32/64 pasos. Melodías: se graban en su compás correspondiente.",
                            color = MUTED, fontSize = 12.sp)
                    }
                    "MIXER" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        SectionHeading("MIXER · 16 CANALES", "Volumen, estéreo, mute y solo")
                        for (i in 0 until TRACK_COUNT) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(TRACK_NAMES[i], modifier = Modifier.weight(1f), fontSize = 11.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${(project.volumes[i] * 100).toInt()}%", color = GOLD, fontSize = 11.sp)
                                TextButton(onClick = { checkpoint(); project.muted[i] = !project.muted[i]; changed() }) {
                                    Text("M", color = if (project.muted[i]) RED else MUTED)
                                }
                                TextButton(onClick = { checkpoint(); project.solo[i] = !project.solo[i]; changed() }) {
                                    Text("S", color = if (project.solo[i]) GOLD else MUTED)
                                }
                            }
                            Slider(value = project.volumes[i].toFloat(), onValueChange = { project.volumes[i] = it.toDouble(); revision++ },
                                onValueChangeFinished = { changed() })
                            Text("PAN: ${(project.pans[i] * 100).toInt()}", color = MUTED, fontSize = 10.sp)
                            Slider(value = project.pans[i].toFloat(), valueRange = -1f..1f,
                                onValueChange = { project.pans[i] = it.toDouble(); revision++ },
                                onValueChangeFinished = { changed() })
                            HorizontalDivider(color = PANEL)
                        }
                    }
                    "FX" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeading("MASTER FX", "Efectos DSP integrados en la reproducción y WAV")
                        Text("SATURACIÓN / DRIVE ${(project.drive * 100).toInt()}%", color = GOLD)
                        Slider(value = project.drive.toFloat(), onValueChange = { project.drive = it.toDouble(); revision++ },
                            onValueChangeFinished = { changed() })
                        Text("DELAY ${(project.delay * 100).toInt()}%", color = GOLD)
                        Slider(value = project.delay.toFloat(), onValueChange = { project.delay = it.toDouble(); revision++ },
                            onValueChangeFinished = { changed() })
                        Text("La saturación y el delay se procesan directamente sobre ambos canales. No se incluyen efectos que no funcionen.",
                            color = MUTED, fontSize = 12.sp)
                        HorizontalDivider(color = PANEL)
                        SectionHeading("GRABACIÓN DE AUDIO", "Micrófono → muestra WAV → sampler")
                        Button(onClick = {
                            if (!micRecording) {
                                if (activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                    try { activity.micRecorder.start(); micRecording = true; notice = "Grabando micrófono…" }
                                    catch (e: Exception) { notice = "Error: ${e.message}" }
                                } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                val file = activity.micRecorder.stop(); micRecording = false; micFile = file
                                notice = "Grabación guardada: ${file?.name ?: "error"}"
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = if (micRecording) RED else PURPLE)) {
                            Text(if (micRecording) "■ DETENER MICRÓFONO" else "● GRABAR MICRÓFONO")
                        }
                        micFile?.let { f ->
                            Button(onClick = { scope.launch {
                                try {
                                    val snd = withContext(Dispatchers.IO) { store.importSample(f.inputStream()) }
                                    checkpoint(); project.samplerName = snd.filename; engine.setSample(snd)
                                    instrument = 15; activity.midi.selectInstrument(15); tab = "PIANO"; changed(); notice = "Audio importado al SAMPLER"
                                } catch (e: Exception) { notice = "Error leyendo audio: ${e.message}" }
                            } }) { Text("USAR GRABACIÓN COMO INSTRUMENTO") }
                        }
                        Button(onClick = { showKit = true }) { Text("BIBLIOTECA ORIGINAL · 24 SONIDOS") }
                        Button(onClick = { importSample.launch(arrayOf("audio/wav", "audio/x-wav", "application/octet-stream")) }) {
                            Text("IMPORTAR WAV PROPIO")
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(notice, modifier = Modifier.weight(1f), color = GOLD, fontSize = 11.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = {
                    if (undo.isNotEmpty()) {
                        redo.addLast(project.toJson().toString())
                        newProject(ZetaProject.fromJson(org.json.JSONObject(undo.removeLast())), resetHistory = false)
                        notice = "Deshacer"
                    }
                }, enabled = undo.isNotEmpty()) { Text("↶", fontSize = 20.sp) }
                TextButton(onClick = {
                    if (redo.isNotEmpty()) {
                        undo.addLast(project.toJson().toString())
                        newProject(ZetaProject.fromJson(org.json.JSONObject(redo.removeLast())), resetHistory = false)
                        notice = "Rehacer"
                    }
                }, enabled = redo.isNotEmpty()) { Text("↷", fontSize = 20.sp) }
            }
            if (exportProgress >= 0) LinearProgressIndicator(progress = { exportProgress / 100f }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { saveNow() }, enabled = !saving, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = PANEL)) { Text("GUARDAR", fontSize = 12.sp) }
                Button(onClick = { exportWav.launch("${project.name.take(40)}.wav") },
                    enabled = exportProgress < 0, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = PURPLE)) { Text("EXPORTAR WAV", fontSize = 12.sp) }
            }
        }
        if (showProjects) AlertDialog(onDismissRequest = { showProjects = false },
            title = { Text("MIS PROYECTOS") }, text = {
                Column {
                    OutlinedTextField(value = nameInput, onValueChange = { nameInput = it.take(60) },
                        label = { Text("Nombre") }, singleLine = true)
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        TextButton(onClick = {
                            checkpoint(); project.name = nameInput.ifBlank { "Mi PHONK" }; saveNow(); showProjects = false
                        }) { Text("RENOMBRAR Y GUARDAR") }
                        TextButton(onClick = {
                            val title = "Proyecto " + java.text.SimpleDateFormat("ddMMyy_HHmmss", java.util.Locale.getDefault())
                                .format(java.util.Date())
                            newProject(ZetaProject(name = title)); showProjects = false
                        }) { Text("NUEVO") }
                    }
                    TextButton(onClick = { exportProject.launch("${project.name}.phonkproj") }) { Text("EXPORTAR PROYECTO") }
                    TextButton(onClick = { importProject.launch(arrayOf("application/json", "application/octet-stream", "*/*")) }) {
                        Text("IMPORTAR PROYECTO")
                    }
                    HorizontalDivider(color = PANEL)
                    LazyColumn(Modifier.heightIn(max = 270.dp)) {
                        items(listProjects) { n ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = {
                                    try { newProject(store.load(n)); showProjects = false; notice = "Abierto $n" }
                                    catch (e: Exception) { notice = "Error: ${e.message}" }
                                }, modifier = Modifier.weight(1f)) {
                                    Text(n, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                TextButton(onClick = {
                                    if (n != "autosave") pendingDelete = n
                                }) { Text("✕", color = RED) }
                            }
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showProjects = false }) { Text("CERRAR") } })
        pendingDelete?.let { target ->
            AlertDialog(onDismissRequest = { pendingDelete = null },
                title = { Text("¿ELIMINAR PROYECTO?") },
                text = { Text("Se eliminará '$target'. Esta acción no se puede deshacer.") },
                confirmButton = { TextButton(onClick = {
                    store.remove(target); listProjects = store.list(); pendingDelete = null
                    notice = "Proyecto eliminado"
                }) { Text("ELIMINAR", color = RED) } },
                dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("CANCELAR") } })
        }
        if (showPatterns) AlertDialog(onDismissRequest = { showPatterns = false },
            title = { Text("MIS RITMOS") }, text = {
                Column {
                    OutlinedTextField(value = patternInput, onValueChange = { patternInput = it.take(60) },
                        label = { Text("Nombre del ritmo") }, singleLine = true)
                    Button(onClick = {
                        try {
                            store.savePattern(project, patternInput)
                            listPatterns = store.listPatterns(); notice = "Ritmo guardado"; showPatterns = false
                        } catch (e: Exception) { notice = "Error: ${e.message}" }
                    }) { Text("GUARDAR RITMO ACTUAL") }
                    LazyColumn(Modifier.heightIn(max = 270.dp)) {
                        items(listPatterns) { n ->
                            TextButton(onClick = {
                                try { checkpoint(); store.loadPattern(project, n); changed(); showPatterns = false; notice = "Ritmo aplicado: $n" }
                                catch (e: Exception) { notice = "Error: ${e.message}" }
                            }) { Text(n) }
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showPatterns = false }) { Text("CERRAR") } })
        if (showKit) AlertDialog(onDismissRequest = { showKit = false },
            title = { Text("BIBLIOTECA DE SONIDOS") }, text = {
                Column {
                    Text("24 WAV sintetizados originalmente para esta app; selecciona uno para el sampler.", color = MUTED, fontSize = 11.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        listOf("TODOS", "KICK", "SNARE", "HAT", "COWBELL", "808", "FX").forEach { cat ->
                            SelectPill(cat, kitCategory == cat) { kitCategory = cat }
                        }
                    }
                    LazyColumn(Modifier.heightIn(max = 350.dp)) {
                        items(soundKit.filter { kitCategory == "TODOS" || it.optString("category") == kitCategory }) { sound ->
                            TextButton(onClick = { scope.launch {
                                try {
                                    val file = sound.getString("file")
                                    val data = withContext(Dispatchers.IO) {
                                        store.importSample(activity.assets.open("soundkit/$file"))
                                    }
                                    checkpoint(); project.samplerName = data.filename
                                    project.samplerRoot = sound.optInt("root", 60)
                                    engine.setSample(data); instrument = 15; activity.midi.selectInstrument(15)
                                    changed(); tab = "PIANO"; showKit = false
                                    notice = "Sonido cargado: ${sound.optString("name")}"
                                } catch (e: Exception) { notice = "Error: ${e.message}" }
                            } }) {
                                Text("${sound.optString("category")}  ·  ${sound.optString("name")}")
                            }
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showKit = false }) { Text("CERRAR") } })
        if (showHelp) AlertDialog(onDismissRequest = { showHelp = false }, title = { Text("PHONK ZETA") },
            text = { Text("1. Toca PIANO o PADS. 2. Pulsa REC. 3. Edita en PIANO ROLL. " +
                "4. Diseña baterías en RITMOS y guarda patrones en MIS RITMOS. " +
                "5. Activa compases en TRACKS. 6. Mezcla, aplica FX y exporta WAV. " +
                "La biblioteca usa síntesis propia; importa tus WAV para el SAMPLER. No se requiere Internet.") },
            confirmButton = { TextButton(onClick = { showHelp = false }) { Text("OK") } })
    }
}

@Composable private fun SectionHeading(title: String, subtitle: String) {
    Text(title, color = GOLD, fontWeight = FontWeight.Black, fontSize = 16.sp)
    Text(subtitle, color = MUTED, fontSize = 11.sp)
}
@Composable private fun SelectPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, shape = RoundedCornerShape(9.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (selected) PURPLE else PANEL),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier = Modifier.height(36.dp)) { Text(text, fontSize = 10.sp) }
}

@Composable
private fun PianoRoll(p: ZetaProject, track: Int, bar: Int, octave: Int,
                      selected: MusicNote?, onTap: (Int, Double) -> Unit, modifier: Modifier) {
    val bottom = octave * 12
    Canvas(modifier.background(SURFACE, RoundedCornerShape(8.dp))
        .pointerInput(track, bar, octave, p.notes.size) {
            detectTapGestures { pos ->
                val pitch = (bottom + 23 - floor(pos.y / size.height * 24.0).toInt()).coerceIn(0, 127)
                val beat = bar * 4.0 + (floor(pos.x / size.width * 16.0) / 4.0)
                onTap(pitch, beat.coerceIn(0.0, p.bars * 4.0 - .01))
            }
        }) {
        val h = size.height / 24f
        val w = size.width / 16f
        for (i in 0..24) {
            drawLine(if (i % 12 == 0) GOLD.copy(alpha = .55f) else MUTED.copy(alpha = .20f),
                Offset(0f, i * h), Offset(size.width, i * h), 1f)
        }
        for (i in 0..16) {
            drawLine(if (i % 4 == 0) PURPLE.copy(alpha = .7f) else MUTED.copy(alpha = .17f),
                Offset(i * w, 0f), Offset(i * w, size.height), if (i % 4 == 0) 2f else 1f)
        }
        for (n in p.notes) {
            if (n.track != track || n.pitch !in bottom..bottom + 23) continue
            val start = (n.start - bar * 4.0) * 4 * w
            val end = (n.start + n.length - bar * 4.0) * 4 * w
            if (end <= 0 || start >= size.width) continue
            val y = (bottom + 23 - n.pitch) * h
            drawRect(if (n == selected) GOLD else PURPLE,
                Offset(start.toFloat().coerceAtLeast(0f) + 1f, y + 1f),
                Size((end - start).toFloat().coerceAtMost(size.width - start.toFloat().coerceAtLeast(0f)).coerceAtLeast(2f),
                    h - 2f))
        }
        drawIntoCanvas { c ->
            val paint = android.graphics.Paint().apply {
                color = android.graphics.Color.WHITE; textSize = 19f; isAntiAlias = true
            }
            for (i in 0 until 24) {
                val pitch = bottom + 23 - i
                if (pitch % 12 == 0) c.nativeCanvas.drawText("C${pitch / 12 - 1}", 3f, (i + .72f) * h, paint)
            }
        }
    }
}

@Composable
private fun PianoView(engine: ZetaAudioEngine, track: Int, octave: Int, chordMode: Int,
                      scaleMode: Int, rootNote: Int, velocity: Float, modifier: Modifier) {
    val active = remember { mutableStateMapOf<Int, List<Int>>() }
    fun notesFor(pitch: Int): List<Int> {
        val tones = when (scaleMode) {
            1 -> setOf(0, 2, 4, 5, 7, 9, 11)
            2 -> setOf(0, 2, 3, 5, 7, 8, 10)
            else -> (0..11).toSet()
        }
        val base = (pitch - 2..pitch + 2).filter { it in 0..127 && (it - rootNote).mod(12) in tones }
            .minByOrNull { kotlin.math.abs(it - pitch) } ?: pitch
        val ints = when (chordMode) { 1 -> listOf(0, 4, 7); 2 -> listOf(0, 3, 7);
            3 -> listOf(0, 4, 7, 10); else -> listOf(0) }
        return ints.map { base + it }.filter { it in 0..127 }
    }
    fun pitchAt(x: Float, y: Float, width: Float, height: Float): Int {
        val unit = width / 14
        val white = (x / unit).toInt().coerceIn(0, 13)
        val base = WHITE_NOTES[white % 7] + (white / 7) * 12
        if (y < height * .62f) {
            val fraction = x / unit - floor(x / unit)
            if (fraction > .68f && base % 12 in listOf(0, 2, 5, 7, 9))
                return (octave * 12 + 12 + base + 1).coerceIn(0, 127)
            if (fraction < .32f && white > 0) {
                val prev = WHITE_NOTES[(white - 1) % 7] + (white - 1) / 7 * 12
                if (prev % 12 in listOf(0, 2, 5, 7, 9))
                    return (octave * 12 + 12 + prev + 1).coerceIn(0, 127)
            }
        }
        return (octave * 12 + 12 + base).coerceIn(0, 127)
    }
    DisposableEffect(track, octave, chordMode, scaleMode, rootNote) {
        onDispose { active.values.flatten().forEach { engine.noteOff(track, it) }; active.clear() }
    }
    Canvas(modifier.background(SURFACE, RoundedCornerShape(10.dp))
        .pointerInput(track, octave, chordMode, scaleMode, rootNote, velocity) {
            awaitEachGesture {
                awaitPointerEventScope {
                    do {
                        val e = awaitPointerEvent()
                        for (change in e.changes) {
                            val id = change.id.value.toInt()
                            if (change.pressed) {
                                val notes = notesFor(pitchAt(change.position.x, change.position.y,
                                    size.width.toFloat(), size.height.toFloat()))
                                val old = active[id]
                                if (old != notes) {
                                    old?.forEach { engine.noteOff(track, it) }
                                    notes.forEach { engine.noteOn(track, it, velocity.toDouble()) }
                                    active[id] = notes
                                }
                            } else active.remove(id)?.forEach { engine.noteOff(track, it) }
                        }
                    } while (e.changes.any { it.pressed })
                    active.toMap().values.flatten().forEach { engine.noteOff(track, it) }
                    active.clear()
                }
            }
        }) {
        val keyW = size.width / 14
        for (i in 0 until 14) {
            val pitch = octave * 12 + 12 + WHITE_NOTES[i % 7] + i / 7 * 12
            drawRect(if (active.values.any { pitch in it }) GOLD else Color(0xFFE7E7EC),
                Offset(i * keyW, 0f), Size(keyW - 1f, size.height))
        }
        for (i in 0 until 13) {
            val n = WHITE_NOTES[i % 7]
            if (n in listOf(0, 2, 5, 7, 9)) {
                val pitch = octave * 12 + 12 + n + i / 7 * 12 + 1
                val bw = keyW * .62f
                drawRect(if (active.values.any { pitch in it }) PURPLE else Color(0xFF17171E),
                    Offset((i + 1) * keyW - bw / 2, 0f), Size(bw, size.height * .62f))
            }
        }
    }
}
