package com.phonkzeta.musicstudio

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test
import java.io.ByteArrayOutputStream

class ProjectAndWaveTest {
    @Test fun roundTripProjectAndArrangement() {
        val p = ZetaProject(name = "PHONK", bpm = 172, bars = 12, patternLength = 32)
        p.steps[0][21] = true; p.velocity[0][21] = .25
        p.arrangement[6][4] = false; p.pans[5] = -.45; p.solo[5] = true
        p.notes.add(MusicNote(6, 70, 14.125, 1.75, .6))
        p.metronome = true
        val copy = ZetaProject.fromJson(JSONObject(p.toJson().toString()))
        assertEquals(172, copy.bpm)
        assertEquals(12, copy.bars)
        assertEquals(32, copy.patternLength)
        assertTrue(copy.steps[0][21])
        assertEquals(.25, copy.velocity[0][21], 1e-5)
        assertFalse(copy.arrangement[6][4])
        assertTrue(copy.solo[5])
        assertEquals(-.45, copy.pans[5], 1e-5)
        assertEquals(1.75, copy.notes[0].length, 1e-5)
        assertTrue(copy.metronome)
    }
    @Test fun migrationFromOldVersionKeepsDrumNotes() {
        val j = JSONObject("""{"schema":1,"name":"Old","bpm":150,"steps":[[true,false]],"notes":[{"track":6,"pitch":60,"start":0.5,"length":0.25,"velocity":0.8}]}""")
        val p = ZetaProject.fromJson(j)
        assertTrue(p.steps[0][0]); assertEquals(1, p.notes.size)
        assertEquals(64, p.steps[0].size)
    }
    @Test fun decodeValidPcm16Wav() {
        val sample = ByteArrayOutputStream()
        fun write(s: String) { sample.write(s.toByteArray(Charsets.US_ASCII)) }
        fun le(x: Int, n: Int) { repeat(n) { sample.write((x ushr (8 * it)) and 255) } }
        write("RIFF"); le(44, 4); write("WAVEfmt "); le(16, 4)
        le(1, 2); le(1, 2); le(48000, 4); le(96000, 4); le(2, 2); le(16, 2)
        write("data"); le(8, 4)
        listOf(0, 32767, -32768, 0).forEach { le(it, 2) }
        val sound = WaveDecoder.decode(sample.toByteArray())
        assertEquals(48000, sound.sampleRate)
        assertEquals(4, sound.pcm.size)
        assertEquals(-1f, sound.pcm[2], .0001f)
    }
    @Test(expected = IllegalArgumentException::class)
    fun rejectNonWaveInput() { WaveDecoder.decode(ByteArray(44)) }
}
