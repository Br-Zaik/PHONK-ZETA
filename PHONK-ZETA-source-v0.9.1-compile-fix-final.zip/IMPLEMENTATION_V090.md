# PHONK ZETA 0.9.0

Rediseño real del modo fácil.

- El modo fácil ya no reutiliza la interfaz antigua: tiene shell propio.
- Inicio, Editor, Pads/Melodía y Exportar son pantallas separadas.
- Se eliminan barras duplicadas y exportación fija del modo fácil.
- Editor compacto tipo timeline, sin el encabezado pesado de la versión anterior.
- Piano roll fácil con notas móviles y bordes arrastrables para cambiar duración.
- Pads grandes y teclado melódico en pantalla propia.
- La navegación fácil queda en una sola barra inferior.
- El modo Estudio avanzado se conserva aparte.
- Optimización: los detectores pointerInput del editor ya no se reinician en cada actualización del playhead.
- Actualización del transporte visual reducida para evitar recomposiciones excesivas.
