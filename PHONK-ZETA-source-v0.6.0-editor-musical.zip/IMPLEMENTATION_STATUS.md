# Estado 0.6.0 — código actualizado, build Android por verificar

- Editor timeline `TimelineEditor.kt` con paginación de 8 compases, cursores, mm:ss, zoom, reproducción desde marca y arreglo visual; bloques musicales por compás y editor de clips de audio importados. Se ha añadido audioBank para usar las mismas posiciones/ganancias en PLAY y render WAV/M4A.
- Nuevo formato JSON schema 5, lector de proyectos schema 1–5. Límite de 8 bloques y 4 archivos de audio distintos residentes en RAM (audio por archivo hasta 240 s); canción hasta 512 compases. Limitación práctica de memoria para Moto e30.
- Slider de duración/ciclo por segundos; piano vertical con notas arriba y horizontal con notas opcionales. Variaciones de batería en generador.
- Tests JVM de serialización y arreglo + WAV de clip desplazado añadidos; deben correr en GitHub Actions con Android/Gradle real.
- **No verificado todavía:** APK compilado, latencia táctil/rotación, mezcla en teléfono con 4 audios largos. No anunciar como libre de fallos.
- **Pendiente avanzado:** clips MIDI completamente independientes fuera de la rejilla por compases; arrastre preciso de extremos por píxel; streaming de audio del almacenamiento en lugar de decodificar en memoria; time-stretch/auto-pitch para adaptar MP3 al BPM; exportar MP3; Oboe y compresor/FX por pista; proyecto portable con audio empaquetado.

---

# Estado v0.5.0

Ver IMPLEMENTATION_V050.md. La compilación de esta versión y sus pruebas en Android están PENDIENTES de GitHub Actions; no se ha certificado un APK.

# v0.4.0 (código fuente)
- Ver `IMPLEMENTATION_V040.md` para implementación y limitaciones.
- No afirmar compilación o prueba Android completa sin GitHub Actions.
- BAR_LIMIT ahora 512, grabaciones JSON schema 3, interfaz reestructurada.

## Corrección v0.2.3 (20/09/2026)
- Registro real de GitHub Actions: run 35521763708, job 106106951934.
- Arreglados los dos errores Kotlin `Restricted suspending functions can invoke ...` en MainActivity.kt (antes líneas 380 y 894).
- Eliminada la llamada anidada a `awaitPointerEventScope` dentro de `awaitEachGesture` en los Drum Pads y PianoView: ahora los eventos se esperan directamente en el scope de gestos.
- Comprobado por inspección local que el archivo ya no contiene ese patrón. AÚN NO verificado por compilación Android ni prueba en dispositivo; el run debe repetirse con este ZIP.

# PHONK ZETA 0.2.0 — Estado verificado con precisión

Estado de cada punto: **Código** = hay implementación fuente, no significa probado en Android. **Validado local** = test limitado completado con herramientas disponibles. **Pendiente** = no existe función completa; no presentar como funcional.

| Componente | Estado |
|---|---|
| Proyecto Android/CI Kotlin/Compose | Código; falta build Android real |
| Motor de audio AudioTrack PCM16 48 kHz | Código; backend compiló con stubs; teléfono sin probar |
| Scheduler de notas en frames, longitudes de nota y loop de hasta 128 compases | Código; sin mediciones en hardware |
| Piano multitáctil y velocity/chords/escalas | Código; sin prueba táctil en teléfono |
| 12 timbres sintetizados + 4 baterías | Código; síntesis original, no instrumentos acústicos grabados |
| Pad 4×4 | Código |
| Secuenciador 16/32/64 pasos, swing y velocity | Código |
| Ritmos independientes guardables/reutilizables | Código |
| Generador editable PHONK | Código (algorítmico básico, sin IA) |
| Piano Roll por compás con edición de nota/longitud/velocity | Código (sin drag libre multi-select avanzado) |
| Arreglo por compases 16 canales | Código (activar/silenciar, no clips libremente arrastrables) |
| Mixer pan/volumen/mute/solo 16 canales | Código |
| Drive y delay en motor + WAV | Código |
| Metrónomo excluido de exportación | Código |
| Sampler WAV mono/estéreo PCM16 + one-shot/sustain | Código; limitado a una muestra activa |
| 24 muestras integradas originales | Validado local: 24/24 WAV decodificados |
| Grabador WAV de micrófono importable al sampler | Código; requiere permiso; hardware sin probar |
| MIDI USB/Bluetooth input de notas | Código básico; no verificado con controladores físicos |
| Guardado atómico, autosave, JSON v1→v2 | Código; pruebas JVM preparadas |
| Proyecto exportable/importable `.phonkproj` JSON | Código; samples no empaquetados |
| WAV final PCM16 estéreo 48 kHz | Código; requiere prueba final Android |
| GitHub Actions test+lint+build --continue | Código; ejecución remota pendiente |
| Oboe/C++ NDK + latencia profesional medida | Pendiente |
| Audio clips multipista y edición de audio por región | Pendiente |
| Mixer buses/ruteo/efectos por canal/EQ/compresor/sidechain/automatización | Pendiente |
| Sampler slicing/chopping y pads con samples independientes | Pendiente |
| Import/export MIDI SMF; pitch bend/CC avanzado | Pendiente |
| WAV24, FLAC, AAC, MP3, stems | Pendiente |
| `.phonkproj` portable con WAV empaquetados | Pendiente |
| Samples acústicos profesionales adicionales con licencias verificadas | Pendiente |
| APK release firmado, Play Store y pruebas instrumentadas | Pendiente |

**No afirmar «sin errores» o «aplicación terminada» hasta que compile y pase tests en Actions y pruebas manuales de audio en Android real.**


### v0.2.2 — build fix
- Corregida coordenada Gradle `androidx.compose.material3:material3` (el typo anterior produjo `ModuleVersionNotFoundException` en GitHub Actions).
- Workflow incluye un hotfix idempotente para el ZIP v0.2.1 ya subido al repo.
- APK aún no verificado en GitHub Actions después de este cambio.
