package com.phonkzeta.musicstudio

import kotlin.random.Random

/** Original, editable multi-track ideas. This never embeds a third-party song. */
object EasyPhonk {
    val styles = listOf("DRIFT", "DARK", "AGRESIVO", "BRAZILIAN", "SLOWED")
    fun generate(p: ZetaProject, style: String, bars: Int = 24, seed: Int = Random.nextInt()) {
        val rnd = Random(seed)
        p.bpm = when (style) {
            "SLOWED" -> 96
            "DARK" -> 130
            "BRAZILIAN" -> 142
            "AGRESIVO" -> 165
            else -> 150
        }
        p.bars = bars.coerceIn(2, BAR_LIMIT)
        p.patternLength = 16
        p.swing = if (style == "BRAZILIAN") .12 else .025
        p.drive = if (style == "AGRESIVO") .39 else .19
        p.delay = if (style == "DARK" || style == "SLOWED") .18 else .08
        for (row in 0..3) {
            p.steps[row].fill(false)
            p.velocity[row].fill(.85)
        }
        for (s in 0 until 16) {
            p.steps[0][s] = s in (if (style == "BRAZILIAN") listOf(0,3,6,8,11,14) else listOf(0,6,8,14))
            p.steps[1][s] = s in listOf(4, 12)
            p.steps[2][s] = s % (if (style == "SLOWED") 4 else 2) == 0
            p.steps[3][s] = s in (if (style == "BRAZILIAN") listOf(2,7,10,15) else listOf(12))
            p.velocity[2][s] = if (s % 4 == 0) .9 else .65
        }
        p.notes.removeAll { it.track in 5..11 }
        val root = listOf(36, 38, 41, 43, 45)[rnd.nextInt(5)]
        val minor = intArrayOf(0, 3, 5, 7, 10, 12)
        val phrase = intArrayOf(0, 1, 3, 2, 0, 4, 3, 1).map { minor[it] }
        for (bar in 0 until p.bars) {
            val section = bar.toDouble() / p.bars
            val outro = section >= .94
            val drop = !outro && (section >= .13 && section < .77 || section >= .84)
            if (!drop) {
                p.arrangement[0][bar] = false
                p.arrangement[1][bar] = false
                p.arrangement[5][bar] = false
            } else {
                p.arrangement[0][bar] = true
                p.arrangement[1][bar] = true
                p.arrangement[5][bar] = true
            }
            p.arrangement[2][bar] = drop
            p.arrangement[3][bar] = drop
            p.arrangement[6][bar] = true
            val variant = when (bar % 8) {
                3, 7 -> 1
                5 -> 2
                else -> 0
            }
            for (n in 0 until 8) {
                val pitch = root + 24 + phrase[(n + variant) % phrase.size]
                if (bar % 4 != 2 || n % 2 == 0) p.notes.add(MusicNote(6, pitch, bar * 4.0 + n * .5,
                    if (style == "SLOWED") .48 else .32, if (n % 4 == 0) .85 else .58))
            }
            if (drop) for (beat in listOf(0.0, 1.5, 2.0, 3.5)) {
                p.notes.add(MusicNote(5, root + if (beat == 3.5 && bar % 2 == 1) 7 else 0,
                    bar * 4.0 + beat, if (style == "SLOWED") .85 else .58, .86))
            }
            if (bar % 4 == 3 && drop) {
                p.notes.add(MusicNote(9, root + 36, bar * 4.0 + 3.0, .8, .38))
            }
            // Drum variations are actual notes on the timeline, not just a 16-step loop.
            if (drop && bar % 8 in listOf(1, 5)) {
                p.notes.add(MusicNote(0, 36, bar * 4.0 + 2.75, .12, .62))
                p.notes.add(MusicNote(2, 42, bar * 4.0 + 3.75, .085, .47))
            }
            if (drop && bar % 8 == 4) {
                p.notes.add(MusicNote(1, 38, bar * 4.0 + 3.0, .15, .48))
                p.notes.add(MusicNote(6, root + 24 + phrase[3], bar * 4.0 + 3.5, .22, .62))
            }
            // Distinct short fills around each transition; the entire song is not one repeated loop.
            if (bar % 8 == 7 && drop && bar + 1 < p.bars) {
                for (beat in listOf(3.0, 3.25, 3.5, 3.75))
                    p.notes.add(MusicNote(2, 42, bar * 4.0 + beat, .09, .55 + (beat - 3.0) * .22))
                p.notes.add(MusicNote(0, 36, bar * 4.0 + 3.5, .13, .96))
            }
            if (bar % 8 == 6 && drop) {
                p.notes.add(MusicNote(5, root + 7, bar * 4.0 + 3.25, .65, .67))
            }
        }
        p.name = "PHONK $style"
    }
}
