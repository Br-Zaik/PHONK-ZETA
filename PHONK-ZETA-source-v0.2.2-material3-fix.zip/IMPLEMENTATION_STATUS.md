# PHONK ZETA 0.2.0 — Estado verificado con precisión

Estado de cada punto: **Código** = hay implementación fuente, no significa probado en Android. **Validado local** = test limitado completado con herramientas disponibles. **Pendiente** = no existe función completa; no presentar como funcional.

| Componente | Estado |
|---|---|
| Proyecto Android/CI Kotlin/Compose | Código; falta build Android real |
| Motor de audio AudioTrack PCM16 48 kHz | Código; backend compiló con stubs; teléfono sin probar |
| Scheduler de notas en frames, longitudes de nota y loop de hasta 128 compases | Código; sin mediciones en hardware |
| Piano multitáctil y velocity/chords/escalas | Código; sin prueba táctil en teléfono |
| 12 timbres sintetizados + 4 baterías | Código; síntesis original, no instrumentos acústicos grabados |
| Pad 4×4 | Código |
| Secuenciador 16/32/64 pasos, swing y velocity | Código |
| Ritmos independientes guardables/reutilizables | Código |
| Generador editable PHONK | Código (algorítmico básico, sin IA) |
| Piano Roll por compás con edición de nota/longitud/velocity | Código (sin drag libre multi-select avanzado) |
| Arreglo por compases 16 canales | Código (activar/silenciar, no clips libremente arrastrables) |
| Mixer pan/volumen/mute/solo 16 canales | Código |
| Drive y delay en motor + WAV | Código |
| Metrónomo excluido de exportación | Código |
| Sampler WAV mono/estéreo PCM16 + one-shot/sustain | Código; limitado a una muestra activa |
| 24 muestras integradas originales | Validado local: 24/24 WAV decodificados |
| Grabador WAV de micrófono importable al sampler | Código; requiere permiso; hardware sin probar |
| MIDI USB/Bluetooth input de notas | Código básico; no verificado con controladores físicos |
| Guardado atómico, autosave, JSON v1→v2 | Código; pruebas JVM preparadas |
| Proyecto exportable/importable `.phonkproj` JSON | Código; samples no empaquetados |
| WAV final PCM16 estéreo 48 kHz | Código; requiere prueba final Android |
| GitHub Actions test+lint+build --continue | Código; ejecución remota pendiente |
| Oboe/C++ NDK + latencia profesional medida | Pendiente |
| Audio clips multipista y edición de audio por región | Pendiente |
| Mixer buses/ruteo/efectos por canal/EQ/compresor/sidechain/automatización | Pendiente |
| Sampler slicing/chopping y pads con samples independientes | Pendiente |
| Import/export MIDI SMF; pitch bend/CC avanzado | Pendiente |
| WAV24, FLAC, AAC, MP3, stems | Pendiente |
| `.phonkproj` portable con WAV empaquetados | Pendiente |
| Samples acústicos profesionales adicionales con licencias verificadas | Pendiente |
| APK release firmado, Play Store y pruebas instrumentadas | Pendiente |

**No afirmar «sin errores» o «aplicación terminada» hasta que compile y pase tests en Actions y pruebas manuales de audio en Android real.**


### v0.2.2 — build fix
- Corregida coordenada Gradle `androidx.compose.material3:material3` (el typo anterior produjo `ModuleVersionNotFoundException` en GitHub Actions).
- Workflow incluye un hotfix idempotente para el ZIP v0.2.1 ya subido al repo.
- APK aún no verificado en GitHub Actions después de este cambio.
