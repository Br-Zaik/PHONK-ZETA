package com.phonkzeta.musicstudio

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.round

object StudioEdits {
    private fun snapQuarter(value: Double): Double = round(value * 4.0) / 4.0

    fun addInstrument(project: ZetaProject, track: Int, title: String) {
        if (track !in 4 until TRACK_COUNT) return
        project.laneAdded[track] = true
        project.instrumentIds[track] = track
        project.laneNames[track] = title.take(24)
        project.volumes[track] = project.volumes[track].coerceIn(.0, 1.0)
    }

    fun moveResizeAudio(project: ZetaProject, id: String, deltaBeats: Double, mode: Int) {
        val clip = project.audioClips.firstOrNull { it.id == id } ?: return
        val maxBeat = max(project.bars * 4.0, clip.startBeat + clip.lengthBeats + 4.0)
        val delta = snapQuarter(deltaBeats)
        when (mode) {
            -1 -> {
                val spb = 60.0 / project.bpm
                val minDelta = -clip.trimSeconds / spb
                val maxDelta = clip.lengthBeats - .25
                val d = delta.coerceIn(minDelta, maxDelta)
                clip.startBeat = (clip.startBeat + d).coerceAtLeast(0.0)
                clip.trimSeconds = (clip.trimSeconds + d * spb).coerceAtLeast(0.0)
                clip.lengthBeats = (clip.lengthBeats - d).coerceAtLeast(.25)
            }
            1 -> clip.lengthBeats = (clip.lengthBeats + delta).coerceIn(.25, maxBeat - clip.startBeat)
            else -> clip.startBeat = (clip.startBeat + delta).coerceIn(0.0, maxBeat - clip.lengthBeats)
        }
        ensureBars(project, clip.startBeat + clip.lengthBeats)
    }

    fun splitAudio(project: ZetaProject, id: String, atBeat: Double): Boolean {
        val index = project.audioClips.indexOfFirst { it.id == id }
        if (index < 0) return false
        val clip = project.audioClips[index]
        val split = snapQuarter(atBeat)
        val local = split - clip.startBeat
        if (local <= .25 || local >= clip.lengthBeats - .25) return false
        val frac = (local / clip.lengthBeats).coerceIn(.0, 1.0)
        val cutIndex = (clip.waveform.size * frac).toInt().coerceIn(0, clip.waveform.size)
        val leftWave = clip.waveform.take(cutIndex)
        val rightWave = clip.waveform.drop(cutIndex)
        val spb = 60.0 / project.bpm
        val left = clip.copy(lengthBeats = local, waveform = leftWave)
        val right = clip.copy(
            id = "clip_${System.nanoTime()}",
            startBeat = split,
            trimSeconds = clip.trimSeconds + local * spb,
            lengthBeats = clip.lengthBeats - local,
            waveform = rightWave,
            label = clip.label
        )
        project.audioClips[index] = left
        project.audioClips.add(index + 1, right)
        return true
    }

    fun duplicateAudio(project: ZetaProject, id: String) {
        val clip = project.audioClips.firstOrNull { it.id == id } ?: return
        val start = clip.startBeat + clip.lengthBeats
        val copy = clip.copy(id = "clip_${System.nanoTime()}", startBeat = start, label = clip.label)
        project.audioClips.add(copy)
        ensureBars(project, copy.startBeat + copy.lengthBeats)
    }

    fun deleteAudio(project: ZetaProject, id: String) {
        project.audioClips.removeAll { it.id == id }
    }

    fun addNote(project: ZetaProject, track: Int, pitch: Int, start: Double, length: Double) {
        if (track !in 4 until TRACK_COUNT) return
        addInstrument(project, track, project.laneNames[track])
        val maxBeat = max(project.bars * 4.0, start + length + 4.0)
        val note = MusicNote(track, pitch.coerceIn(0, 127), snapQuarter(start).coerceAtLeast(0.0), length.coerceIn(.125, 8.0), .82)
        project.notes.add(note)
        ensureBars(project, maxBeat)
    }

    fun updateNote(project: ZetaProject, old: MusicNote, updated: MusicNote) {
        val index = project.notes.indexOf(old)
        if (index >= 0) project.notes[index] = updated
        ensureBars(project, updated.start + updated.length)
    }

    fun deleteNote(project: ZetaProject, note: MusicNote) {
        project.notes.remove(note)
    }

    fun toggleStep(project: ZetaProject, row: Int, step: Int) {
        if (row !in 0..3 || step !in 0..63) return
        project.steps[row][step] = !project.steps[row][step]
        if (step + 1 > project.patternLength) project.patternLength = when {
            step < 16 -> 16
            step < 32 -> 32
            else -> 64
        }
    }

    fun setTrackGain(project: ZetaProject, track: Int, value: Double) {
        if (track in 0 until TRACK_COUNT) project.volumes[track] = value.coerceIn(.0, 1.0)
    }

    fun setBpmPreservingAudio(project: ZetaProject, newBpm: Int) {
        val target = newBpm.coerceIn(40, 260)
        if (target == project.bpm) return
        val oldSpb = 60.0 / project.bpm
        val newSpb = 60.0 / target
        project.audioClips.forEach { clip ->
            val startSeconds = clip.startBeat * oldSpb
            val lengthSeconds = clip.lengthBeats * oldSpb
            clip.startBeat = startSeconds / newSpb
            clip.lengthBeats = lengthSeconds / newSpb
        }
        project.bpm = target
        val end = project.audioClips.maxOfOrNull { it.startBeat + it.lengthBeats } ?: project.bars * 4.0
        ensureBars(project, end)
    }

    fun setMasterFx(project: ZetaProject, drive: Double, delay: Double) {
        project.drive = drive.coerceIn(.0, 1.0)
        project.delay = delay.coerceIn(.0, .75)
    }

    private fun ensureBars(project: ZetaProject, endBeat: Double) {
        val wanted = ceil(endBeat / 4.0).toInt().coerceIn(1, BAR_LIMIT)
        if (wanted > project.bars) project.bars = wanted
    }
}
