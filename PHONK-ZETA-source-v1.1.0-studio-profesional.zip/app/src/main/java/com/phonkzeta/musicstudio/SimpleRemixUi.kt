package com.phonkzeta.musicstudio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

private val UI_BG = Color(0xFF09090B)
private val UI_CARD = Color(0xFF171820)
private val UI_CARD_2 = Color(0xFF252631)
private val UI_PURPLE = Color(0xFFA78BFA)
private val UI_GOLD = Color(0xFFF5C451)
private val UI_GREEN = Color(0xFF2E8B62)
private val UI_RED = Color(0xFFFF4565)
private val UI_MUTED = Color(0xFFD6D8E2)

@Composable
fun RemixShell(
    title: String,
    tab: String,
    notice: String,
    exportProgress: Int,
    onSave: () -> Unit,
    onTab: (String) -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize().background(UI_BG).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PHONK", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text(" ZETA", color = UI_GOLD, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onSave) { Text("GUARDAR", color = UI_MUTED, fontWeight = FontWeight.Bold) }
        }
        if (title.isNotBlank()) {
            Text(title, color = UI_MUTED, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
        }
        Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), content = content)
        if (exportProgress >= 0) LinearProgressIndicator(progress = { exportProgress / 100f }, modifier = Modifier.fillMaxWidth())
        if (notice.isNotBlank()) Text(notice, color = UI_GOLD, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 3.dp))
        SimpleBottomNav(tab, onTab)
    }
}

@Composable
private fun SimpleBottomNav(tab: String, onTab: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp).background(UI_CARD, RoundedCornerShape(20.dp)).padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        listOf("INICIO" to "Inicio", "STEMS" to "Separar", "STUDIO" to "Estudio", "EXPORTAR" to "Exportar").forEach { (key, label) ->
            Button(onClick = { onTab(key) }, modifier = Modifier.weight(1f).height(44.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (tab == key) UI_PURPLE else UI_CARD_2),
                contentPadding = PaddingValues(horizontal = 3.dp)) {
                Text(label, color = if (tab == key) UI_BG else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RemixHomePage(
    project: ZetaProject,
    hasSong: Boolean,
    playing: Boolean,
    waveform: List<Float>,
    onImport: () -> Unit,
    onCreateBeat: () -> Unit,
    onOpenSong: () -> Unit,
    onProjects: () -> Unit,
    onPlay: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(4.dp))
        Text("CREA SIN COMPLICARTE", color = UI_GOLD, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text("Importa una canción y conviértela en tu remix.", color = UI_MUTED, fontSize = 15.sp)
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth().height(74.dp),
            colors = ButtonDefaults.buttonColors(containerColor = UI_PURPLE), shape = RoundedCornerShape(22.dp)) {
            Text("＋  IMPORTAR CANCIÓN", color = UI_BG, fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
        OutlinedButton(onClick = onCreateBeat, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp)) {
            Text("CREAR BEAT DESDE CERO", color = Color.White, fontWeight = FontWeight.Bold)
        }

        if (hasSong) {
            Column(Modifier.fillMaxWidth().background(UI_CARD, RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(project.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${project.bpm} BPM", color = UI_GOLD, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = UI_CARD_2)) {
                        Text(if (playing) "Ⅱ" else "▶", color = Color.White, fontSize = 18.sp)
                    }
                }
                MiniWaveform(waveform, Modifier.fillMaxWidth().height(70.dp))
                Button(onClick = onOpenSong, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = UI_GOLD)) {
                    Text("ABRIR CANCIÓN", color = UI_BG, fontWeight = FontWeight.Black)
                }
            }
        }
        OutlinedButton(onClick = onProjects, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text("MIS PROYECTOS", color = UI_MUTED, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StemPage(
    project: ZetaProject,
    playing: Boolean,
    playProgress: Float,
    processing: Boolean,
    processProgress: Int,
    onSeparate: () -> Unit,
    onPlay: () -> Unit,
    onSelect: (String) -> Unit,
    onToggle: (String) -> Unit,
    onGain: (String, Double) -> Unit,
    onRemix: () -> Unit
) {
    val original = project.audioClips.firstOrNull { it.label == "ORIGINAL" }
    val stems = project.audioClips.filter { it.label.startsWith("STEM_") }
    var selectedId by remember(project.audioClips.size) { mutableStateOf(stems.firstOrNull()?.id ?: original?.id.orEmpty()) }
    val selected = project.audioClips.firstOrNull { it.id == selectedId }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(4.dp))
        Text("SEPARAR AUDIO", color = UI_GOLD, fontSize = 19.sp, fontWeight = FontWeight.Black)
        Text("Bajo, batería, voz e instrumental · procesamiento local rápido.", color = UI_MUTED, fontSize = 14.sp)
        MiniWaveform(original?.waveform ?: emptyList(), Modifier.fillMaxWidth().height(82.dp))
        LinearProgressIndicator(progress = { playProgress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        Button(onClick = onPlay, enabled = original != null, modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = UI_CARD_2)) {
            Text(if (playing) "Ⅱ PAUSA" else "▶ ESCUCHAR", color = Color.White, fontWeight = FontWeight.Bold)
        }

        if (stems.isEmpty()) {
            Button(onClick = onSeparate, enabled = original != null && !processing, modifier = Modifier.fillMaxWidth().height(68.dp),
                colors = ButtonDefaults.buttonColors(containerColor = UI_PURPLE), shape = RoundedCornerShape(20.dp)) {
                Text(if (processing) "SEPARANDO… $processProgress%" else "SEPARAR EN 4 PARTES", color = UI_BG, fontSize = 18.sp, fontWeight = FontWeight.Black)
            }
            Text("La separación es aproximada: usa filtros locales optimizados, no un modelo pesado de IA.", color = UI_MUTED, fontSize = 12.sp)
        } else {
            Text("TOCA UNA PARTE PARA ESCUCHARLA", color = UI_MUTED, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            val order = listOf("STEM_BAJO", "STEM_BATERIA", "STEM_VOZ", "STEM_INSTRUMENTAL")
            order.forEach { key ->
                val clip = stems.firstOrNull { it.label == key } ?: return@forEach
                val label = when (key) {
                    "STEM_BAJO" -> "BAJO"
                    "STEM_BATERIA" -> "BATERÍA"
                    "STEM_VOZ" -> "VOZ"
                    else -> "INSTRUMENTAL"
                }
                val selectedNow = clip.id == selectedId
                Row(Modifier.fillMaxWidth().background(if (selectedNow) UI_PURPLE.copy(alpha = .18f) else UI_CARD, RoundedCornerShape(18.dp))
                    .border(1.dp, if (selectedNow) UI_PURPLE else UI_CARD_2, RoundedCornerShape(18.dp))
                    .clickable { selectedId = clip.id; onSelect(clip.id) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = if (selectedNow) UI_PURPLE else Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                    Switch(checked = !clip.muted, onCheckedChange = { onToggle(clip.id) })
                }
            }
            selected?.let { clip ->
                var localGain by remember(clip.id, clip.gain) { mutableFloatStateOf(clip.gain.toFloat().coerceIn(0f, 1f)) }
                Text("VOLUMEN", color = UI_MUTED, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Slider(value = localGain, onValueChange = { localGain = it },
                    onValueChangeFinished = { onGain(clip.id, localGain.toDouble()) })
            }
            Button(onClick = onRemix, modifier = Modifier.fillMaxWidth().height(58.dp), colors = ButtonDefaults.buttonColors(containerColor = UI_GOLD)) {
                Text("IR AL ESTUDIO", color = UI_BG, fontWeight = FontWeight.Black, fontSize = 17.sp)
            }
        }
    }
}

@Composable
fun RemixPage(
    project: ZetaProject,
    playing: Boolean,
    playProgress: Float,
    onPlay: () -> Unit,
    onStyle: (String) -> Unit,
    onToggleClip: (String) -> Unit,
    onGain: (String, Double) -> Unit,
    onImport: () -> Unit,
    onExport: () -> Unit
) {
    var style by remember { mutableStateOf("DARK") }
    var selectedClip by remember(project.audioClips.size) { mutableStateOf(project.audioClips.firstOrNull { !it.muted }?.id ?: "") }
    val chosen = project.audioClips.firstOrNull { it.id == selectedClip }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("REMIX", color = UI_GOLD, fontSize = 20.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = UI_PURPLE)) {
                Text(if (playing) "Ⅱ" else "▶ PLAY", color = UI_BG, fontWeight = FontWeight.Black)
            }
        }
        LinearProgressIndicator(progress = { playProgress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())

        Text("ESTILO", color = UI_MUTED, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("DRIFT", "DARK", "AGRESIVO").forEach { s ->
                Button(onClick = { style = s }, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = if (style == s) UI_PURPLE else UI_CARD_2), contentPadding = PaddingValues(5.dp)) {
                    Text(s, color = if (style == s) UI_BG else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("BRAZILIAN", "SLOWED").forEach { s ->
                Button(onClick = { style = s }, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = if (style == s) UI_PURPLE else UI_CARD_2)) {
                    Text(s, color = if (style == s) UI_BG else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Button(onClick = { onStyle(style) }, modifier = Modifier.weight(1.2f), colors = ButtonDefaults.buttonColors(containerColor = UI_GOLD)) {
                Text("APLICAR", color = UI_BG, fontWeight = FontWeight.Black)
            }
        }

        Text("PISTAS", color = UI_MUTED, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        if (project.audioClips.isEmpty()) {
            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth().height(58.dp)) { Text("＋ IMPORTAR AUDIO") }
        } else {
            project.audioClips.filter { it.label == "ORIGINAL" || it.label.startsWith("STEM_") }.forEach { clip ->
                val label = when (clip.label) {
                    "ORIGINAL" -> "ORIGINAL"
                    "STEM_BAJO" -> "BAJO"
                    "STEM_BATERIA" -> "BATERÍA"
                    "STEM_VOZ" -> "VOZ"
                    "STEM_INSTRUMENTAL" -> "INSTRUMENTAL"
                    else -> clip.label
                }
                Row(Modifier.fillMaxWidth().background(if (clip.id == selectedClip) UI_PURPLE.copy(alpha = .12f) else UI_CARD, RoundedCornerShape(16.dp))
                    .clickable { selectedClip = clip.id }.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(label, color = Color.White, fontWeight = FontWeight.Bold)
                        MiniWaveform(clip.waveform, Modifier.fillMaxWidth().height(30.dp))
                    }
                    Switch(checked = !clip.muted, onCheckedChange = { onToggleClip(clip.id) })
                }
            }
        }
        chosen?.let { clip ->
            var localGain by remember(clip.id, clip.gain) { mutableFloatStateOf(clip.gain.toFloat().coerceIn(0f, 1f)) }
            Text("VOLUMEN DE ${clip.label.removePrefix("STEM_")}", color = UI_MUTED, fontSize = 12.sp)
            Slider(value = localGain, onValueChange = { localGain = it },
                onValueChangeFinished = { onGain(clip.id, localGain.toDouble()) })
        }
        Button(onClick = onExport, modifier = Modifier.fillMaxWidth().height(58.dp), colors = ButtonDefaults.buttonColors(containerColor = UI_GREEN)) {
            Text("EXPORTAR", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
    }
}

@Composable
fun ExportPage(
    project: ZetaProject,
    busy: Boolean,
    onWav: () -> Unit,
    onM4a: () -> Unit,
    onSave: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(8.dp))
        Text("EXPORTAR", color = UI_GOLD, fontSize = 21.sp, fontWeight = FontWeight.Black)
        Column(Modifier.fillMaxWidth().background(UI_CARD, RoundedCornerShape(20.dp)).padding(16.dp)) {
            Text(project.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${project.bpm} BPM", color = UI_MUTED, fontSize = 14.sp)
        }
        Button(onClick = onWav, enabled = !busy, modifier = Modifier.fillMaxWidth().height(70.dp), colors = ButtonDefaults.buttonColors(containerColor = UI_PURPLE), shape = RoundedCornerShape(20.dp)) {
            Text("WAV · ALTA CALIDAD", color = UI_BG, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
        Button(onClick = onM4a, enabled = !busy, modifier = Modifier.fillMaxWidth().height(70.dp), colors = ButtonDefaults.buttonColors(containerColor = UI_GREEN), shape = RoundedCornerShape(20.dp)) {
            Text("M4A · MENOR TAMAÑO", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
        OutlinedButton(onClick = onSave, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text("GUARDAR PROYECTO", color = UI_MUTED, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MiniWaveform(values: List<Float>, modifier: Modifier = Modifier) {
    Canvas(modifier.background(Color(0xFF111219), RoundedCornerShape(12.dp))) {
        if (values.isEmpty()) {
            drawLine(UI_CARD_2, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 2f)
            return@Canvas
        }
        val center = size.height / 2f
        val step = size.width / max(1, values.size)
        values.forEachIndexed { i, amp ->
            val h = amp.coerceIn(0f, 1f) * size.height * .42f
            val x = i * step + step * .5f
            drawLine(UI_PURPLE, Offset(x, center - h), Offset(x, center + h), max(1f, step * .55f))
        }
    }
}
