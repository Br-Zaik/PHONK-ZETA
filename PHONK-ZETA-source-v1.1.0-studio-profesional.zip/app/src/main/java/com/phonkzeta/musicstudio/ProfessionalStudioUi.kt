package com.phonkzeta.musicstudio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

private val ST_BG = Color(0xFF09090B)
private val ST_PANEL = Color(0xFF171820)
private val ST_PANEL_2 = Color(0xFF22242D)
private val ST_GRID = Color(0xFF353846)
private val ST_PURPLE = Color(0xFFA78BFA)
private val ST_GOLD = Color(0xFFF5C451)
private val ST_RED = Color(0xFFFF4565)
private val ST_GREEN = Color(0xFF38A36E)
private val ST_BLUE = Color(0xFF28B8C9)
private val ST_TEXT = Color(0xFFF2F3F7)
private val ST_MUTED = Color(0xFFAEB2C0)
private const val ST_LABEL_DP = 88
private const val ST_ROW_DP = 58

private data class InstrumentChoice(val track: Int, val title: String, val subtitle: String)
private val instrumentChoices = listOf(
    InstrumentChoice(4, "PIANO", "Acordes y melodías"),
    InstrumentChoice(5, "808 BASS", "Bajo para phonk"),
    InstrumentChoice(6, "COWBELL", "Melodías phonk"),
    InstrumentChoice(7, "SYNTH", "Electrónica"),
    InstrumentChoice(8, "LEAD", "Melodía principal"),
    InstrumentChoice(15, "SAMPLER", "Tu propio sonido")
)

@Composable
fun ProfessionalStudioPage(
    project: ZetaProject,
    playSeconds: Double,
    playing: Boolean,
    recording: Boolean,
    onPlay: () -> Unit,
    onRecord: (Int) -> Unit,
    onSeekSeconds: (Double) -> Unit,
    onBpm: (Int) -> Unit,
    onApplyStyle: (String) -> Unit,
    onAddInstrument: (Int, String) -> Unit,
    onImportAudio: () -> Unit,
    onImportSampler: () -> Unit,
    onPreviewNote: (Int, Int, Boolean) -> Unit,
    onAddNote: (Int, Int, Double, Double) -> Unit,
    onUpdateNote: (MusicNote, MusicNote) -> Unit,
    onDeleteNote: (MusicNote) -> Unit,
    onToggleStep: (Int, Int) -> Unit,
    onAudioMoveResize: (String, Double, Int) -> Unit,
    onAudioSplit: (String, Double) -> Unit,
    onAudioDuplicate: (String) -> Unit,
    onAudioDelete: (String) -> Unit,
    onAudioLoop: (String) -> Unit,
    onAudioMute: (String) -> Unit,
    onAudioGain: (String, Double) -> Unit,
    onTrackGain: (Int, Double) -> Unit,
    onMasterFx: (Double, Double) -> Unit
) {
    var addMenu by remember { mutableStateOf(false) }
    var pianoTrack by remember { mutableIntStateOf(-1) }
    var drumEditor by remember { mutableStateOf(false) }
    var selectedAudio by remember { mutableStateOf<String?>(null) }
    var selectedMidi by remember { mutableIntStateOf(-1) }
    var fxOpen by remember { mutableStateOf(false) }
    var styleOpen by remember { mutableStateOf(false) }

    if (pianoTrack >= 0) {
        PianoRollPage(
            project = project,
            track = pianoTrack,
            playSeconds = playSeconds,
            playing = playing,
            recording = recording,
            onBack = { pianoTrack = -1 },
            onPlay = onPlay,
            onRecord = { onRecord(pianoTrack) },
            onPreviewNote = { pitch, down -> onPreviewNote(pianoTrack, pitch, down) },
            onAddNote = { pitch, start, length -> onAddNote(pianoTrack, pitch, start, length) },
            onUpdateNote = onUpdateNote,
            onDeleteNote = onDeleteNote,
            onTrackGain = { value -> onTrackGain(pianoTrack, value) }
        )
        return
    }

    if (drumEditor) {
        DrumSequencerPage(project = project, playing = playing, playSeconds = playSeconds,
            onBack = { drumEditor = false }, onPlay = onPlay, onToggleStep = onToggleStep)
        return
    }

    Column(Modifier.fillMaxSize().background(ST_BG), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        StudioTransport(
            project = project,
            playSeconds = playSeconds,
            playing = playing,
            recording = recording,
            onPlay = onPlay,
            onRecord = {
                val track = if (selectedMidi >= 4) selectedMidi else 6
                onRecord(track)
            },
            onBpm = onBpm,
            onStyle = { styleOpen = true }
        )

        TimelineArrangement(
            modifier = Modifier.weight(1f),
            project = project,
            playSeconds = playSeconds,
            selectedAudio = selectedAudio,
            selectedMidi = selectedMidi,
            onSeekSeconds = onSeekSeconds,
            onAudioSelect = { selectedAudio = it; selectedMidi = -1 },
            onMidiSelect = { selectedMidi = it; selectedAudio = null },
            onOpenPiano = { pianoTrack = it },
            onOpenDrums = { drumEditor = true },
            onAudioMoveResize = onAudioMoveResize
        )

        ContextToolbar(
            selectedAudio = selectedAudio,
            selectedMidi = selectedMidi,
            playBeat = playSeconds * project.bpm / 60.0,
            project = project,
            onSplit = { id, beat -> onAudioSplit(id, beat) },
            onDuplicate = onAudioDuplicate,
            onLoop = onAudioLoop,
            onMute = onAudioMute,
            onDelete = { id -> onAudioDelete(id); selectedAudio = null },
            onOpenPiano = { pianoTrack = it },
            onTrackGain = onTrackGain,
            onAudioGain = onAudioGain,
            onFx = { fxOpen = true }
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Button(onClick = { addMenu = true }, modifier = Modifier.weight(1f).height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ST_GOLD), shape = RoundedCornerShape(15.dp)) {
                Text("＋ PISTA", color = ST_BG, fontWeight = FontWeight.Black)
            }
            OutlinedButton(onClick = onImportAudio, modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(15.dp)) {
                Text("＋ AUDIO", color = ST_TEXT, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = { drumEditor = true }, modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(15.dp)) {
                Text("BATERÍA", color = ST_TEXT, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (addMenu) {
        AlertDialog(
            onDismissRequest = { addMenu = false },
            title = { Text("Añadir pista") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    instrumentChoices.forEach { choice ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable {
                                if (choice.track == 15 && project.samplerName.isBlank()) onImportSampler()
                                else onAddInstrument(choice.track, choice.title)
                                addMenu = false
                            },
                            color = ST_PANEL_2,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(choice.title, color = ST_TEXT, fontWeight = FontWeight.Black)
                                    Text(choice.subtitle, color = ST_MUTED, fontSize = 12.sp)
                                }
                                Text("＋", color = ST_PURPLE, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { drumEditor = true; addMenu = false },
                        color = ST_PANEL_2, shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("BATERÍA", color = ST_TEXT, fontWeight = FontWeight.Black)
                                Text("Kick, snare, hats y clap", color = ST_MUTED, fontSize = 12.sp)
                            }
                            Text("＋", color = ST_PURPLE, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { addMenu = false }) { Text("CERRAR") } }
        )
    }

    if (fxOpen) {
        var drive by remember(project.drive) { mutableFloatStateOf(project.drive.toFloat()) }
        var delay by remember(project.delay) { mutableFloatStateOf(project.delay.toFloat()) }
        AlertDialog(
            onDismissRequest = { fxOpen = false },
            title = { Text("FX MASTER") },
            text = {
                Column {
                    Text("Drive ${(drive * 100).toInt()}%")
                    Slider(value = drive, onValueChange = { drive = it })
                    Text("Delay ${(delay * 100).toInt()}%")
                    Slider(value = delay, onValueChange = { delay = it }, valueRange = 0f..0.75f)
                }
            },
            confirmButton = {
                TextButton(onClick = { onMasterFx(drive.toDouble(), delay.toDouble()); fxOpen = false }) { Text("APLICAR") }
            },
            dismissButton = { TextButton(onClick = { fxOpen = false }) { Text("CANCELAR") } }
        )
    }

    if (styleOpen) {
        AlertDialog(
            onDismissRequest = { styleOpen = false },
            title = { Text("PHONK automático") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("DRIFT", "DARK", "AGRESIVO", "BRAZILIAN", "SLOWED").forEach { style ->
                        Button(onClick = { onApplyStyle(style); styleOpen = false }, modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = ST_PANEL_2)) {
                            Text(style, color = ST_TEXT, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { styleOpen = false }) { Text("CERRAR") } }
        )
    }
}

@Composable
private fun StudioTransport(
    project: ZetaProject,
    playSeconds: Double,
    playing: Boolean,
    recording: Boolean,
    onPlay: () -> Unit,
    onRecord: () -> Unit,
    onBpm: (Int) -> Unit,
    onStyle: () -> Unit
) {
    val duration = project.bars * 240.0 / project.bpm
    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(onClick = onPlay, modifier = Modifier.height(48.dp), colors = ButtonDefaults.buttonColors(containerColor = ST_PURPLE)) {
            Text(if (playing) "Ⅱ" else "▶", color = ST_BG, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
        Button(onClick = onRecord, modifier = Modifier.height(48.dp), colors = ButtonDefaults.buttonColors(containerColor = if (recording) ST_RED else Color(0xFF8F2945))) {
            Text(if (recording) "■" else "●", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
        Text("${clock(playSeconds)} / ${clock(duration)}", color = ST_TEXT, fontSize = 13.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = { onBpm(-1) }) { Text("−", color = ST_TEXT, fontSize = 20.sp) }
        Text("${project.bpm}", color = ST_GOLD, fontWeight = FontWeight.Black)
        TextButton(onClick = { onBpm(1) }) { Text("＋", color = ST_TEXT, fontSize = 18.sp) }
        OutlinedButton(onClick = onStyle, contentPadding = PaddingValues(horizontal = 9.dp)) {
            Text("PHONK", color = ST_GOLD, fontSize = 11.sp, fontWeight = FontWeight.Black)
        }
    }
}

private fun clock(seconds: Double): String {
    val s = seconds.coerceAtLeast(0.0).toInt()
    return "%02d:%02d".format(s / 60, s % 60)
}

@Composable
private fun TimelineArrangement(
    modifier: Modifier = Modifier,
    project: ZetaProject,
    playSeconds: Double,
    selectedAudio: String?,
    selectedMidi: Int,
    onSeekSeconds: (Double) -> Unit,
    onAudioSelect: (String) -> Unit,
    onMidiSelect: (Int) -> Unit,
    onOpenPiano: (Int) -> Unit,
    onOpenDrums: () -> Unit,
    onAudioMoveResize: (String, Double, Int) -> Unit
) {
    var zoom by remember { mutableFloatStateOf(34f) }
    val hScroll = rememberScrollState()
    val spb = 60.0 / project.bpm
    val durationBeats = max(project.bars * 4.0, project.audioClips.maxOfOrNull { it.startBeat + it.lengthBeats } ?: 0.0)
    val widthDp = max(520f, (durationBeats * zoom).toFloat()).dp
    val activeMidi = (4 until TRACK_COUNT).filter { t -> project.laneAdded[t] || project.notes.any { it.track == t } }
    val hasDrums = project.steps.any { row -> row.any { it } }
    val audioRows = project.audioClips.toList()
    val totalRows = audioRows.size + activeMidi.size + if (hasDrums) 1 else 0

    Column(modifier.fillMaxWidth().background(ST_PANEL, RoundedCornerShape(16.dp))) {
        Row(Modifier.fillMaxWidth().height(42.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(ST_LABEL_DP.dp).fillMaxHeight(), contentAlignment = Alignment.Center) {
                Text("PISTAS", color = ST_MUTED, fontSize = 11.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { zoom = (zoom / 1.25f).coerceAtLeast(16f) }) { Text("−", color = ST_TEXT, fontSize = 20.sp) }
            Text("ZOOM", color = ST_MUTED, fontSize = 10.sp)
            TextButton(onClick = { zoom = (zoom * 1.25f).coerceAtMost(78f) }) { Text("＋", color = ST_TEXT, fontSize = 18.sp) }
        }

        Row(Modifier.fillMaxWidth().height(34.dp)) {
            Spacer(Modifier.width(ST_LABEL_DP.dp))
            TimelineRuler(
                modifier = Modifier.weight(1f).fillMaxHeight(),
                project = project,
                playSeconds = playSeconds,
                zoom = zoom,
                scrollPx = hScroll.value,
                onSeekSeconds = onSeekSeconds
            )
        }

        if (totalRows == 0) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("Añade una pista o importa audio", color = ST_MUTED)
            }
            return@Column
        }

        Row(Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
            Column(Modifier.width(ST_LABEL_DP.dp)) {
                audioRows.forEach { clip ->
                    LaneLabel(
                        text = audioLabel(clip.label),
                        color = if (clip.label.contains("BAJO")) ST_GOLD else ST_BLUE,
                        selected = selectedAudio == clip.id,
                        onClick = { onAudioSelect(clip.id) }
                    )
                }
                if (hasDrums) {
                    LaneLabel("BATERÍA", ST_GOLD, selectedMidi == 0) { onMidiSelect(0); onOpenDrums() }
                }
                activeMidi.forEach { track ->
                    LaneLabel(project.laneNames[track].take(12), ST_PURPLE, selectedMidi == track) { onMidiSelect(track) }
                }
            }

            Box(Modifier.weight(1f).horizontalScroll(hScroll)) {
                Column(Modifier.width(widthDp)) {
                    audioRows.forEach { clip ->
                        AudioLaneBody(
                            clip = clip,
                            zoom = zoom,
                            widthDp = widthDp,
                            spb = spb,
                            playSeconds = playSeconds,
                            selected = selectedAudio == clip.id,
                            onSelect = { onAudioSelect(clip.id) },
                            onMoveResize = { delta, mode -> onAudioMoveResize(clip.id, delta, mode) }
                        )
                    }
                    if (hasDrums) {
                        DrumLaneBody(project, zoom, widthDp, playSeconds, selectedMidi == 0) {
                            onMidiSelect(0); onOpenDrums()
                        }
                    }
                    activeMidi.forEach { track ->
                        MidiLaneBody(project, track, zoom, widthDp, playSeconds, selectedMidi == track) {
                            onMidiSelect(track); onOpenPiano(track)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimelineRuler(
    modifier: Modifier,
    project: ZetaProject,
    playSeconds: Double,
    zoom: Float,
    scrollPx: Int,
    onSeekSeconds: (Double) -> Unit
) {
    val density = LocalDensity.current
    val spb = 60.0 / project.bpm
    Canvas(modifier.background(ST_PANEL_2).pointerInput(project.bpm, zoom, scrollPx) {
        detectTapGestures { p ->
            val beatPx = with(density) { zoom.dp.toPx() }
            val beat = (p.x + scrollPx) / beatPx
            onSeekSeconds((beat * spb).coerceAtLeast(0.0))
        }
    }) {
        val beatPx = zoom.dp.toPx()
        val firstBeat = max(0, floor(scrollPx / beatPx).toInt() - 1)
        val lastBeat = firstBeat + ceil(size.width / beatPx).toInt() + 3
        for (beat in firstBeat..lastBeat) {
            if (beat % 4 == 0) {
                val x = beat * beatPx - scrollPx
                drawLine(ST_GRID, Offset(x, size.height * .45f), Offset(x, size.height), 1.5f)
                drawContext.canvas.nativeCanvas.drawText(clock(beat * spb), x + 3f, size.height * .58f,
                    android.graphics.Paint().apply {
                        isAntiAlias = true
                        color = android.graphics.Color.LTGRAY
                        textSize = 10f * density.density
                    })
            }
        }
        val playX = (playSeconds / spb * beatPx).toFloat() - scrollPx
        if (playX in 0f..size.width) drawLine(Color.White, Offset(playX, 0f), Offset(playX, size.height), 2f)
    }
}

@Composable
private fun LaneLabel(text: String, color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(ST_ROW_DP.dp)
        .background(if (selected) color.copy(alpha = .16f) else ST_PANEL_2)
        .clickable(onClick = onClick).padding(horizontal = 8.dp), contentAlignment = Alignment.CenterStart) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun AudioLaneBody(
    clip: ZetaAudioClip,
    zoom: Float,
    widthDp: Dp,
    spb: Double,
    playSeconds: Double,
    selected: Boolean,
    onSelect: () -> Unit,
    onMoveResize: (Double, Int) -> Unit
) {
    Box(Modifier.width(widthDp).height(ST_ROW_DP.dp).background(ST_BG)) {
        BeatGrid(widthDp, zoom)
        val start = (clip.startBeat * zoom).toFloat().dp
        val width = max(22f, (clip.lengthBeats * zoom).toFloat()).dp
        val density = LocalDensity.current
        var mode by remember { mutableIntStateOf(0) }
        var dx by remember { mutableFloatStateOf(0f) }
        Box(
            Modifier.offset(x = start, y = 7.dp).width(width).height((ST_ROW_DP - 14).dp)
                .background(if (clip.muted) ST_GRID else ST_PURPLE.copy(alpha = .78f), RoundedCornerShape(8.dp))
                .border(if (selected) 2.dp else 1.dp, if (selected) Color.White else ST_PURPLE, RoundedCornerShape(8.dp))
                .pointerInput(clip.id, clip.startBeat, clip.lengthBeats, zoom) {
                    detectDragGestures(
                        onDragStart = { p ->
                            val edge = with(density) { 14.dp.toPx() }
                            mode = when {
                                p.x <= edge -> -1
                                p.x >= size.width - edge -> 1
                                else -> 0
                            }
                            dx = 0f
                            onSelect()
                        },
                        onDragEnd = {
                            val beats = dx / with(density) { zoom.dp.toPx() }
                            if (beats != 0f) onMoveResize((round(beats * 4f) / 4f).toDouble(), mode)
                            dx = 0f
                        },
                        onDrag = { change, drag -> change.consume(); dx += drag.x }
                    )
                }.clickable { onSelect() }
        ) {
            MiniClipWaveform(clip.waveform, Modifier.fillMaxSize().padding(horizontal = 9.dp, vertical = 7.dp))
            Box(Modifier.align(Alignment.CenterStart).width(8.dp).fillMaxHeight().background(Color.White.copy(alpha = .32f), RoundedCornerShape(8.dp)))
            Box(Modifier.align(Alignment.CenterEnd).width(8.dp).fillMaxHeight().background(Color.White.copy(alpha = .32f), RoundedCornerShape(8.dp)))
        }
        val playX = (playSeconds / spb * zoom).toFloat().dp
        Box(Modifier.offset(x = playX).width(1.dp).fillMaxHeight().background(Color.White))
    }
}

@Composable
private fun MidiLaneBody(
    project: ZetaProject,
    track: Int,
    zoom: Float,
    widthDp: Dp,
    playSeconds: Double,
    selected: Boolean,
    onOpen: () -> Unit
) {
    val spb = 60.0 / project.bpm
    val notes = project.notes.filter { it.track == track }
    Canvas(Modifier.width(widthDp).height(ST_ROW_DP.dp).background(if (selected) ST_PURPLE.copy(alpha = .08f) else ST_BG).clickable(onClick = onOpen)) {
        val beatPx = zoom.dp.toPx()
        val count = (size.width / beatPx).toInt() + 1
        for (beat in 0..count) drawLine(if (beat % 4 == 0) ST_GRID else ST_GRID.copy(alpha = .4f), Offset(beat * beatPx, 0f), Offset(beat * beatPx, size.height), 1f)
        val minPitch = notes.minOfOrNull { it.pitch } ?: 60
        val maxPitch = notes.maxOfOrNull { it.pitch }?.coerceAtLeast(minPitch + 1) ?: 72
        notes.take(500).forEach { note ->
            val x = (note.start * beatPx).toFloat()
            val w = max(5f, (note.length * beatPx).toFloat())
            val frac = 1f - (note.pitch - minPitch).toFloat() / (maxPitch - minPitch).toFloat()
            val y = 6f + frac * (size.height - 18f)
            drawRoundRect(ST_PURPLE, Offset(x, y), Size(w, 8f), androidx.compose.ui.geometry.CornerRadius(4f, 4f))
        }
        val playX = (playSeconds / spb * beatPx).toFloat()
        drawLine(Color.White, Offset(playX, 0f), Offset(playX, size.height), 2f)
    }
}

@Composable
private fun DrumLaneBody(
    project: ZetaProject,
    zoom: Float,
    widthDp: Dp,
    playSeconds: Double,
    selected: Boolean,
    onOpen: () -> Unit
) {
    val spb = 60.0 / project.bpm
    Canvas(Modifier.width(widthDp).height(ST_ROW_DP.dp).background(if (selected) ST_GOLD.copy(alpha = .08f) else ST_BG).clickable(onClick = onOpen)) {
        val beatPx = zoom.dp.toPx()
        for (beat in 0..(size.width / beatPx).toInt() + 1) drawLine(ST_GRID.copy(alpha = if (beat % 4 == 0) .9f else .35f), Offset(beat * beatPx, 0f), Offset(beat * beatPx, size.height), 1f)
        val stepPx = beatPx / 4f
        val pattern = project.patternLength.coerceIn(16, 64)
        for (bar in 0 until project.bars) {
            val baseStep = bar * 16
            for (s in 0 until 16) {
                val sourceStep = (baseStep + s) % pattern
                val hits = (0..3).count { r -> project.steps[r][sourceStep] }
                if (hits > 0) {
                    val x = (bar * 16 + s) * stepPx
                    val h = 7f + hits * 6f
                    drawRoundRect(ST_GOLD, Offset(x + 1f, size.height - h - 5f), Size(max(2f, stepPx - 2f), h), androidx.compose.ui.geometry.CornerRadius(3f, 3f))
                }
            }
        }
        val playX = (playSeconds / spb * beatPx).toFloat()
        drawLine(Color.White, Offset(playX, 0f), Offset(playX, size.height), 2f)
    }
}

private fun audioLabel(label: String): String = when (label) {
    "STEM_BAJO" -> "BAJO"
    "STEM_BATERIA" -> "BATERÍA"
    "STEM_VOZ" -> "VOZ"
    "STEM_INSTRUMENTAL" -> "INSTRUMENTAL"
    "ORIGINAL" -> "ORIGINAL"
    else -> label.take(12)
}

@Composable
private fun BeatGrid(widthDp: Dp, zoom: Float) {
    Canvas(Modifier.width(widthDp).fillMaxHeight()) {
        val beatPx = zoom.dp.toPx()
        val count = (size.width / beatPx).toInt() + 1
        for (beat in 0..count) {
            val x = beat * beatPx
            drawLine(if (beat % 4 == 0) ST_GRID else ST_GRID.copy(alpha = .45f), Offset(x, 0f), Offset(x, size.height), if (beat % 4 == 0) 1.5f else 1f)
        }
    }
}

@Composable
private fun MiniClipWaveform(values: List<Float>, modifier: Modifier) {
    Canvas(modifier) {
        if (values.isEmpty()) return@Canvas
        val step = size.width / max(1, values.size)
        values.forEachIndexed { i, v ->
            val h = v.coerceIn(0f, 1f) * size.height * .42f
            val x = i * step + step * .5f
            drawLine(Color.White.copy(alpha = .9f), Offset(x, size.height / 2f - h), Offset(x, size.height / 2f + h), max(1f, step * .5f))
        }
    }
}


@Composable
private fun ContextToolbar(
    selectedAudio: String?,
    selectedMidi: Int,
    playBeat: Double,
    project: ZetaProject,
    onSplit: (String, Double) -> Unit,
    onDuplicate: (String) -> Unit,
    onLoop: (String) -> Unit,
    onMute: (String) -> Unit,
    onDelete: (String) -> Unit,
    onOpenPiano: (Int) -> Unit,
    onTrackGain: (Int, Double) -> Unit,
    onAudioGain: (String, Double) -> Unit,
    onFx: () -> Unit
) {
    val scroll = rememberScrollState()
    Row(Modifier.fillMaxWidth().height(52.dp).horizontalScroll(scroll), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        if (selectedAudio != null) {
            ToolChip("DIVIDIR") { onSplit(selectedAudio, playBeat) }
            ToolChip("DUPLICAR") { onDuplicate(selectedAudio) }
            ToolChip("LOOP") { onLoop(selectedAudio) }
            ToolChip("MUTE") { onMute(selectedAudio) }
            ToolChip("− VOL") {
                val c = project.audioClips.firstOrNull { it.id == selectedAudio }
                if (c != null) onAudioGain(selectedAudio, (c.gain - .1).coerceAtLeast(0.0))
            }
            ToolChip("＋ VOL") {
                val c = project.audioClips.firstOrNull { it.id == selectedAudio }
                if (c != null) onAudioGain(selectedAudio, (c.gain + .1).coerceAtMost(1.0))
            }
            ToolChip("FX") { onFx() }
            ToolChip("BORRAR", danger = true) { onDelete(selectedAudio) }
        } else if (selectedMidi >= 4) {
            ToolChip("NOTAS") { onOpenPiano(selectedMidi) }
            ToolChip("− VOL") { onTrackGain(selectedMidi, (project.volumes[selectedMidi] - .1).coerceAtLeast(0.0)) }
            ToolChip("＋ VOL") { onTrackGain(selectedMidi, (project.volumes[selectedMidi] + .1).coerceAtMost(1.0)) }
            ToolChip("FX") { onFx() }
        } else {
            Text("Selecciona una pista para editar", color = ST_MUTED, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ToolChip(text: String, danger: Boolean = false, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.height(42.dp), contentPadding = PaddingValues(horizontal = 12.dp), shape = RoundedCornerShape(14.dp)) {
        Text(text, color = if (danger) ST_RED else ST_TEXT, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PianoRollPage(
    project: ZetaProject,
    track: Int,
    playSeconds: Double,
    playing: Boolean,
    recording: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onRecord: () -> Unit,
    onPreviewNote: (Int, Boolean) -> Unit,
    onAddNote: (Int, Double, Double) -> Unit,
    onUpdateNote: (MusicNote, MusicNote) -> Unit,
    onDeleteNote: (MusicNote) -> Unit,
    onTrackGain: (Double) -> Unit
) {
    val beatWidth = 44.dp
    val pitchHeight = 24.dp
    val beats = max(16.0, project.bars * 4.0)
    val minPitch = 48
    val maxPitch = 72
    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    var selected by remember(track, project.notes.size) { mutableStateOf<MusicNote?>(null) }

    Column(Modifier.fillMaxSize().background(ST_BG), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹", color = ST_TEXT, fontSize = 30.sp) }
            Column(Modifier.weight(1f)) {
                Text(project.laneNames[track], color = ST_TEXT, fontWeight = FontWeight.Black, fontSize = 17.sp)
                Text("PIANO ROLL", color = ST_PURPLE, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = ST_PURPLE)) {
                Text(if (playing) "Ⅱ" else "▶", color = ST_BG, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(5.dp))
            Button(onClick = onRecord, colors = ButtonDefaults.buttonColors(containerColor = if (recording) ST_RED else Color(0xFF8F2945))) {
                Text(if (recording) "■" else "●", color = Color.White, fontWeight = FontWeight.Black)
            }
        }

        MiniKeyboard(track = track, onPreview = onPreviewNote)

        val totalWidth = beatWidth * beats.toFloat()
        val totalHeight = pitchHeight * (maxPitch - minPitch + 1).toFloat()
        Row(Modifier.fillMaxWidth().weight(1f).verticalScroll(vScroll)) {
            Column(Modifier.width(46.dp)) {
                for (pitch in maxPitch downTo minPitch) {
                    Box(Modifier.fillMaxWidth().height(pitchHeight).background(if (pitch % 12 in listOf(1,3,6,8,10)) ST_PANEL_2 else Color(0xFFEAEAF0)), contentAlignment = Alignment.Center) {
                        if (pitch % 12 == 0) Text("C${pitch / 12 - 1}", color = if (pitch % 12 in listOf(1,3,6,8,10)) Color.White else Color.Black, fontSize = 9.sp)
                    }
                }
            }
            Box(Modifier.weight(1f).height(totalHeight).horizontalScroll(hScroll)) {
                PianoGrid(
                    modifier = Modifier.width(totalWidth).height(totalHeight),
                    project = project,
                    track = track,
                    minPitch = minPitch,
                    maxPitch = maxPitch,
                    beatWidth = beatWidth,
                    pitchHeight = pitchHeight,
                    selected = selected,
                    playSeconds = playSeconds,
                    onSelect = { selected = it },
                    onAdd = { pitch, beat -> onAddNote(pitch, beat, .5) },
                    onMoveResize = { old, beatDelta, pitchDelta, resize ->
                        val updated = if (resize) old.copy(length = (old.length + beatDelta).coerceIn(.125, beats - old.start))
                        else old.copy(start = (old.start + beatDelta).coerceIn(0.0, beats - old.length), pitch = (old.pitch + pitchDelta).coerceIn(0, 127))
                        onUpdateNote(old, updated)
                        selected = updated
                    }
                )
            }
        }

        Row(Modifier.fillMaxWidth().height(50.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            selected?.let { note ->
                ToolChip("DUPLICAR") { onAddNote(note.pitch, (note.start + note.length).coerceAtMost(beats - .25), note.length) }
                ToolChip("BORRAR", danger = true) { onDeleteNote(note); selected = null }
            }
            ToolChip("− VOL") { onTrackGain((project.volumes[track] - .1).coerceAtLeast(0.0)) }
            ToolChip("＋ VOL") { onTrackGain((project.volumes[track] + .1).coerceAtMost(1.0)) }
        }
    }
}

@Composable
private fun MiniKeyboard(track: Int, onPreview: (Int, Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(68.dp).background(ST_PANEL, RoundedCornerShape(14.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        listOf(60 to "DO", 62 to "RE", 64 to "MI", 65 to "FA", 67 to "SOL", 69 to "LA", 71 to "SI").forEach { (pitch, label) ->
            var down by remember { mutableStateOf(false) }
            Box(Modifier.weight(1f).fillMaxHeight().background(if (down) ST_PURPLE else Color(0xFFECECF2), RoundedCornerShape(10.dp))
                .pointerInput(track, pitch) {
                    detectTapGestures(
                        onPress = {
                            down = true; onPreview(pitch, true)
                            tryAwaitRelease()
                            down = false; onPreview(pitch, false)
                        }
                    )
                }, contentAlignment = Alignment.Center) {
                Text(label, color = ST_BG, fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PianoGrid(
    modifier: Modifier,
    project: ZetaProject,
    track: Int,
    minPitch: Int,
    maxPitch: Int,
    beatWidth: Dp,
    pitchHeight: Dp,
    selected: MusicNote?,
    playSeconds: Double,
    onSelect: (MusicNote?) -> Unit,
    onAdd: (Int, Double) -> Unit,
    onMoveResize: (MusicNote, Double, Int, Boolean) -> Unit
) {
    val density = LocalDensity.current
    val notes = project.notes.filter { it.track == track && it.pitch in minPitch..maxPitch }
    var dragNote by remember { mutableStateOf<MusicNote?>(null) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var resize by remember { mutableStateOf(false) }

    fun hit(pos: Offset): Pair<MusicNote?, Boolean> {
        val bw = with(density) { beatWidth.toPx() }
        val ph = with(density) { pitchHeight.toPx() }
        for (note in notes.asReversed()) {
            val x = (note.start * bw).toFloat()
            val y = (maxPitch - note.pitch) * ph
            val w = max(8f, (note.length * bw).toFloat())
            if (pos.x in x..(x + w) && pos.y in y..(y + ph)) return note to (pos.x > x + w - 12f)
        }
        return null to false
    }

    Box(modifier.background(ST_PANEL)) {
        Canvas(Modifier.fillMaxSize()) {
            val bw = beatWidth.toPx()
            val ph = pitchHeight.toPx()
            val beats = size.width / bw
            for (beat in 0..beats.toInt()) drawLine(if (beat % 4 == 0) ST_GRID else ST_GRID.copy(alpha = .4f), Offset(beat * bw, 0f), Offset(beat * bw, size.height), if (beat % 4 == 0) 1.5f else 1f)
            for (row in 0..(maxPitch - minPitch + 1)) drawLine(ST_GRID.copy(alpha = .55f), Offset(0f, row * ph), Offset(size.width, row * ph), 1f)
            notes.forEach { note ->
                val x = (note.start * bw).toFloat()
                val y = (maxPitch - note.pitch) * ph
                val w = max(8f, (note.length * bw).toFloat())
                val isSel = selected == note
                drawRoundRect(if (isSel) ST_GOLD else ST_PURPLE, Offset(x + 1f, y + 3f), Size(w - 2f, ph - 6f), androidx.compose.ui.geometry.CornerRadius(5f, 5f))
                if (isSel) drawRect(Color.White.copy(alpha = .8f), Offset(x + w - 6f, y + 4f), Size(4f, ph - 8f))
            }
            val playBeat = playSeconds * project.bpm / 60.0
            drawLine(Color.White, Offset((playBeat * bw).toFloat(), 0f), Offset((playBeat * bw).toFloat(), size.height), 2f)
        }

        Box(Modifier.fillMaxSize()
            .pointerInput(track, notes, beatWidth, pitchHeight) {
                detectTapGestures { p ->
                    val found = hit(p).first
                    if (found != null) onSelect(found)
                    else {
                        val bw = with(density) { beatWidth.toPx() }
                        val ph = with(density) { pitchHeight.toPx() }
                        val beat = floor((p.x / bw) * 4f) / 4f
                        val pitch = (maxPitch - floor(p.y / ph).toInt()).coerceIn(minPitch, maxPitch)
                        onAdd(pitch, beat.toDouble())
                        onSelect(null)
                    }
                }
            }
            .pointerInput(track, notes, beatWidth, pitchHeight) {
                detectDragGestures(
                    onDragStart = { p ->
                        val h = hit(p); dragNote = h.first; resize = h.second; dragX = 0f; dragY = 0f
                        if (h.first != null) onSelect(h.first)
                    },
                    onDragEnd = {
                        dragNote?.let { old ->
                            val bw = with(density) { beatWidth.toPx() }
                            val ph = with(density) { pitchHeight.toPx() }
                            val beatDelta = (round((dragX / bw) * 4f) / 4f).toDouble()
                            val pitchDelta = -round(dragY / ph).toInt()
                            if (beatDelta != 0.0 || pitchDelta != 0) onMoveResize(old, beatDelta, pitchDelta, resize)
                        }
                        dragNote = null; dragX = 0f; dragY = 0f
                    },
                    onDrag = { change, amount -> change.consume(); dragX += amount.x; dragY += amount.y }
                )
            })
    }
}

@Composable
private fun DrumSequencerPage(
    project: ZetaProject,
    playing: Boolean,
    playSeconds: Double,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onToggleStep: (Int, Int) -> Unit
) {
    var length by remember(project.patternLength) { mutableIntStateOf(project.patternLength.coerceIn(16, 64)) }
    val labels = listOf("KICK", "SNARE", "HAT", "CLAP")
    Column(Modifier.fillMaxSize().background(ST_BG), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹", color = ST_TEXT, fontSize = 30.sp) }
            Text("BATERÍA", color = ST_TEXT, fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.weight(1f))
            Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = ST_PURPLE)) {
                Text(if (playing) "Ⅱ" else "▶", color = ST_BG, fontWeight = FontWeight.Black)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(16, 32, 64).forEach { n ->
                OutlinedButton(onClick = { length = n }, colors = ButtonDefaults.outlinedButtonColors(containerColor = if (length == n) ST_PURPLE.copy(alpha = .2f) else Color.Transparent)) {
                    Text("$n", color = if (length == n) ST_PURPLE else ST_TEXT)
                }
            }
        }
        val pageScroll = rememberScrollState()
        Column(Modifier.fillMaxWidth().horizontalScroll(pageScroll), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            labels.forEachIndexed { row, label ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(70.dp), contentAlignment = Alignment.CenterStart) { Text(label, color = ST_GOLD, fontSize = 11.sp, fontWeight = FontWeight.Black) }
                    for (step in 0 until length) {
                        val on = project.steps[row][step]
                        Box(Modifier.padding(2.dp).size(34.dp)
                            .background(if (on) ST_GOLD else ST_PANEL_2, RoundedCornerShape(7.dp))
                            .border(1.dp, if (step % 4 == 0) ST_PURPLE else ST_GRID, RoundedCornerShape(7.dp))
                            .clickable { onToggleStep(row, step) })
                    }
                }
            }
        }
        Text("Toca cuadros para crear el patrón. Se repite en el Estudio.", color = ST_MUTED, fontSize = 12.sp)
    }
}
