# PHONK ZETA v1.1.0 — Estudio profesional

- Conserva importación y separación local por stems.
- Nueva pestaña Estudio como timeline multipista.
- Audio: mover, redimensionar por bordes, dividir en cursor, duplicar, loop, mute, volumen y borrar.
- Pistas instrumentales: Piano, 808 Bass, Cowbell, Synth, Lead y Sampler.
- Piano Roll: crear notas por toque, mover notas, cambiar tono y estirar desde el borde derecho.
- Grabación de notas con el motor existente y teclado táctil.
- Batería: secuenciador 16/32/64 pasos para Kick, Snare, Hat y Clap.
- Importación de audios adicionales sin reemplazar el proyecto.
- Sampler persistente desde audio importado (hasta 30 s).
- Presets PHONK accesibles desde el Estudio.
- FX master Drive/Delay y volumen por pista.
- Timeline renderiza solo una superficie horizontal compartida para reducir lag y mantener pistas alineadas.
- Inicio desde cero ahora abre un proyecto vacío a 130 BPM, no un beat automático.
