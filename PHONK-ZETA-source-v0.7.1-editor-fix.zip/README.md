# PHONK ZETA v0.7.0 — Editor visual de pistas

Nueva pantalla EDITOR con forma de onda y mini piano arriba, clips de audio/MIDI en línea de tiempo por segundos abajo, cursor blanco, edición contextual, ciclo visible y acceso a piano horizontal. Ver `IMPLEMENTATION_V070.md` para detalles y límites.

# PHONK ZETA v0.6.0 — editor musical en el celular

**Versión fuente 0.6.0** (versionCode 8). Lee [IMPLEMENTATION_V060.md](IMPLEMENTATION_V060.md) para ver el alcance real y las limitaciones; abajo está el historial previo, no describe el estado actual.

**Nuevo editor en la pestaña EDITOR (también Modo Fácil):** tiempo real mm:ss, regla, compases, cursor, zoom y páginas para canciones largas; bloques de notas/ritmos por compás que puedes desplazar, duplicar y borrar; hasta 8 clips de audio con mover, recortar inicio y final, cortar, duplicar, repetir, silenciar, solo y ganancia. La forma de onda es aproximada. El audio importado se reproduce y renderiza en WAV/M4A en el lugar indicado por su bloque.

**Dos modos para el teclado:** piano horizontal enorme con botón opcional VER NOTAS + TECLAS, o piano vertical con las notas editables arriba. **Ciclo por segundos**, por ejemplo 50 s, en PLAY; no recorta la exportación. Canción ampliable hasta 512 compases. El generador de bases agrega pequeñas variaciones y transiciones por compás.

## Instalación desde el celular

1. Sube el archivo `PHONK-ZETA-source-v0.6.0-editor-musical.zip` a la raíz del repositorio `Br-Zaik/PHONK-ZETA` desde GitHub móvil.
2. El workflow de la raíz del repo debe priorizar `source-v0.6.0` si mantienes ZIPs viejos. El mismo YAML está dentro del nuevo ZIP, en `.github/workflows/android.yml`.
3. GitHub Actions → run `android` → Artifact `PHONK-ZETA-APK-debug` cuando termine en verde. Si falla, usa `PHONK-ZETA-diagnostico` para revisar todos los errores reunidos.

No se ha compilado la app Android en el contenedor de entrega: las pruebas de Compose, Play, grabación, edición y compatibilidad real con el teléfono deben confirmarse desde Actions y dispositivo. El proyecto sigue siendo un prototipo en evolución, no un DAW comercial terminado. Los archivos de proyecto JSON exportados no empaquetan el audio importado: mantén copia de tus WAV/MP3 de origen y usa WAV/M4A para compartir el resultado final.

---

# Archivo histórico de cambios — v0.3.0

Consulta `IMPLEMENTATION_V030.md` para cambios reales, instrucciones y límites conocidos.

# Corrección de compilación v0.2.3
Esta versión corrige DOS errores del compilador Kotlin en MainActivity.kt: scope anidado dentro de awaitEachGesture en pads y piano. Se identificaron en run 35521763708 de GitHub Actions. Sustituye el ZIP anterior por este y deja que GitHub Actions compile. **No se ha probado el APK en un teléfono.**

# PHONK ZETA — Estudio musical Android

**Versión de código fuente: 0.2.0 · compilación Android: PENDIENTE DE VERIFICAR EN GITHUB ACTIONS**

Aplicación offline nativa Kotlin + Jetpack Compose para producir música desde el teléfono. Este ZIP contiene **código fuente real, 24 WAV creados por síntesis para esta entrega, pruebas unitarias y workflow para construir el APK**. No incluye APK ya compilado, ni pretende ser un DAW comercial completo.

## Funciones implementadas en el código

- Piano multitáctil de dos octavas visibles, cambio de octava, velocity manual, modos acorde mayor/menor/séptima y bloqueo a escala mayor/menor seleccionando tónica.
- 12 instrumentos/timbres de síntesis: piano sintético, 808, cowbell, synth, lead, campanas, pad, sub bass, órgano, pluck, cuerdas sintéticas, sampler; además 4 baterías sintetizadas. Los nombres de instrumentos sintetizados no significan recreaciones acústicas de estudio.
- Drum pads 4 × 4, secuenciador de 16, 32 o 64 pasos (paginas de 16) con velocity por paso y swing; generador básico y editable de kick/snare/hats/cowbell/808.
- Grabación de eventos de nota MIDI-like con duración/posición/velocity, cuando se toca el piano, pads o un controlador MIDI conectado; reproducción y exportación usan el mismo planificador basado en frames.
- Piano Roll por compases: crear, seleccionar, desplazar por cuantía fija, cambiar pitch, duración, velocity, duplicar, borrar, cuantizar a 1/16 y cambiar octava.
- Arreglo por compases de hasta 128 compases, activar/desactivar pista por compás, 16 canales con volumen, pan, mute y solo.
- Efectos master originales: saturación/drive, delay estéreo, protección de salida por tanh. Click de metrónomo opcional (no se exporta).
- Biblioteca integrada de 24 sonidos WAV originales creados por síntesis, organizados en kick/snare/hat/cowbell/808/FX. Se cargan en el sampler. Importación de muestras personales WAV PCM16 mono/estéreo, 8–192 kHz, hasta 24 MB y 120 segundos. El sampler dispone de modos ONE-SHOT y SUSTAIN.
- Grabación mono PCM16 por micrófono en WAV, posteriormente importable como muestra del instrumento SAMPLER. No es todavía una pista de audio editable en timeline.
- Entrada MIDI básica USB/Bluetooth cuando Android expone el controlador (un dispositivo/puerto seleccionado); nota ON/OFF y velocity. Disponibilidad y latencia dependen del teléfono/controlador.
- Proyectos JSON v2 en almacenamiento privado con escritura atómica y autosave, importación y exportación de metadata `.phonkproj` (JSON). Guarda ritmos de forma independiente para reutilizarlos; deshacer/rehacer para varias ediciones.
- Exportación real de toda la canción a WAV estéreo 48 kHz PCM16, con arrreglo musical, instrumentos, mezcla y efectos. Exportación por Storage Access Framework a la ubicación seleccionada.
- Workflow GitHub Actions que ejecuta tests, lint y build con `--continue`; publica APK si compila y archivo de diagnóstico para recopilar errores **en una misma ejecución**.

## Uso desde Android / GitHub Actions

**Opción A — repositorio con fuentes extraídas:** abre el ZIP con tu gestor de archivos y sube **su contenido interno** a la raíz del repositorio (`app/`, `settings.gradle.kts`, `.github/workflows/android.yml`). En GitHub, usa Actions → PHONK ZETA - Android APK + diagnostico → Run workflow, o haz un commit en `main`.

**Opción B — subir solo el ZIP con cualquier nombre:** primero crea manualmente el archivo `.github/workflows/android.yml` en el repositorio, pegando el contenido del workflow incluido en este paquete (también se entrega como archivo suelto). Después, sube el ZIP a la raíz; el workflow encontrará el ZIP, localizará `settings.gradle.kts` dentro y compilará sin importar el nombre del ZIP. GitHub **no puede descubrir workflows que sigan dentro de un ZIP sin extraer**, por eso el YAML inicial tiene que estar fuera.

Abre Actions → ejecución → Artifacts:
- `PHONK-ZETA-v0.2.0-APK` (solo si todas las etapas del workflow terminaron bien).
- `PHONK-ZETA-diagnostico-completo` (intenta conservar logs, resultados de test y reportes incluso si falla).

APK Debug: firmado con la clave temporal del runner de Actions, no es un release firmado para Play Store. Si necesitas actualizar con una firma estable, configura un keystore de release propio mediante Secrets; no se incluye ni expone ninguna clave.

## Límites importantes de v0.2

Esta es una ampliación importante del prototipo anterior, **NO la implementación completa de todas las funciones pedidas en el prompt maestro**. No se debe publicitar como DAW profesional ya terminado. Aún faltan, entre otras cosas: motor Oboe/C++ real-time-safe; timeline con clips libremente movibles; pistas de audio y edición no destructiva; sampler multizona/pad kits independientes por pad; efectos EQ/reverb/sidechain/compressor por canal y automatización; soundfont/mezcla acústica de alta calidad; MIDI externo con reconexión/hotplug/pitch bend/CC completos; WAV 24 bit/FLAC/MP3/AAC/stems; empaquetado portable con muestras incluidas; audioprofiling en hardware real y tests instrumentados Android.

El archivo `.phonkproj` **no empaqueta los WAV importados**: si mueves el proyecto a otro teléfono tendrás que transferir/importar las muestras por separado. El motor actual usa AudioTrack desde Kotlin y sincronización por bloque: mejora el scheduling respecto a v0.1, pero todavía no da garantías de latencia profesional en todos los dispositivos. La velocidad de exportación variará mucho con la potencia del teléfono. Bluetooth puede agregar retraso perceptible.

## Comprobaciones efectuadas durante la generación

- Se compiló la lógica Kotlin del **backend** (MusicCore + RecordingAndMidi) usando el compilador local con **stubs de Android/JSON**; eso comprueba tipos/sintaxis de esos archivos, **no equivale a compilar la aplicación Android**.
- Se decodificaron y validaron los 24 WAV originales, comprobando que son PCM legible y con amplitudes finitas.
- Se validaron los XML y la estructura del workflow.
- No hay Android SDK/Gradle con acceso a dependencias en este entorno. El primer APK y la compilación Compose deben verificarse en GitHub Actions, y las pruebas de latencia/audio deben hacerse en un teléfono real.

## Derechos de uso

Los 24 sonidos incorporados se generaron matemáticamente para esta app, sin recortar canciones comerciales ni emplear muestras de terceros. El usuario es responsable de contar con los permisos correspondientes para muestras externas que importe a sus proyectos. El código de la app es original; las dependencias de compilación y de Android conservan sus propias licencias.


## v0.2.2 — corrección Gradle Material 3

Se corrige `androidx.compose.material:material3` por `androidx.compose.material3:material3`.
El workflow también aplica esta corrección al ZIP v0.2.1 ya subido, sin necesidad de volver a subir el código.
No se ha podido validar la compilación Android en este entorno; GitHub Actions confirmará si aparecen más errores.


## v0.6.1: test de persistencia corregido
La prueba de pistas múltiples ya comprueba `schema=5` (incluye el editor por clips); ver `IMPLEMENTATION_V061.md`.


## Corrección v0.7.1
Se resolvió el error Kotlin en VisualStudioEditor.kt:340: `this.color` en android.graphics.Paint para evitar la sombra del `val color: androidx.compose.ui.graphics.Color` del Canvas. Verificación de compilación Android pendiente de GitHub Actions.
