package com.phonkzeta.musicstudio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor

private val PERFORMANCE_BG = Color(0xFF080A0F)
private val PERFORMANCE_PURPLE = Color(0xFF996AFF)
private val PERFORMANCE_GOLD = Color(0xFFFFD36A)
private val PIANO_STEPS = intArrayOf(0, 2, 4, 5, 7, 9, 11)
private val MINOR_STEPS = intArrayOf(0, 2, 3, 5, 7, 8, 10, 12)
private val PAD_TRACKS = intArrayOf(0, 1, 2, 3, 6, 5, 2, 3, 0, 1, 2, 6, 5, 0, 1, 3)
private val PAD_LABELS = listOf("KICK", "SNARE", "HAT", "CLAP", "COWBELL", "808", "HAT 2", "CLAP 2",
    "KICK 2", "SNARE 2", "HAT 3", "BELL", "BASS", "KICK 3", "SNARE 3", "CLAP 3")

@Composable
fun ZetaPerformance(
    engine: ZetaAudioEngine,
    mode: String,
    track: Int,
    playing: Boolean,
    recording: Boolean,
    onExit: () -> Unit,
    onPlay: () -> Unit,
    onRecord: () -> Unit,
    onStop: () -> Unit,
    onInstrument: (Int) -> Unit
) {
    var octave by remember { mutableIntStateOf(4) }
    var whiteCount by remember { mutableIntStateOf(7) }
    var sustain by remember { mutableStateOf(false) }
    var velocity by remember { mutableFloatStateOf(.87f) }
    Column(Modifier.fillMaxSize().background(PERFORMANCE_BG).padding(horizontal = 6.dp, vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth().height(53.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            PerfButton("← VOLVER", onExit, Color(0xFF343641))
            Text(mode, color = PERFORMANCE_GOLD, fontSize = 17.sp,
                fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            PerfButton(if (playing) "Ⅱ PAUSA" else "▶ PLAY", onPlay, Color(0xFF28684C))
            PerfButton(if (recording) "■ FIN REC" else "● REC", onRecord,
                if (recording) Color(0xFFB72E47) else Color(0xFF4B2638))
            PerfButton("■ STOP", onStop, Color(0xFF343641))
        }
        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (mode != "PADS") {
                PerfButton("OCT −", { octave = (octave - 1).coerceAtLeast(1) }, Color(0xFF303542))
                Text("$octave", color = PERFORMANCE_GOLD, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                PerfButton("OCT +", { octave = (octave + 1).coerceAtMost(7) }, Color(0xFF303542))
                if (mode == "PIANO") {
                    PerfButton("${whiteCount} TECLAS", { whiteCount = when (whiteCount) {
                        7 -> 10; 10 -> 14; else -> 7
                    } }, Color(0xFF303542))
                }
                PerfButton(if (sustain) "SUSTAIN ✓" else "SUSTAIN", {
                    sustain = !sustain
                    if (!sustain) engine.allNotesOff()
                },
                    if (sustain) PERFORMANCE_PURPLE else Color(0xFF303542))
                Spacer(Modifier.weight(1f))
                Text("FUERZA", color = Color.White, fontSize = 12.sp)
                Slider(value = velocity, onValueChange = { velocity = it }, valueRange = .2f..1f,
                    modifier = Modifier.width(92.dp))
            } else {
                Text("16 PADS · toca varios a la vez · REC guarda los golpes",
                    color = Color.White, fontSize = 15.sp)
            }
        }
        val instrument = if (mode == "PADS") -1 else track
        if (mode == "PADS") {
            PerfPads(engine, Modifier.fillMaxWidth().weight(1f))
        } else if (mode == "SMART KEYS") {
            PerfSmartKeys(engine, instrument, octave, velocity, sustain,
                Modifier.fillMaxWidth().weight(1f))
        } else {
            PerfPiano(engine, instrument, octave, whiteCount, velocity, sustain,
                Modifier.fillMaxWidth().weight(1f))
        }
        if (mode != "PADS") {
            Row(Modifier.fillMaxWidth().height(49.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf(4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15).forEach { index ->
                    if (index in listOf(4, 5, 6, 7, 9, 15)) {
                        PerfButton(TRACK_NAMES[index], { engine.allNotesOff(); onInstrument(index) },
                            if (track == index) PERFORMANCE_PURPLE else Color(0xFF2D303B))
                    }
                }
            }
        }
    }
}

@Composable
private fun PerfButton(label: String, onClick: () -> Unit, color: Color) {
    Button(onClick = onClick, shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        modifier = Modifier.height(45.dp)) {
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            maxLines = 1)
    }
}

@Composable
private fun PerfPiano(engine: ZetaAudioEngine, track: Int, octave: Int, whites: Int,
                      velocity: Float, sustain: Boolean, modifier: Modifier) {
    val pressed = remember { mutableStateMapOf<Long, Int>() }
    fun pitchFor(x: Float, y: Float, w: Float, h: Float): Int {
        val key = (x / (w / whites)).toInt().coerceIn(0, whites - 1)
        val base = PIANO_STEPS[key % 7] + (key / 7) * 12
        val ratio = x / (w / whites) - floor(x / (w / whites))
        if (y < h * .61f) {
            if (ratio > .69f && base % 12 in intArrayOf(0, 2, 5, 7, 9))
                return ((octave + 1) * 12 + base + 1).coerceIn(0, 127)
            if (ratio < .31f && key > 0) {
                val prev = PIANO_STEPS[(key - 1) % 7] + (key - 1) / 7 * 12
                if (prev % 12 in intArrayOf(0, 2, 5, 7, 9))
                    return ((octave + 1) * 12 + prev + 1).coerceIn(0, 127)
            }
        }
        return ((octave + 1) * 12 + base).coerceIn(0, 127)
    }
    DisposableEffect(track, octave, whites, sustain) {
        onDispose { pressed.values.forEach { engine.noteOff(track, it) }; pressed.clear() }
    }
    Canvas(modifier.background(Color(0xFF232631), RoundedCornerShape(12.dp))
        .pointerInput(track, octave, whites, velocity, sustain) {
            awaitEachGesture {
                do {
                    val event = awaitPointerEvent()
                    for (change in event.changes) {
                        val id = change.id.value
                        if (change.pressed) {
                            val note = pitchFor(change.position.x, change.position.y,
                                size.width.toFloat(), size.height.toFloat())
                            val old = pressed[id]
                            if (old != note) {
                                if (!sustain) old?.let { engine.noteOff(track, it) }
                                engine.noteOn(track, note, velocity.toDouble())
                                pressed[id] = note
                            }
                        } else {
                            pressed.remove(id)?.let { if (!sustain) engine.noteOff(track, it) }
                        }
                    }
                } while (event.changes.any { it.pressed })
                if (!sustain) pressed.values.forEach { engine.noteOff(track, it) }
                pressed.clear()
            }
        }) {
        val kw = size.width / whites
        for (key in 0 until whites) {
            val pitch = (octave + 1) * 12 + PIANO_STEPS[key % 7] + key / 7 * 12
            drawRect(if (pitch in pressed.values) PERFORMANCE_GOLD else Color(0xFFF4F5FB),
                Offset(key * kw + 1.5f, 1f), Size(kw - 3f, size.height - 2f))
            drawRect(Color(0xFF5B6071), Offset(key * kw, 0f), Size(1.5f, size.height))
        }
        for (key in 0 until whites - 1) {
            val n = PIANO_STEPS[key % 7]
            if (n in intArrayOf(0, 2, 5, 7, 9)) {
                val pitch = (octave + 1) * 12 + n + key / 7 * 12 + 1
                val bw = kw * .59f
                drawRect(if (pitch in pressed.values) PERFORMANCE_PURPLE else Color(0xFF15171D),
                    Offset((key + 1) * kw - bw / 2, 0f), Size(bw, size.height * .61f))
            }
        }
    }
}

@Composable
private fun PerfSmartKeys(engine: ZetaAudioEngine, track: Int, octave: Int, velocity: Float,
                          sustain: Boolean, modifier: Modifier) {
    val held = remember { mutableStateMapOf<Long, Int>() }
    DisposableEffect(track, octave, sustain) {
        onDispose { held.values.forEach { engine.noteOff(track, it) }; held.clear() }
    }
    Canvas(modifier.pointerInput(track, octave, sustain, velocity) {
        awaitEachGesture {
            do {
                val event = awaitPointerEvent()
                for (change in event.changes) {
                    val id = change.id.value
                    if (change.pressed) {
                        val col = (change.position.x / (size.width / 4)).toInt().coerceIn(0, 3)
                        val row = (change.position.y / (size.height / 2)).toInt().coerceIn(0, 1)
                        val pitch = ((octave + 1) * 12 + MINOR_STEPS[row * 4 + col]).coerceIn(0, 127)
                        if (held[id] != pitch) {
                            if (!sustain) held[id]?.let { engine.noteOff(track, it) }
                            engine.noteOn(track, pitch, velocity.toDouble()); held[id] = pitch
                        }
                    } else held.remove(id)?.let { if (!sustain) engine.noteOff(track, it) }
                }
            } while (event.changes.any { it.pressed })
            if (!sustain) held.values.forEach { engine.noteOff(track, it) }
            held.clear()
        }
    }) {
        for (row in 0..1) for (col in 0..3) {
            val note = (octave + 1) * 12 + MINOR_STEPS[row * 4 + col]
            val color = if (note in held.values) PERFORMANCE_GOLD else
                if ((row + col) % 2 == 0) Color(0xFF5535A0) else Color(0xFF6942B8)
            val x = col * size.width / 4
            val y = row * size.height / 2
            drawRoundRect(color, Offset(x + 4f, y + 4f),
                Size(size.width / 4 - 8f, size.height / 2 - 8f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(18f))
            drawIntoText("${row * 4 + col + 1}", x + size.width / 8,
                y + size.height / 4, 44f)
        }
    }
}

@Composable
private fun PerfPads(engine: ZetaAudioEngine, modifier: Modifier) {
    val held = remember { mutableStateMapOf<Long, Int>() }
    DisposableEffect(Unit) {
        onDispose { held.values.forEach { engine.noteOff(PAD_TRACKS[it], 60) }; held.clear() }
    }
    Canvas(modifier.pointerInput(Unit) {
        awaitEachGesture {
            do {
                val event = awaitPointerEvent()
                for (change in event.changes) {
                    val id = change.id.value
                    if (change.pressed) {
                        val col = (change.position.x / (size.width / 4)).toInt().coerceIn(0, 3)
                        val row = (change.position.y / (size.height / 4)).toInt().coerceIn(0, 3)
                        val index = row * 4 + col
                        if (held[id] != index) {
                            held[id]?.let { engine.noteOff(PAD_TRACKS[it], if (PAD_TRACKS[it] < 4) intArrayOf(36,38,42,39)[PAD_TRACKS[it]] else 60) }
                            engine.noteOn(PAD_TRACKS[index], if (PAD_TRACKS[index] < 4) intArrayOf(36,38,42,39)[PAD_TRACKS[index]] else 60)
                            held[id] = index
                        }
                    } else held.remove(id)?.let { engine.noteOff(PAD_TRACKS[it], if (PAD_TRACKS[it] < 4) intArrayOf(36,38,42,39)[PAD_TRACKS[it]] else 60) }
                }
            } while (event.changes.any { it.pressed })
            held.values.forEach { engine.noteOff(PAD_TRACKS[it],
                if (PAD_TRACKS[it] < 4) intArrayOf(36,38,42,39)[PAD_TRACKS[it]] else 60) }
            held.clear()
        }
    }) {
        val palette = listOf(Color(0xFFB62B55), Color(0xFFD05333), Color(0xFF6942B8), Color(0xFFB28522))
        for (i in 0 until 16) {
            val x = (i % 4) * size.width / 4
            val y = (i / 4) * size.height / 4
            drawRoundRect(if (i in held.values) PERFORMANCE_GOLD else palette[i % 4],
                Offset(x + 4f, y + 4f), Size(size.width / 4 - 8f, size.height / 4 - 8f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(17f))
            drawIntoText(PAD_LABELS[i], x + size.width / 8,
                y + size.height / 8, 27f)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawIntoText(label: String, x: Float, y: Float, fontSize: Float) {
    drawContext.canvas.nativeCanvas.drawText(label, x, y + fontSize / 3,
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = fontSize
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        })
}
