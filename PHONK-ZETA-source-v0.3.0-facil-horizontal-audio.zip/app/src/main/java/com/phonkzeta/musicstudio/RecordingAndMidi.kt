package com.phonkzeta.musicstudio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max

/** Records external microphone into its own WAV file. Not falsely represented as a timeline audio-track recorder. */
class MicRecorder(private val context: Context) {
    private val running = AtomicBoolean(false)
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var output: File? = null
    private var error: String = ""
    fun start() {
        check(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            "Falta permiso de micrófono"
        }
        if (!running.compareAndSet(false, true)) return
        try {
            val rate = 48000
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            require(min > 0) { "El dispositivo no admite grabación PCM" }
            val record = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(min * 2, 8192))
            require(record.state == AudioRecord.STATE_INITIALIZED) { "No se inicializó micrófono" }
            recorder = record
            val dir = File(context.filesDir, "recordings").apply { mkdirs() }
            val file = File(dir, "MIC_${System.currentTimeMillis()}.wav")
            output = file
            error = ""
            record.startRecording()
            worker = thread(name = "PHONK-Mic-Writer", isDaemon = true) {
                try {
                    RandomAccessFile(file, "rw").use { f ->
                        f.setLength(0)
                        f.write(ByteArray(44))
                        val b = ByteArray(4096)
                        var pcm = 0L
                        while (running.get() && pcm < 16L * 1024L * 1024L) {
                            val n = record.read(b, 0, b.size)
                            if (n > 0) { f.write(b, 0, n); pcm += n }
                            else if (n < 0) { error = "Error de lectura ($n)"; break }
                        }
                        fun le(v: Long, count: Int) { repeat(count) { i -> f.write(((v ushr (i * 8)) and 255).toInt()) } }
                        f.seek(0)
                        f.write("RIFF".toByteArray()); le(pcm + 36, 4)
                        f.write("WAVEfmt ".toByteArray()); le(16, 4); le(1, 2); le(1, 2)
                        le(rate.toLong(), 4); le(rate * 2L, 4); le(2, 2); le(16, 2)
                        f.write("data".toByteArray()); le(pcm, 4)
                    }
                } catch (e: Exception) { error = e.message ?: "Error de grabación" }
                finally { running.set(false); try { record.release() } catch (_: Exception) {} }
            }
        } catch (e: Exception) {
            running.set(false)
            try { recorder?.release() } catch (_: Exception) {}
            throw e
        }
    }
    fun stop(): File? {
        running.set(false)
        try { recorder?.stop() } catch (_: Exception) {}
        try { worker?.join(2000) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        recorder = null
        return output?.takeIf { !workerIsAlive() && it.isFile && it.length() > 44L && error.isEmpty() }
    }
    private fun workerIsAlive() = worker?.isAlive == true
}

/** Input from Android's MIDI API. Device is optional, touch keyboard always remains available. */
class MidiBridge(private val context: Context, private val engine: ZetaAudioEngine) {
    var onStatus: ((String) -> Unit)? = null
    private val manager: MidiManager? = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    private var device: MidiDevice? = null
    private var outputPort: MidiOutputPort? = null
    private var channel = 0
    private var instrument = 6
    private val receiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            var i = offset
            val end = offset + count
            while (i < end) {
                val status = msg[i].toInt() and 255
                val type = status and 0xF0
                if (status < 0x80 || type !in listOf(0x80, 0x90, 0xB0, 0xE0)) { i++; continue }
                val len = if (type == 0xB0 || type == 0xE0 || type == 0x80 || type == 0x90) 3 else 1
                if (i + len > end) break
                val note = msg[i + 1].toInt() and 127
                val v = msg[i + 2].toInt() and 127
                if (status and 15 == channel) {
                    when (type) {
                        0x90 -> if (v == 0) engine.noteOff(instrument, note)
                                 else engine.noteOn(instrument, note, v / 127.0)
                        0x80 -> engine.noteOff(instrument, note)
                        0xB0 -> if (note == 123 || note == 120) engine.allNotesOff()
                    }
                }
                i += len
            }
        }
    }
    fun selectInstrument(track: Int) { instrument = track.coerceIn(4, 15) }
    fun connect() {
        try {
            val midi = manager ?: run { onStatus?.invoke("MIDI no disponible"); return }
            val choices = midi.devices.filter { it.outputPortCount > 0 }
            if (choices.isEmpty()) { onStatus?.invoke("Conecta un teclado MIDI y vuelve a pulsar") ; return }
            close()
            val info: MidiDeviceInfo = choices.first()
            midi.openDevice(info, { opened ->
                if (opened == null) { onStatus?.invoke("No se pudo abrir MIDI") ; return@openDevice }
                device = opened
                try {
                    outputPort = opened.openOutputPort(0)
                    require(outputPort != null) { "Puerto MIDI no disponible" }
                    outputPort!!.connect(receiver)
                    val label = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "Teclado MIDI"
                    onStatus?.invoke("MIDI conectado: $label")
                } catch (e: Exception) { onStatus?.invoke("Error MIDI: ${e.message}"); close() }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { onStatus?.invoke("Error MIDI: ${e.message}") }
    }
    fun close() {
        try { outputPort?.disconnect(receiver) } catch (_: Exception) {}
        try { outputPort?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        outputPort = null; device = null
        engine.allNotesOff()
    }
}
