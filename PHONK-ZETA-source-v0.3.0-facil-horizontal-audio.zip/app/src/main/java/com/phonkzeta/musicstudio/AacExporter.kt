package com.phonkzeta.musicstudio

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File

/** Encodes the exact WAV mix using Android's built-in AAC-LC encoder into an M4A container. */
object AacExporter {
    fun wavToM4a(wav: File, target: File) {
        require(wav.length() >= 44 && wav.inputStream().use { input ->
            val header = ByteArray(12)
            input.read(header) == 12 && String(header, 0, 4) == "RIFF" && String(header, 8, 4) == "WAVE"
        }) { "No es WAV válido" }
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,
            ZetaAudioEngine.RATE, 2).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        var muxer: MediaMuxer? = null
        var codecStarted = false
        var muxerStarted = false
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start(); codecStarted = true
            muxer = MediaMuxer(target.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            wav.inputStream().use { input ->
                var skipped = 0L
                while (skipped < 44) {
                    val n = input.skip(44 - skipped)
                    require(n > 0) { "WAV incompleto" }
                    skipped += n
                }
                val info = MediaCodec.BufferInfo()
                var track = -1
                var endInput = false
                var endOutput = false
                var framesRead = 0L
                var iterations = 0
                while (!endOutput && iterations++ < 200000) {
                    if (!endInput) {
                        val index = codec.dequeueInputBuffer(10000)
                        if (index >= 0) {
                            val buffer = codec.getInputBuffer(index) ?: error("Encoder sin entrada")
                            buffer.clear()
                            val request = minOf(buffer.remaining(), 8192) / 4 * 4
                            require(request > 0) { "Buffer de entrada insuficiente" }
                            val bytes = ByteArray(request)
                            val count = input.read(bytes)
                            val time = framesRead * 1_000_000L / ZetaAudioEngine.RATE
                            if (count < 0) {
                                codec.queueInputBuffer(index, 0, 0, time,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                endInput = true
                            } else if (count > 0) {
                                require(count % 4 == 0) { "PCM incompleto" }
                                buffer.put(bytes, 0, count)
                                codec.queueInputBuffer(index, 0, count, time, 0)
                                framesRead += count / 4
                            }
                        }
                    }
                    when (val index = codec.dequeueOutputBuffer(info, 10000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(!muxerStarted) { "Formato de encoder cambió dos veces" }
                            val writer = requireNotNull(muxer)
                            track = writer.addTrack(codec.outputFormat)
                            writer.start(); muxerStarted = true
                        }
                        MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                        else -> if (index >= 0) {
                            val encoded = codec.getOutputBuffer(index)
                            if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                                check(muxerStarted && track >= 0) { "M4A sin pista" }
                                val encodedBuffer = requireNotNull(encoded)
                                encodedBuffer.position(info.offset)
                                encodedBuffer.limit(info.offset + info.size)
                                requireNotNull(muxer).writeSampleData(track, encodedBuffer, info)
                            }
                            endOutput = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            codec.releaseOutputBuffer(index, false)
                        }
                    }
                }
                check(endOutput && muxerStarted) { "No se pudo terminar el archivo M4A" }
            }
        } catch (e: Exception) {
            target.delete()
            throw e
        } finally {
            try { if (codecStarted) codec.stop() } catch (_: Exception) {}
            codec.release()
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }
}
