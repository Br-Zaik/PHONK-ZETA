package com.phonkzeta.musicstudio

import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ceil
import kotlin.math.max

private val APP_BG = Color(0xFF09090B)
private val APP_PURPLE = Color(0xFFA78BFA)
private val APP_GOLD = Color(0xFFF5C451)

class MainActivity : ComponentActivity() {
    val engine = ZetaAudioEngine()
    lateinit var store: ProjectStorage
    var snapshotProvider: (() -> ZetaProject)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStorage(this)
        val project = try { store.load("autosave") } catch (_: Exception) { ZetaProject() }
        if (project.name == "autosave") project.name = "Mi remix"
        engine.setProject(project)
        try {
            val kit = mapOf(
                0 to "01_deep_kick.wav", 1 to "05_dark_snare.wav",
                2 to "09_tight_hat.wav", 3 to "06_snap_snare.wav",
                5 to "17_long_808_c.wav", 6 to "13_drift_cowbell.wav"
            ).mapValues { (_, file) ->
                WaveDecoder.decode(assets.open("soundkit/$file").use { it.readBytes() })
            }
            engine.setFactoryKit(kit)
        } catch (_: Exception) { }
        reloadAudioBank(project)
        runCatching { engine.start() }
        setContent { RemixApp(project, this) }
    }

    fun reloadAudioBank(project: ZetaProject) {
        engine.clearAudioSources()
        project.audioClips.forEach { clip ->
            store.loadBackground(clip.filename)?.let { engine.setAudioSource(it) }
        }
    }

    override fun onStop() {
        runCatching { snapshotProvider?.invoke()?.let { store.saveAutosave(it) } }
        super.onStop()
    }

    override fun onDestroy() {
        engine.close()
        super.onDestroy()
    }
}

@Composable
private fun RemixApp(initial: ZetaProject, activity: MainActivity) {
    val engine = activity.engine
    val store = activity.store
    val scope = rememberCoroutineScope()

    var project by remember { mutableStateOf(initial) }
    var revision by remember { mutableIntStateOf(0) }
    val observedProject = remember(revision) { project }
    var tab by remember { mutableStateOf("INICIO") }
    var playing by remember { mutableStateOf(false) }
    var transportTick by remember { mutableIntStateOf(0) }
    var notice by remember { mutableStateOf("Listo · sin Internet") }
    var exportProgress by remember { mutableIntStateOf(-1) }
    var processing by remember { mutableStateOf(false) }
    var processingProgress by remember { mutableIntStateOf(0) }
    var saveJob by remember { mutableStateOf<Job?>(null) }
    var showProjects by remember { mutableStateOf(false) }
    var projects by remember { mutableStateOf(store.list()) }

    DisposableEffect(project) {
        activity.snapshotProvider = { project.copyDeep() }
        onDispose { activity.snapshotProvider = null }
    }

    LaunchedEffect(playing) {
        while (playing) {
            delay(180)
            transportTick++
        }
    }
    val playSeconds = remember(transportTick, revision) { engine.playSeconds }
    val durationSeconds = remember(revision) {
        project.audioClips.maxOfOrNull { clip -> clip.lengthBeats * 60.0 / project.bpm } ?: (project.bars * 240.0 / project.bpm)
    }.coerceAtLeast(.1)
    val playProgress = (playSeconds / durationSeconds).toFloat().coerceIn(0f, 1f)
    val originalClip = observedProject.audioClips.firstOrNull { it.label == "ORIGINAL" }
    val hasSong = originalClip != null

    fun changed(message: String? = null) {
        revision++
        engine.refresh(project)
        if (message != null) notice = message
        saveJob?.cancel()
        val snap = project.copyDeep()
        saveJob = scope.launch {
            delay(650)
            runCatching { withContext(Dispatchers.IO) { store.saveAutosave(snap) } }
        }
    }

    fun saveNow() {
        val snap = project.copyDeep()
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    store.save(snap)
                    store.saveAutosave(snap)
                }
            }.onSuccess { notice = "Proyecto guardado" }
                .onFailure { notice = "No se pudo guardar" }
        }
    }

    fun togglePlay() {
        playing = engine.togglePlay()
        notice = if (playing) "Reproduciendo" else "Pausa"
    }

    fun selectOnlyClip(id: String) {
        project.audioClips.forEach { it.muted = it.id != id }
        changed()
        if (!playing) playing = engine.togglePlay()
    }

    fun toggleClip(id: String) {
        project.audioClips.firstOrNull { it.id == id }?.let { it.muted = !it.muted }
        changed()
    }

    fun setClipGain(id: String, value: Double) {
        project.audioClips.firstOrNull { it.id == id }?.gain = value.coerceIn(0.0, 1.0)
        revision++
        engine.refresh(project)
    }

    fun loadProject(name: String) {
        runCatching { store.load(name) }.onSuccess { loaded ->
            project = loaded
            revision++
            activity.reloadAudioBank(loaded)
            engine.setProject(loaded)
            playing = false
            tab = if (loaded.audioClips.isNotEmpty()) "REMIX" else "INICIO"
            notice = "Proyecto abierto"
            showProjects = false
        }.onFailure { notice = "No se pudo abrir" }
    }

    val importSong = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            processing = true
            processingProgress = 5
            notice = "Importando canción…"
            runCatching {
                val sound = withContext(Dispatchers.IO) { AudioImport.decode(activity, uri, maximumSeconds = 180) }
                processingProgress = 35
                val displayName = runCatching {
                    activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0) else "Mi remix"
                    } ?: "Mi remix"
                }.getOrDefault("Mi remix")
                val bpm = withContext(Dispatchers.Default) { RemixTools.estimateBpm(sound) }
                processingProgress = 60
                val stored = withContext(Dispatchers.IO) { store.importBackground(sound) }
                val waveform = withContext(Dispatchers.Default) { timelineWaveform(sound, 72) }
                val seconds = sound.pcm.size.toDouble() / sound.sampleRate
                val beats = seconds * bpm / 60.0

                engine.stop()
                playing = false
                project = ZetaProject(
                    name = displayName.substringBeforeLast('.').take(45).ifBlank { "Mi remix" },
                    bpm = bpm,
                    bars = ceil(beats / 4.0).toInt().coerceIn(2, BAR_LIMIT)
                )
                project.audioClips.add(
                    ZetaAudioClip(
                        id = "original_${System.nanoTime()}", filename = stored,
                        startBeat = 0.0, trimSeconds = 0.0, lengthBeats = beats,
                        gain = .82, label = "ORIGINAL", waveform = waveform
                    )
                )
                revision++
                engine.clearAudioSources()
                engine.setAudioSource(sound.copy(filename = stored))
                engine.setProject(project)
                withContext(Dispatchers.IO) { store.saveAutosave(project.copyDeep()) }
                processingProgress = 100
                notice = "Canción lista · $bpm BPM detectados"
                tab = "STEMS"
            }.onFailure { notice = "No se pudo importar: ${it.message ?: "error"}" }
            processing = false
            processingProgress = 0
        }
    }

    fun separateAudio() {
        if (processing) return
        val original = project.audioClips.firstOrNull { it.label == "ORIGINAL" } ?: run {
            notice = "Importa una canción primero"
            return
        }
        scope.launch {
            processing = true
            processingProgress = 2
            notice = "Separando audio…"
            runCatching {
                val source = withContext(Dispatchers.IO) { store.loadBackground(original.filename) }
                    ?: error("No se encontró el audio original")
                project.audioClips.removeAll { it.label.startsWith("STEM_") }
                val specs = listOf(
                    StemKind.BASS to "STEM_BAJO",
                    StemKind.DRUMS to "STEM_BATERIA",
                    StemKind.VOCALS to "STEM_VOZ",
                    StemKind.INSTRUMENTAL to "STEM_INSTRUMENTAL"
                )
                specs.forEachIndexed { index, (kind, label) ->
                    processingProgress = 8 + index * 22
                    val stem = withContext(Dispatchers.Default) { RemixTools.extractStem(source, kind) }
                    val filename = withContext(Dispatchers.IO) { store.importBackground(stem) }
                    val wave = withContext(Dispatchers.Default) { timelineWaveform(stem, 64) }
                    engine.setAudioSource(stem.copy(filename = filename))
                    project.audioClips.add(
                        ZetaAudioClip(
                            id = "${label.lowercase()}_${System.nanoTime()}", filename = filename,
                            startBeat = original.startBeat, trimSeconds = 0.0,
                            lengthBeats = original.lengthBeats, gain = .72,
                            label = label, waveform = wave, muted = true
                        )
                    )
                }
                original.muted = false
                revision++
                engine.refresh(project)
                withContext(Dispatchers.IO) { store.saveAutosave(project.copyDeep()) }
                processingProgress = 100
                notice = "4 partes listas"
            }.onFailure { notice = "No se pudo separar: ${it.message ?: "error"}" }
            processing = false
            processingProgress = 0
        }
    }

    fun applyStyle(style: String) {
        val oldBpm = project.bpm
        val oldSpb = 60.0 / oldBpm
        val timings = project.audioClips.associate { clip ->
            clip.id to Pair(clip.startBeat * oldSpb, clip.lengthBeats * oldSpb)
        }
        val duration = timings.values.maxOfOrNull { it.first + it.second } ?: 20.0
        val bpm = RemixTools.styleBpm(style)
        val bars = ceil(duration / (240.0 / bpm)).toInt().coerceIn(2, BAR_LIMIT)
        val oldName = project.name
        EasyPhonk.generate(project, style, bars)
        project.name = if (oldName.startsWith("PHONK ")) project.name else oldName
        val newSpb = 60.0 / project.bpm
        project.audioClips.forEach { clip ->
            val t = timings[clip.id] ?: return@forEach
            clip.startBeat = t.first / newSpb
            clip.lengthBeats = t.second / newSpb
        }
        project.bars = max(project.bars, ceil(duration / (4.0 * newSpb)).toInt()).coerceAtMost(BAR_LIMIT)
        changed("Estilo $style aplicado")
    }

    val exportWav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        if (uri != null) scope.launch {
            exportProgress = 0
            val temp = File(activity.cacheDir, "phonk_${System.currentTimeMillis()}.wav")
            runCatching {
                val snap = project.copyDeep()
                withContext(Dispatchers.IO) {
                    engine.exportWav(snap, temp, onProgress = { pct -> activity.runOnUiThread { exportProgress = pct } })
                    activity.contentResolver.openOutputStream(uri)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
                        ?: error("No se pudo guardar")
                }
            }.onSuccess { notice = "WAV exportado" }
                .onFailure { notice = "Error al exportar WAV" }
            temp.delete(); exportProgress = -1
        }
    }

    val exportM4a = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { uri ->
        if (uri != null) scope.launch {
            exportProgress = 0
            val wav = File(activity.cacheDir, "phonk_${System.currentTimeMillis()}.wav")
            val m4a = File(activity.cacheDir, "phonk_${System.currentTimeMillis()}.m4a")
            runCatching {
                val snap = project.copyDeep()
                withContext(Dispatchers.IO) {
                    engine.exportWav(snap, wav, onProgress = { pct -> activity.runOnUiThread { exportProgress = pct.coerceAtMost(92) } })
                    AacExporter.wavToM4a(wav, m4a)
                    activity.contentResolver.openOutputStream(uri)?.use { out -> m4a.inputStream().use { it.copyTo(out) } }
                        ?: error("No se pudo guardar")
                }
            }.onSuccess { notice = "M4A exportado" }
                .onFailure { notice = "Error al exportar M4A" }
            wav.delete(); m4a.delete(); exportProgress = -1
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = APP_PURPLE, secondary = APP_GOLD, background = APP_BG, surface = APP_BG,
            onPrimary = APP_BG, onSecondary = APP_BG, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        RemixShell(
            title = observedProject.name,
            tab = tab,
            notice = notice,
            exportProgress = exportProgress,
            onSave = { saveNow() },
            onTab = { target ->
                if (target == "STEMS" && !hasSong) {
                    notice = "Importa una canción primero"
                    tab = "INICIO"
                } else tab = target
            }
        ) {
            when (tab) {
                "INICIO" -> RemixHomePage(
                    project = observedProject,
                    hasSong = hasSong,
                    playing = playing,
                    waveform = originalClip?.waveform ?: emptyList(),
                    onImport = { importSong.launch(arrayOf("audio/*")) },
                    onCreateBeat = {
                        engine.stop(); playing = false
                        project = ZetaProject(name = "Beat nuevo")
                        EasyPhonk.generate(project, "DARK", 16)
                        revision++
                        engine.clearAudioSources(); engine.setProject(project)
                        notice = "Beat creado"
                        tab = "REMIX"
                    },
                    onOpenSong = { tab = "STEMS" },
                    onProjects = { projects = store.list(); showProjects = true },
                    onPlay = { togglePlay() }
                )
                "STEMS" -> StemPage(
                    project = observedProject,
                    playing = playing,
                    playProgress = playProgress,
                    processing = processing,
                    processProgress = processingProgress,
                    onSeparate = { separateAudio() },
                    onPlay = { togglePlay() },
                    onSelect = { id -> selectOnlyClip(id) },
                    onToggle = { id -> toggleClip(id) },
                    onGain = { id, gain -> setClipGain(id, gain) },
                    onRemix = { tab = "REMIX" }
                )
                "REMIX" -> RemixPage(
                    project = observedProject,
                    playing = playing,
                    playProgress = playProgress,
                    onPlay = { togglePlay() },
                    onStyle = { applyStyle(it) },
                    onToggleClip = { toggleClip(it) },
                    onGain = { id, gain -> setClipGain(id, gain) },
                    onImport = { importSong.launch(arrayOf("audio/*")) },
                    onExport = { tab = "EXPORTAR" }
                )
                "EXPORTAR" -> ExportPage(
                    project = observedProject,
                    busy = exportProgress >= 0,
                    onWav = { exportWav.launch("${project.name.take(40)}.wav") },
                    onM4a = { exportM4a.launch("${project.name.take(40)}.m4a") },
                    onSave = { saveNow() }
                )
            }
        }

        if (showProjects) {
            AlertDialog(
                onDismissRequest = { showProjects = false },
                title = { Text("Mis proyectos") },
                text = {
                    androidx.compose.foundation.layout.Column {
                        if (projects.isEmpty()) Text("Todavía no hay proyectos guardados.")
                        projects.take(12).forEach { name ->
                            TextButton(onClick = { loadProject(name) }) { Text(name) }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showProjects = false }) { Text("CERRAR") } }
            )
        }
    }
}
