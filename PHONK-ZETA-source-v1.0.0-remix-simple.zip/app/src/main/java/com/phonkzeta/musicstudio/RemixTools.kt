package com.phonkzeta.musicstudio

import kotlin.math.*

enum class StemKind { BASS, DRUMS, VOCALS, INSTRUMENTAL }

object RemixTools {
    private fun lowPassAlpha(cutoff: Double, sampleRate: Int): Double =
        exp(-2.0 * Math.PI * cutoff / sampleRate.toDouble()).coerceIn(0.0, .99999)

    fun extractStem(source: SampleSound, kind: StemKind): SampleSound {
        val input = source.pcm
        val rate = source.sampleRate
        // Stems are stored at half rate when possible: much less RAM/storage on low-end phones,
        // while keeping enough bandwidth for remix work.
        val stride = if (rate >= 32000) 2 else 1
        val outRate = rate / stride
        val out = FloatArray((input.size + stride - 1) / stride)
        val aBass = lowPassAlpha(190.0, rate)
        val aLowMid = lowPassAlpha(220.0, rate)
        val aVocalHi = lowPassAlpha(4200.0, rate)
        val aDrum = lowPassAlpha(1200.0, rate)
        var lpBass = 0.0
        var lpLowMid = 0.0
        var lpVocalHi = 0.0
        var lpDrum = 0.0
        var envelope = 0.0
        var peak = 0f

        var outIndex = 0
        for (i in input.indices) {
            val x = input[i].toDouble()
            lpBass = aBass * lpBass + (1.0 - aBass) * x
            lpLowMid = aLowMid * lpLowMid + (1.0 - aLowMid) * x
            lpVocalHi = aVocalHi * lpVocalHi + (1.0 - aVocalHi) * x
            lpDrum = aDrum * lpDrum + (1.0 - aDrum) * x

            val mid = lpVocalHi - lpLowMid
            val high = x - lpDrum
            envelope = envelope * .985 + abs(high) * .015
            val transient = (abs(high) - envelope * .82).coerceAtLeast(0.0)

            if (i % stride == 0 && outIndex < out.size) {
                val y = when (kind) {
                    StemKind.BASS -> lpBass * 1.55
                    StemKind.DRUMS -> high * (.28 + transient * 5.0)
                    StemKind.VOCALS -> mid * 1.28
                    StemKind.INSTRUMENTAL -> x - mid * .58
                }.coerceIn(-1.0, 1.0).toFloat()
                out[outIndex++] = y
                peak = max(peak, abs(y))
            }
        }

        val target = when (kind) {
            StemKind.BASS -> .90f
            StemKind.DRUMS -> .88f
            StemKind.VOCALS -> .90f
            StemKind.INSTRUMENTAL -> .94f
        }
        if (peak > .02f && peak < target) {
            val gain = (target / peak).coerceAtMost(2.2f)
            for (i in out.indices) out[i] = (out[i] * gain).coerceIn(-1f, 1f)
        }
        return SampleSound(out, outRate)
    }

    fun estimateBpm(sound: SampleSound): Int {
        val targetHz = 100
        val hop = max(1, sound.sampleRate / targetHz)
        val count = min(sound.pcm.size / hop, targetHz * 150)
        if (count < targetHz * 4) return 140
        val env = DoubleArray(count)
        var p = 0
        for (i in 0 until count) {
            var energy = 0.0
            val end = min(sound.pcm.size, p + hop)
            while (p < end) {
                energy += abs(sound.pcm[p].toDouble())
                p++
            }
            env[i] = energy / hop
        }
        val onset = DoubleArray(count)
        var smooth = env[0]
        for (i in 1 until count) {
            smooth = smooth * .90 + env[i] * .10
            onset[i] = (env[i] - smooth).coerceAtLeast(0.0)
        }
        var bestBpm = 140
        var bestScore = Double.NEGATIVE_INFINITY
        for (bpm in 75..190) {
            val lag = (targetHz * 60.0 / bpm).roundToInt().coerceAtLeast(1)
            var score = 0.0
            var normA = 1e-9
            var normB = 1e-9
            var i = lag
            while (i < count) {
                val a = onset[i]
                val b = onset[i - lag]
                score += a * b
                normA += a * a
                normB += b * b
                i++
            }
            score /= sqrt(normA * normB)
            if (bpm in 120..165) score *= 1.025
            if (score > bestScore) {
                bestScore = score
                bestBpm = bpm
            }
        }
        return bestBpm.coerceIn(75, 190)
    }

    fun styleBpm(style: String): Int = when (style) {
        "SLOWED" -> 96
        "DARK" -> 130
        "BRAZILIAN" -> 142
        "AGRESIVO" -> 165
        else -> 150
    }
}
