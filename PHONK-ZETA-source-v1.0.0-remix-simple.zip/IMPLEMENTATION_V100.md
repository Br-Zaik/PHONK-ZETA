# PHONK ZETA v1.0.0

Rediseño completo del modo principal:
- Flujo simple: Importar -> Separar -> Remix -> Exportar.
- Importación MP3/M4A/FLAC/OGG/WAV mediante codecs Android.
- Detección local aproximada de BPM.
- Separación local rápida en Bajo, Batería, Voz/medios e Instrumental mediante DSP optimizado.
- La separación se procesa fuera de la UI para evitar congelamientos.
- Editor pesado anterior deja de ser la interfaz principal.
- Remix por estilos: Drift, Dark, Agresivo, Brazilian, Slowed.
- Pistas con ON/OFF y volumen, sin timeline pesado.
- Exportación WAV y M4A.
- Autosave y proyectos.

Nota: la separación de stems es aproximada por filtros DSP locales. No se presenta como separación IA exacta.
